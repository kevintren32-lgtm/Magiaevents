# Plataforma de gestión de eventos — núcleo funcional (v0.1)

## Estado real (verificado el 20/10/2026)
- **API y lógica — `npm test`: 38 de 38 pasan.** Unitarias de dominio (dinero, finanzas, estados, disponibilidad, cronograma); autenticación (bloqueo, recuperación, anti-enumeración); 16 de seguridad y aislamiento (cambio de identificadores, roles, documentos y enlaces firmados, cuenta desactivada, rutas estáticas, 25 pagos simultáneos con la misma clave); cobertura de invitados/CSV/mesas, tareas y dependencias, automatizaciones idempotentes, reportes y CSV, cambios, propuestas, documentos, catálogo, usuarios, ajustes y disponibilidad; dos flujos completos y la pasarela.
- **Navegador real (Chromium + Playwright) — `npm run test:e2e`: 11 de 11 pasan.** Recorre TODAS las pantallas de los tres portales en escritorio y a 390 px (sin errores de carga, sin «undefined/NaN», campos con etiqueta, sin desbordamiento horizontal) y ejecuta flujos: invitación → activación → asistente de 10 pasos; catálogo, usuarios, permisos, desactivación, marca y automatizaciones; subida y descarga de documentos; importación de invitados y sobrecupo de mesas; mensajes planner↔cliente; cambio de contraseña; recuperación; disponibilidad del proveedor. Cero errores de consola o CSP (se excluyen los 4xx que las pruebas provocan a propósito).
- **Tipos:** `npm run typecheck` sin errores (con un sustituto mínimo de `@types/node`, ver `types/node-shim.d.ts`).
- **Operación verificada a mano:** arranque en producción (rechaza sin `APP_SECRET`, cookie `Secure`), sesión válida tras reiniciar el servidor, respaldo en caliente con verificación de integridad, `/api/health`.
- Capturas de ejemplo en `docs/capturas/`.

## Qué se implementó
**Backend:** autenticación (sesiones, bloqueo, recuperación, invitaciones), roles planner/colaborador/cliente/proveedor con permisos en el servidor, eventos con máquina de estados, catálogo, solicitudes, cotizaciones versionadas, asignaciones, disponibilidad, pagos idempotentes, webhook de pasarela con HMAC, gastos, ajustes de solo anexado, finanzas, tareas y plantillas, cronograma con conflictos, invitados/mesas con CSV, incidencias, cambios, documentos privados con enlaces firmados, conversaciones solo con la planner, notificaciones, automatizaciones, reportes y CSV, auditoría inmutable.
**Interfaz (sin dependencias, CSP estricta):** tres portales diferenciados.
- *Planner:* panel, eventos (tabla y calendario) con detalle por pestañas (resumen, servicios, presupuesto, pagos, proveedores, cronograma, tareas, invitados/mesas, documentos, cambios, incidencias, historial), clientes, proveedores, catálogo, reportes, auditoría, usuarios y permisos, configuración (marca, integraciones, automatizaciones).
- *Cliente:* asistente guiado de 10 pasos con guardado de progreso, catálogo, solicitudes, aprobación de propuestas, pagos, documentos, cronograma, invitados y mesas, tareas, solicitudes de cambio.
- *Proveedor:* inicio, agenda mensual, asignaciones con ficha operativa, checklist, llegada/inicio/fin, incidencias, disponibilidad, perfil.
- Compartido: mensajes (siempre con la planner), notificaciones, cuenta. Responsive (tablas a tarjetas, navegación inferior en móvil), foco visible, etiquetas, estados con texto.

## Qué NO está hecho
- **Next.js:** no se usó (sin red para instalar). **Supabase/PostgreSQL:** el esquema y las políticas RLS están generados en `supabase/` pero **nunca se ejecutaron** y la aplicación sigue usando SQLite; falta la capa de datos. El aislamiento hoy lo garantiza el servidor (probado). Ver `docs/DESPLIEGUE.md`.
- **Docker, systemd y Caddy:** archivos de ejemplo en `Dockerfile` y `deploy/`, sin probar. El respaldo (`npm run backup`) y `/api/health` sí están probados.
- **Correo, WhatsApp, pasarela real, calendarios externos, mapas:** sin conectar. Los correos quedan en `email_outbox` y NO se envían (la interfaz muestra el enlace de invitación para compartirlo a mano). El webhook responde 503 sin `GATEWAY_WEBHOOK_SECRET`.
- **PDF y firma electrónica**, gráficos en reportes, búsqueda global, módulo de solicitudes de privacidad (acceso/rectificación/eliminación) y edición de logotipo/tipografías por pantalla (la API de ajustes existe).
- **Sin verificar:** accesibilidad con lector de pantalla real, rendimiento bajo carga sostenida, Safari/Firefox y tablets (solo se probó Chromium), y comportamiento en un teléfono físico.
- Los textos legales son marcadores que deben redactarse y revisarse con asesoría jurídica.

**Despliegue:** guía y lista de verificación en `docs/DESPLIEGUE.md`.

## Ejecutar
```
node --version        # >= 22.18
npm run seed -- --owner-email tu@correo.com --demo   # imprime contraseñas aleatorias UNA vez
APP_SECRET=$(openssl rand -hex 32) npm start         # http://localhost:3000
npm test
```
Variables: `PORT`, `DB_PATH`, `STORAGE_DIR`, `APP_SECRET` (obligatoria en producción), `GATEWAY_WEBHOOK_SECRET`, `NODE_ENV`, `TRUST_PROXY=1`.
Los datos demo usan `@demo.invalid`; para eliminarlos, borra la base de datos de demostración. La semilla rechaza `--demo` en producción.

## Decisiones y supuestos
Importes en centavos enteros; IVA por línea, redondeo mitad hacia arriba. Ingreso neto = contratado − IVA; costos de proveedor capturados sin IVA recuperable. «Cobrado» solo cuenta pagos pagados/parciales; lo manual no es «verificado». Correo único global (para multiempresa habrá que acotarlo por organización). Estados internos en inglés; las etiquetas en español irán en la interfaz.
