# Guía de despliegue

Hay dos caminos. **Solo el A está probado de punta a punta.**

## A. Despliegue actual (Node 22 + SQLite) — probado en desarrollo
Requisitos: un servidor Linux con Node ≥ 22.18, un dominio y HTTPS (Caddy de ejemplo en `deploy/`). Un solo proceso y un solo archivo de base de datos: apropiado para una planner y su equipo; no para múltiples réplicas.

1. Copia el proyecto a `/opt/planner` y crea el usuario `planner` y la carpeta `/var/lib/planner` (permisos 700).
2. `cp .env.example /etc/planner.env`; genera `APP_SECRET` (`openssl rand -hex 32`); `chmod 600`.
3. Crea la propietaria (imprime la contraseña una sola vez): `node scripts/seed.ts --owner-email tu@correo.com --org "Nombre"`. **No uses `--demo` en producción** (el script lo rechaza).
4. Instala `deploy/planner.service.example` en systemd y `deploy/Caddyfile.example` en Caddy. Arranca y abre el dominio.
5. Entra, cambia la contraseña, configura marca y textos legales (Configuración), e invita al equipo. Los correos NO se envían: la pantalla de invitación muestra el enlace para compartirlo por tu canal.

### Respaldos y recuperación
- `npm run backup -- /ruta/respaldos` hace una copia consistente (VACUUM INTO), copia los documentos y verifica la integridad (`PRAGMA integrity_check`). Probado.
- Programa en cron diario y copia fuera del servidor (otro proveedor). Conserva al menos 30 días.
- Restaurar: detén el servicio, reemplaza `app.db` y `storage/` por la copia, arranca. **Prueba una restauración antes de salir a producción.**

### Actualizaciones y reversión
Haz respaldo → copia el código nuevo → reinicia (las migraciones en `migrations/sqlite` se aplican solas y solo añaden). Para revertir: restaura el respaldo y el código anterior. Las migraciones no borran datos.

### Monitoreo
`GET /api/health` responde `{"ok":true}`: úsalo en un monitor externo. Los errores internos se registran en el log del servicio con una referencia que también ve el usuario. Revisa el log y la pestaña Auditoría.

### Lista de verificación de producción
- [ ] HTTPS activo; `NODE_ENV=production` (cookies Secure); `APP_SECRET` definido; `TRUST_PROXY=1` solo tras tu proxy.
- [ ] Contraseña de la propietaria cambiada; sin datos demo; cuentas de equipo con permisos mínimos.
- [ ] Respaldo programado, copiado fuera del servidor y restauración probada.
- [ ] Textos legales y aviso de privacidad revisados por asesoría jurídica (los actuales son marcadores).
- [ ] Monitor de `/api/health`; disco con espacio; actualizaciones del sistema al día.
- [ ] Política de retención de datos definida (qué se conserva y cuánto tiempo).
- [ ] Correo, pasarela de pagos y WhatsApp: **no conectados**; decide si los necesitas antes de abrir al público.

## B. Supabase / PostgreSQL — SIN PROBAR, requiere trabajo adicional
Lo que hay: `supabase/migrations/0001_schema.sql` (52 tablas, generado del esquema real con `npm run gen:pg`) y `0002_rls.sql` (RLS en todas las tablas, vistas de portal para cliente y proveedor, funciones `app.*`) y `supabase/tests/rls_isolation.sql`.
Lo que NO hay: la aplicación **no usa PostgreSQL todavía**. Falta escribir la capa de acceso a datos (hoy `node:sqlite` síncrono) y adaptar autenticación a Supabase Auth (`users.id` debe coincidir con `auth.users.id`; el hash de contraseña propio dejaría de usarse).
Modelo de seguridad previsto: RLS activo y **sin políticas de escritura**; el servidor escribe con `service_role` aplicando las reglas de negocio; el personal lee tablas base según permisos; clientes y proveedores leen solo vistas con columnas autorizadas (sin costos, sin notas internas, sin datos de otros).
Pasos para validarlo: `supabase start` → `supabase db reset` → `psql … -f supabase/tests/rls_isolation.sql`. Espera tener que corregir detalles de sintaxis o permisos: nunca se ejecutó. Revisa también los avisos del linter de Supabase sobre vistas «security definer» (aquí son intencionales).
Ámbito multiempresa: todas las tablas llevan `org_id` y las políticas lo exigen; el correo es único global (en SaaS habría que acotarlo por organización).
