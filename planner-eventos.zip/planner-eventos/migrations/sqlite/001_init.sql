-- 001_init.sql — Esquema base (SQLite). Fechas ISO-8601 UTC; importes en centavos enteros.
-- Cada tabla de negocio lleva org_id (aislamiento multiorganización).

CREATE TABLE organizations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE organization_settings (
  org_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (org_id, key)
);

CREATE TABLE counters (
  org_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  value INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (org_id, name)
);

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  email TEXT NOT NULL COLLATE NOCASE UNIQUE,
  password_hash TEXT,
  display_name TEXT NOT NULL,
  phone TEXT,
  role TEXT NOT NULL CHECK (role IN ('owner','staff','client','vendor')),
  permissions TEXT NOT NULL DEFAULT '[]',
  prefs TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('invited','active','disabled')),
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_users_org ON users(org_id);

CREATE TABLE sessions (
  id TEXT PRIMARY KEY,                 -- SHA-256 del token (nunca el token)
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  expires_at TEXT NOT NULL,
  revoked_at TEXT,
  user_agent TEXT
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE password_resets (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE clients (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  user_id TEXT UNIQUE REFERENCES users(id),
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  internal_notes TEXT,
  archived_at TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_clients_org ON clients(org_id);

CREATE TABLE vendors (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  user_id TEXT UNIQUE REFERENCES users(id),
  business_name TEXT NOT NULL,
  legal_name TEXT,
  contact_name TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  city TEXT,
  categories TEXT NOT NULL DEFAULT '[]',
  description TEXT,
  capacity_note TEXT,
  coverage TEXT,
  setup_minutes INTEGER NOT NULL DEFAULT 0,
  teardown_minutes INTEGER NOT NULL DEFAULT 0,
  tech_requirements TEXT,
  payment_terms TEXT,
  cancellation_policy TEXT,
  tax_data TEXT,                         -- acceso restringido (finance.view)
  status TEXT NOT NULL DEFAULT 'prospect' CHECK (status IN ('prospect','evaluating','docs_pending','approved','active','suspended','inactive','temporarily_unavailable')),
  internal_notes TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_vendors_org ON vendors(org_id);

CREATE TABLE invitations (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  email TEXT NOT NULL COLLATE NOCASE,
  role TEXT NOT NULL CHECK (role IN ('staff','client','vendor')),
  display_name TEXT,
  permissions TEXT NOT NULL DEFAULT '[]',
  client_id TEXT REFERENCES clients(id),
  vendor_id TEXT REFERENCES vendors(id),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  accepted_at TEXT,
  revoked_at TEXT,
  invited_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_invitations_org ON invitations(org_id);

CREATE TABLE email_outbox (
  id TEXT PRIMARY KEY,
  org_id TEXT REFERENCES organizations(id),
  to_email TEXT NOT NULL,
  template TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued_not_sent' CHECK (status IN ('queued_not_sent','sent','failed')),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE rate_limits (
  key TEXT PRIMARY KEY,
  window_start INTEGER NOT NULL,
  count INTEGER NOT NULL
);

-- ───────────── Eventos ─────────────
CREATE TABLE events (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  folio TEXT NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'prospect' CHECK (status IN ('prospect','initial_consult','preparing','proposal_drafting','proposal_sent','pending_approval','contracted','planning','confirmed','in_execution','finished','closed','cancelled','archived')),
  event_date TEXT,
  start_time TEXT,
  end_time TEXT,
  timezone TEXT NOT NULL DEFAULT 'America/Mexico_City',
  venue_name TEXT,
  address TEXT,
  city TEXT,
  latitude REAL,
  longitude REAL,
  guests_estimated INTEGER,
  guests_confirmed INTEGER NOT NULL DEFAULT 0,
  budget_target_cents INTEGER,
  budget_approved_cents INTEGER,
  currency TEXT NOT NULL DEFAULT 'MXN',
  planner_id TEXT REFERENCES users(id),
  notes_internal TEXT,
  notes_client TEXT,
  brief TEXT NOT NULL DEFAULT '{}',
  brief_step INTEGER NOT NULL DEFAULT 0,
  brief_submitted_at TEXT,
  cancel_reason TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  closed_at TEXT,
  UNIQUE (org_id, folio)
);
CREATE INDEX idx_events_org_date ON events(org_id, event_date);
CREATE INDEX idx_events_status ON events(org_id, status);

CREATE TABLE event_staff (
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id),
  role TEXT NOT NULL DEFAULT 'coordinator',
  PRIMARY KEY (event_id, user_id)
);

CREATE TABLE client_event_memberships (
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  client_id TEXT NOT NULL REFERENCES clients(id),
  kind TEXT NOT NULL DEFAULT 'primary' CHECK (kind IN ('primary','participant')),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (event_id, client_id)
);
CREATE INDEX idx_cem_client ON client_event_memberships(client_id);

-- ───────────── Catálogo ─────────────
CREATE TABLE service_categories (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  name TEXT NOT NULL,
  sort INTEGER NOT NULL DEFAULT 0,
  UNIQUE (org_id, name)
);

CREATE TABLE service_catalog (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  category_id TEXT NOT NULL REFERENCES service_categories(id),
  name TEXT NOT NULL,
  description TEXT,
  price_type TEXT NOT NULL DEFAULT 'fixed' CHECK (price_type IN ('fixed','per_person','per_hour','per_day','per_unit','per_meter','per_package','custom','quote')),
  base_price_cents INTEGER,
  unit_label TEXT,
  min_qty_milli INTEGER NOT NULL DEFAULT 1000,
  max_qty_milli INTEGER,
  tax_bps INTEGER NOT NULL DEFAULT 1600,
  advance_bps INTEGER NOT NULL DEFAULT 5000,
  visible_to_client INTEGER NOT NULL DEFAULT 1,
  active INTEGER NOT NULL DEFAULT 1,
  vendor_id TEXT REFERENCES vendors(id),
  internal_notes TEXT,
  price_version INTEGER NOT NULL DEFAULT 1,
  details TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_catalog_org ON service_catalog(org_id, category_id);

CREATE TABLE service_packages (
  id TEXT PRIMARY KEY,
  service_id TEXT NOT NULL REFERENCES service_catalog(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  price_cents INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);

-- ───────────── Solicitudes, cotizaciones, asignaciones ─────────────
CREATE TABLE service_requests (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  service_id TEXT NOT NULL REFERENCES service_catalog(id),
  package_id TEXT REFERENCES service_packages(id),
  qty_milli INTEGER NOT NULL DEFAULT 1000,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','requested','in_review','info_required','quote_preparing','quote_sent','client_approved','pending_vendor','confirmed','contracted','rejected','cancelled','completed')),
  client_notes TEXT,
  planner_notes TEXT,
  unit_price_cents INTEGER,
  discount_cents INTEGER NOT NULL DEFAULT 0,
  tax_bps INTEGER,
  price_version INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_requests_event ON service_requests(event_id);

CREATE TABLE quotes (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL UNIQUE REFERENCES events(id) ON DELETE CASCADE,
  current_version INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE quote_versions (
  id TEXT PRIMARY KEY,
  quote_id TEXT NOT NULL REFERENCES quotes(id) ON DELETE CASCADE,
  version INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'sent' CHECK (status IN ('draft','sent','accepted','rejected','superseded')),
  subtotal_cents INTEGER NOT NULL,
  discount_cents INTEGER NOT NULL,
  charges_cents INTEGER NOT NULL DEFAULT 0,
  charges_note TEXT,
  tax_cents INTEGER NOT NULL,
  total_cents INTEGER NOT NULL,
  advance_cents INTEGER NOT NULL,
  note TEXT,
  sent_at TEXT,
  accepted_at TEXT,
  accepted_by TEXT REFERENCES users(id),
  rejected_reason TEXT,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (quote_id, version)
);

CREATE TABLE quote_items (
  id TEXT PRIMARY KEY,
  version_id TEXT NOT NULL REFERENCES quote_versions(id) ON DELETE CASCADE,
  request_id TEXT REFERENCES service_requests(id),
  description TEXT NOT NULL,
  qty_milli INTEGER NOT NULL,
  unit_price_cents INTEGER NOT NULL,
  discount_cents INTEGER NOT NULL DEFAULT 0,
  tax_bps INTEGER NOT NULL,
  line_gross_cents INTEGER NOT NULL,
  line_tax_cents INTEGER NOT NULL,
  line_total_cents INTEGER NOT NULL
);
CREATE INDEX idx_quote_items_version ON quote_items(version_id);

CREATE TABLE service_assignments (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  request_id TEXT REFERENCES service_requests(id),
  vendor_id TEXT NOT NULL REFERENCES vendors(id),
  status TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','accepted','rejected','confirmed','completed','cancelled')),
  public_title TEXT NOT NULL,
  service_description TEXT,
  qty_milli INTEGER NOT NULL DEFAULT 1000,
  cost_cents INTEGER NOT NULL DEFAULT 0,       -- costo contratado (privado de la planner)
  actual_cost_cents INTEGER,                   -- costo real (privado)
  service_date TEXT NOT NULL,
  arrival_time TEXT,
  setup_time TEXT,
  start_time TEXT,
  end_time TEXT,
  teardown_time TEXT,
  location_visible INTEGER NOT NULL DEFAULT 0,
  location_detail TEXT,
  instructions TEXT,
  requirements TEXT,
  staff_needed INTEGER,
  reject_reason TEXT,
  arrived_at TEXT,
  started_at TEXT,
  finished_at TEXT,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_assign_vendor ON service_assignments(vendor_id, service_date);
CREATE INDEX idx_assign_event ON service_assignments(event_id);

CREATE TABLE assignment_checklist (
  id TEXT PRIMARY KEY,
  assignment_id TEXT NOT NULL REFERENCES service_assignments(id) ON DELETE CASCADE,
  phase TEXT NOT NULL CHECK (phase IN ('prep','exec','teardown')),
  text TEXT NOT NULL,
  done INTEGER NOT NULL DEFAULT 0,
  done_at TEXT
);

CREATE TABLE vendor_availability (
  id TEXT PRIMARY KEY,
  vendor_id TEXT NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('available','unavailable')),
  capacity INTEGER NOT NULL DEFAULT 1,
  note TEXT,
  UNIQUE (vendor_id, date)
);

CREATE TABLE vendor_blackouts (
  id TEXT PRIMARY KEY,
  vendor_id TEXT NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  reason TEXT
);

CREATE TABLE vendor_evaluations (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  vendor_id TEXT NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  event_id TEXT REFERENCES events(id),
  punctuality INTEGER CHECK (punctuality BETWEEN 1 AND 5),
  quality INTEGER CHECK (quality BETWEEN 1 AND 5),
  compliance INTEGER CHECK (compliance BETWEEN 1 AND 5),
  professionalism INTEGER CHECK (professionalism BETWEEN 1 AND 5),
  notes TEXT,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ───────────── Finanzas ─────────────
CREATE TABLE payments (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL REFERENCES events(id),
  direction TEXT NOT NULL CHECK (direction IN ('in','out')),   -- in: cliente→planner, out: planner→proveedor
  client_id TEXT REFERENCES clients(id),
  vendor_id TEXT REFERENCES vendors(id),
  concept TEXT,
  amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
  paid_cents INTEGER NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'MXN',
  due_date TEXT,
  paid_date TEXT,
  method TEXT,
  reference TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','scheduled','in_review','paid','partially_paid','overdue','refunded','cancelled')),
  source TEXT NOT NULL DEFAULT 'manual' CHECK (source IN ('manual','gateway')),
  verified INTEGER NOT NULL DEFAULT 0,       -- 1 solo si lo confirmó un webhook autenticado
  idempotency_key TEXT,
  receipt_document_id TEXT,
  recorded_by TEXT REFERENCES users(id),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  CHECK (paid_cents >= 0 AND paid_cents <= amount_cents),
  CHECK ((direction = 'in' AND client_id IS NOT NULL) OR (direction = 'out' AND vendor_id IS NOT NULL))
);
CREATE UNIQUE INDEX uq_payments_idem ON payments(org_id, idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE INDEX idx_payments_event ON payments(event_id);

CREATE TABLE payment_transactions (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  payment_id TEXT REFERENCES payments(id),
  provider TEXT NOT NULL,
  external_id TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (provider, external_id)
);

CREATE TABLE webhook_events (
  id TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  external_id TEXT NOT NULL,
  event_type TEXT,
  signature_valid INTEGER NOT NULL,
  payload_sha256 TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('processed','ignored','rejected')),
  received_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (provider, external_id)
);

CREATE TABLE expenses (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL REFERENCES events(id),
  vendor_id TEXT REFERENCES vendors(id),
  category TEXT,
  description TEXT NOT NULL,
  amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
  expense_date TEXT NOT NULL,
  recorded_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE financial_adjustments (   -- solo anexado: las correcciones son movimientos compensatorios
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL REFERENCES events(id),
  kind TEXT NOT NULL CHECK (kind IN ('client_credit','client_charge','refund','vendor_adjustment','correction')),
  amount_cents INTEGER NOT NULL,      -- con signo
  reason TEXT NOT NULL,
  related_payment_id TEXT REFERENCES payments(id),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ───────────── Invitados y mesas ─────────────
CREATE TABLE tables_seating (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  capacity INTEGER NOT NULL CHECK (capacity > 0),
  pos_x INTEGER,
  pos_y INTEGER,
  UNIQUE (event_id, name)
);

CREATE TABLE guests (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  group_name TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','invited','confirmed','declined','no_response','waitlist','attended','no_show')),
  companions INTEGER NOT NULL DEFAULT 0,
  dietary TEXT,
  accessibility TEXT,
  notes TEXT,
  table_id TEXT REFERENCES tables_seating(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_guests_event ON guests(event_id);

-- ───────────── Tareas y cronograma ─────────────
CREATE TABLE tasks (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  assignment_id TEXT REFERENCES service_assignments(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  assignee_user_id TEXT REFERENCES users(id),
  audience TEXT NOT NULL DEFAULT 'internal' CHECK (audience IN ('internal','client','vendor')),
  due_date TEXT,
  priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','in_progress','blocked','completed','cancelled')),
  completed_at TEXT,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_tasks_event ON tasks(event_id);
CREATE INDEX idx_tasks_assignee ON tasks(assignee_user_id, status);

CREATE TABLE task_dependencies (
  task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  depends_on_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  PRIMARY KEY (task_id, depends_on_id),
  CHECK (task_id <> depends_on_id)
);

CREATE TABLE task_templates (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  name TEXT NOT NULL,
  event_type TEXT NOT NULL,
  items TEXT NOT NULL DEFAULT '[]',   -- [{title, offset_days, audience, priority}]
  is_demo INTEGER NOT NULL DEFAULT 0,
  UNIQUE (org_id, name)
);

CREATE TABLE timeline_items (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  assignment_id TEXT REFERENCES service_assignments(id) ON DELETE SET NULL,
  vendor_id TEXT REFERENCES vendors(id),
  item_date TEXT NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  title TEXT NOT NULL,
  location TEXT,
  instructions TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','in_progress','done','blocked','cancelled')),
  priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  locked INTEGER NOT NULL DEFAULT 0,         -- 1 = confirmado: cambios solo por solicitud de cambio
  show_to_client INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_timeline_event ON timeline_items(event_id, item_date, start_time);

CREATE TABLE timeline_dependencies (
  item_id TEXT NOT NULL REFERENCES timeline_items(id) ON DELETE CASCADE,
  depends_on_id TEXT NOT NULL REFERENCES timeline_items(id) ON DELETE CASCADE,
  PRIMARY KEY (item_id, depends_on_id),
  CHECK (item_id <> depends_on_id)
);

-- ───────────── Documentos ─────────────
CREATE TABLE documents (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT REFERENCES events(id),
  vendor_id TEXT REFERENCES vendors(id),
  kind TEXT NOT NULL DEFAULT 'other',
  name TEXT NOT NULL,
  storage_key TEXT NOT NULL UNIQUE,         -- aleatorio, no predecible
  mime TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  supersedes_id TEXT REFERENCES documents(id),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  visibility TEXT NOT NULL DEFAULT 'internal' CHECK (visibility IN ('internal','client','vendor')),
  expires_on TEXT,
  uploaded_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_documents_event ON documents(event_id);

CREATE TABLE document_permissions (
  document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  vendor_id TEXT NOT NULL REFERENCES vendors(id),
  PRIMARY KEY (document_id, vendor_id)
);

-- ───────────── Comunicación centralizada ─────────────
-- Cada conversación tiene exactamente UN participante externo (cliente O proveedor) + la planner.
-- No existe estructura que permita conversación cliente↔proveedor.
CREATE TABLE conversations (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT REFERENCES events(id),
  kind TEXT NOT NULL CHECK (kind IN ('client','vendor')),
  participant_user_id TEXT NOT NULL REFERENCES users(id),
  subject TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_conv_participant ON conversations(participant_user_id);

CREATE TABLE messages (
  id TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  author_id TEXT NOT NULL REFERENCES users(id),
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_messages_conv ON messages(conversation_id, created_at);

CREATE TABLE message_attachments (
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  document_id TEXT NOT NULL REFERENCES documents(id),
  PRIMARY KEY (message_id, document_id)
);

CREATE TABLE notifications (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_id TEXT REFERENCES events(id),
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  link TEXT,
  priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal','high')),
  dedupe_key TEXT,
  read_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE UNIQUE INDEX uq_notif_dedupe ON notifications(user_id, dedupe_key) WHERE dedupe_key IS NOT NULL;
CREATE INDEX idx_notif_user ON notifications(user_id, read_at, created_at);

-- ───────────── Incidencias y cambios ─────────────
CREATE TABLE incidents (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL REFERENCES events(id),
  assignment_id TEXT REFERENCES service_assignments(id),
  vendor_id TEXT REFERENCES vendors(id),
  reported_by TEXT NOT NULL REFERENCES users(id),
  severity TEXT NOT NULL DEFAULT 'medium' CHECK (severity IN ('low','medium','high','critical')),
  description TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','resolved')),
  resolution TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  resolved_at TEXT
);

CREATE TABLE change_requests (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  event_id TEXT NOT NULL REFERENCES events(id),
  requested_by TEXT NOT NULL REFERENCES users(id),
  target_type TEXT NOT NULL CHECK (target_type IN ('timeline_item','assignment','event','service_request','other')),
  target_id TEXT,
  payload TEXT NOT NULL DEFAULT '{}',
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  decided_by TEXT REFERENCES users(id),
  decided_at TEXT,
  decision_note TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ───────────── Auditoría (solo anexado) ─────────────
CREATE TABLE audit_logs (
  id TEXT PRIMARY KEY,
  org_id TEXT REFERENCES organizations(id),
  user_id TEXT REFERENCES users(id),
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT,
  before_json TEXT,
  after_json TEXT,
  reason TEXT,
  result TEXT NOT NULL DEFAULT 'ok',
  ip TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_audit_org ON audit_logs(org_id, created_at);
CREATE INDEX idx_audit_entity ON audit_logs(entity, entity_id);

CREATE TRIGGER audit_logs_no_update BEFORE UPDATE ON audit_logs
BEGIN SELECT RAISE(ABORT, 'audit_logs es de solo anexado'); END;
CREATE TRIGGER audit_logs_no_delete BEFORE DELETE ON audit_logs
BEGIN SELECT RAISE(ABORT, 'audit_logs es de solo anexado'); END;
CREATE TRIGGER fin_adj_no_update BEFORE UPDATE ON financial_adjustments
BEGIN SELECT RAISE(ABORT, 'financial_adjustments es de solo anexado: registra un movimiento compensatorio'); END;
CREATE TRIGGER fin_adj_no_delete BEFORE DELETE ON financial_adjustments
BEGIN SELECT RAISE(ABORT, 'financial_adjustments es de solo anexado: registra un movimiento compensatorio'); END;

-- ───────────── Integraciones, automatizaciones, privacidad ─────────────
CREATE TABLE integrations (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  kind TEXT NOT NULL CHECK (kind IN ('email','payments','whatsapp','calendar','maps','ai')),
  status TEXT NOT NULL DEFAULT 'not_configured' CHECK (status IN ('not_configured','configured')),
  notes TEXT,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (org_id, kind)
);

CREATE TABLE automation_rules (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  kind TEXT NOT NULL CHECK (kind IN ('payment_reminders','document_expiry','pending_guest_confirmations','overdue_tasks','services_without_vendor','vendors_unconfirmed','upcoming_events','mark_overdue_payments')),
  enabled INTEGER NOT NULL DEFAULT 1,
  params TEXT NOT NULL DEFAULT '{}',
  UNIQUE (org_id, kind)
);

CREATE TABLE automation_runs (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  rule_id TEXT NOT NULL REFERENCES automation_rules(id) ON DELETE CASCADE,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  status TEXT NOT NULL CHECK (status IN ('ok','error')),
  created_count INTEGER NOT NULL DEFAULT 0,
  error TEXT
);

CREATE TABLE consents (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  version TEXT NOT NULL,
  accepted_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE data_requests (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  kind TEXT NOT NULL CHECK (kind IN ('access','rectification','deletion')),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','done','rejected')),
  details TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
