-- 002: mensaje de la planner visible para el cliente (separado de las notas internas)
ALTER TABLE service_requests ADD COLUMN planner_message TEXT;
