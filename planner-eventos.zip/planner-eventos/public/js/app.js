import { html, raw, $, $$, state, can, get, post, route, clearRoutes, actions, submits, dispatch, here, query, field, toast, ApiError } from './core.js';
import { registerShared, refreshUnread } from './shared.js';
import { registerAdmin } from './admin.js';
import { registerClient } from './client.js';
import { registerVendor } from './vendor.js';

const HEX = /^#[0-9a-fA-F]{6}$/;
function applyBrand() {
  const b = state.brand ?? {}; const r = document.documentElement.style;
  if (HEX.test(b.color_bg ?? '')) r.setProperty('--bg', b.color_bg); if (HEX.test(b.color_ink ?? '')) r.setProperty('--ink', b.color_ink); if (HEX.test(b.color_accent ?? '')) r.setProperty('--accent', b.color_accent);
  if (b.font_heading) r.setProperty('--font-heading', b.font_heading); if (b.font_body) r.setProperty('--font-body', b.font_body);
  document.title = b.name || 'Plataforma de eventos';
}
const brandName = () => state.brand?.name || state.orgName || 'Plataforma de eventos';
const brandMark = () => html`${state.brand?.logo_url && /^https:\/\//.test(state.brand.logo_url) ? html`<img src="${state.brand.logo_url}" alt="" height="36"> ` : ''}${brandName()}${state.brand?.tagline ? html`<small>${state.brand.tagline}</small>` : ''}`;

// ───── Autenticación ─────
const AUTH = {
  login: () => html`<h1 class="sr">Iniciar sesión</h1><form data-submit="login" novalidate><h2>Bienvenida</h2>${field('email', 'Correo electrónico', { type: 'email', required: true, autocomplete: 'username' })}${field('password', 'Contraseña', { type: 'password', required: true, autocomplete: 'current-password' })}<button class="btn primary" type="submit">Entrar</button><small class="err" data-err="_form" role="alert"></small></form><div class="links"><a href="#/forgot">Olvidé mi contraseña</a></div>`,
  forgot: () => html`<form data-submit="forgot" novalidate><h2>Recuperar acceso</h2><p class="m">Escribe tu correo y, si existe una cuenta, recibirás instrucciones.</p>${field('email', 'Correo electrónico', { type: 'email', required: true })}<button class="btn primary" type="submit">Enviar instrucciones</button><small class="err" data-err="_form" role="alert"></small></form><div class="links"><a href="#/login">Volver a iniciar sesión</a></div>`,
  reset: () => html`<form data-submit="reset" novalidate><h2>Nueva contraseña</h2>${field('password', 'Nueva contraseña', { type: 'password', required: true, autocomplete: 'new-password', hint: 'Mínimo 10 caracteres, con letras y números.' })}<button class="btn primary" type="submit">Guardar contraseña</button><small class="err" data-err="_form" role="alert"></small></form>`,
  invite: () => html`<form data-submit="invite" novalidate><h2>Activa tu cuenta</h2>${field('display_name', 'Tu nombre', { required: true })}${field('password', 'Crea una contraseña', { type: 'password', required: true, autocomplete: 'new-password', hint: 'Mínimo 10 caracteres, con letras y números.' })}${field('accept_privacy', 'He leído y acepto el aviso de privacidad', { type: 'checkbox' })}<button class="btn primary" type="submit">Activar cuenta</button><small class="err" data-err="_form" role="alert"></small></form>`,
};
function renderAuth(kind) { $('#app').innerHTML = html`<main id="main" class="auth"><div class="card"><div class="brand">${brandMark()}</div>${AUTH[kind]()}</div></main>`.s; $('#main h2, #main h1')?.setAttribute('tabindex', '-1'); }
submits.login = async (d) => {
  let r; try { r = await post('/api/auth/login', d); } catch (e) { if (e instanceof ApiError && e.status === 429) throw new Error('Demasiados intentos. Espera unos minutos e inténtalo de nuevo.'); throw e; }
  state.user = r.user; clearRoutes(); setup(); $('#app').innerHTML = ''; location.hash = '#/'; onRoute();
};
submits.forgot = async (d) => { const r = await post('/api/auth/forgot', d); toast(r.message); location.hash = '#/login'; };
submits.reset = async (d) => { await post('/api/auth/reset', { token: query().get('token') ?? '', password: d.password }); toast('Contraseña actualizada. Ya puedes iniciar sesión.'); location.hash = '#/login'; };
submits.invite = async (d) => { await post('/api/auth/accept-invite', { token: query().get('token') ?? '', password: d.password, display_name: d.display_name, accept_privacy: !!d.accept_privacy }); toast('Cuenta activada. Inicia sesión.'); location.hash = '#/login'; };
actions.logout = async () => { await post('/api/auth/logout'); state.user = null; $('#app').innerHTML = ''; location.hash = '#/login'; onRoute(); };
actions.menu = () => $('.side')?.classList.toggle('open');

// ───── Estructura ─────
const NAV = {
  staff: () => [['/', 'Panel'], ['/events', 'Eventos'], can('clients.manage') && ['/clients', 'Clientes'], can('vendors.manage') && ['/vendors', 'Proveedores'], can('catalog.manage') && ['/catalog', 'Catálogo'], can('reports.view') && ['/reports', 'Reportes'], ['/messages', 'Mensajes'], can('audit.view') && ['/audit', 'Auditoría'], can('users.manage') && ['/users', 'Usuarios'], can('settings.manage') && ['/settings', 'Configuración']].filter(Boolean),
  client: () => [['/', 'Mi evento'], ['/messages', 'Mensajes'], ['/notifications', 'Notificaciones'], ['/account', 'Mi cuenta']],
  vendor: () => [['/', 'Inicio'], ['/agenda', 'Agenda'], ['/assignments', 'Asignaciones'], ['/availability', 'Disponibilidad'], ['/profile', 'Perfil'], ['/messages', 'Mensajes']],
};
const navItems = () => (NAV[state.user.role === 'owner' ? 'staff' : state.user.role] ?? NAV.client)();
function renderShell() {
  const items = navItems();
  $('#app').innerHTML = html`<div class="shell"><aside class="side" aria-label="Navegación principal"><div class="brand">${brandMark()}</div><nav>${items.map(([p, t]) => html`<a href="#${p}" data-nav="${p}">${t}</a>`)}</nav><div class="who">${state.user.display_name}<br><button type="button" data-action="logout">Cerrar sesión</button></div></aside>
    <div><div class="topbar"><a class="bell" href="#/notifications" aria-label="Notificaciones">🔔<b id="unread" hidden></b></a><a class="bell" href="#/account">Mi cuenta</a></div><main id="main" class="main" tabindex="-1"></main></div>
    <nav class="tabbar" aria-label="Navegación móvil">${items.slice(0, 4).map(([p, t]) => html`<a href="#${p}" data-nav="${p}">${t}</a>`)}<button type="button" data-action="menu">Más</button></nav></div>`.s;
  $('.side nav').addEventListener('click', () => $('.side').classList.remove('open'));
}
const mount = (safe) => { const m = $('#main'); if (!m) return; m.innerHTML = safe.s; $('h1', m)?.setAttribute('tabindex', '-1'); window.scrollTo(0, 0); refreshUnread(); };
function markNav() {
  const p = here(); const items = navItems().map(([x]) => x).sort((a, b) => b.length - a.length); const cur = items.find((x) => (x === '/' ? p === '/' : p === x || p.startsWith(x + '/')));
  $$('[data-nav]').forEach((a) => (a.dataset.nav === cur ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current')));
}
function setup() { clearRoutes(); registerShared(); const r = state.user.role; if (r === 'owner' || r === 'staff') registerAdmin(); else if (r === 'client') registerClient(); else registerVendor(); }
async function onRoute() {
  const path = here(); const authPaths = ['/login', '/forgot', '/reset', '/invite'];
  if (!state.user) { if (!authPaths.includes(path)) { location.replace('#/login'); return; } return renderAuth(path.slice(1)); }
  if (authPaths.includes(path)) { location.replace('#/'); return; }
  if (!$('#main.main')) renderShell();
  markNav(); await dispatch(mount);
}
window.addEventListener('hashchange', onRoute);

(async function boot() {
  try { const b = await get('/api/brand'); state.brand = b.brand ?? {}; state.locale = b.locale ?? {}; state.orgName = b.org_name; } catch { /* sin marca */ }
  applyBrand();
  try { state.user = (await get('/api/me')).user; if (state.user) setup(); } catch { state.user = null; }
  try { const t = JSON.parse(sessionStorage.getItem('pendingToast') ?? 'null'); sessionStorage.removeItem('pendingToast'); if (t && Date.now() - t.t < 4000) toast(t.msg, t.kind); } catch { /* sin almacenamiento */ }
  onRoute();
})();
void raw; void route;
