import { html, raw, state, get, post, put, route, actions, submits, modal, toast, confirmBox, field, table, empty, head, badge, kv, btn, tabs, L, EVENT_TYPES, money, fdate, fdt, fromMilli, toMilli } from './core.js';
import { documentsPanel, tasksPanel, timelinePanel, guestsPanel, changesPanel } from './shared.js';

const reload = () => location.reload();
const STEPS = [
  { t: 'Tipo de evento', f: [{ k: 'Tipo de evento', type: 'select', options: EVENT_TYPES }] },
  { t: 'Fechas tentativas', f: [{ k: 'Fecha tentativa 1', type: 'date' }, { k: 'Fecha tentativa 2', type: 'date' }, { k: 'Comentarios sobre fechas', type: 'textarea' }] },
  { t: 'Ciudad y ubicación aproximada', f: [{ k: 'Ciudad', type: 'text' }, { k: 'Zona o recinto en mente', type: 'text' }] },
  { t: 'Número estimado de invitados', f: [{ k: 'Invitados estimados', type: 'number' }] },
  { t: 'Presupuesto aproximado', f: [{ k: 'Presupuesto mínimo (MXN)', type: 'text' }, { k: 'Presupuesto máximo (MXN)', type: 'text' }] },
  { t: 'Estilo y temática', f: [{ k: 'Estilo', type: 'text' }, { k: 'Paleta de colores', type: 'text' }, { k: 'Describe la atmósfera que imaginas', type: 'textarea' }] },
  { t: 'Servicios que consideras necesarios', services: true },
  { t: 'Necesidades especiales', f: [{ k: 'Accesibilidad', type: 'textarea' }, { k: 'Restricciones alimentarias', type: 'textarea' }, { k: 'Otras necesidades', type: 'textarea' }] },
  { t: 'Referencias visuales', f: [{ k: 'Enlaces de inspiración', type: 'textarea' }], note: 'También puedes subir imágenes en la pestaña «Documentos».' },
  { t: 'Revisión y envío', review: true },
];
const firstEvent = async () => { const { events } = await get('/api/events'); return events[0]; };

export function registerClient() {
  route('/', async () => {
    const { events } = await get('/api/events');
    if (!events.length) return html`${head('Bienvenida', 'Vamos a construir tu evento paso a paso. Puedes guardar y continuar cuando quieras.')}<form data-submit="startEvent" class="block" novalidate>${field('name', 'Ponle nombre a tu evento', { required: true, placeholder: 'Boda de Ana y Luis' })}${field('type', 'Tipo de evento', { type: 'select', empty: false, options: EVENT_TYPES })}${field('event_date', 'Fecha tentativa (si ya la tienes)', { type: 'date' })}<button class="btn primary" type="submit">Comenzar</button><small class="err" data-err="_form" role="alert"></small></form>`;
    const cards = await Promise.all(events.map(async (e) => ({ e, p: (await get(`/api/events/${e.id}`)).progress })));
    return html`${head('Mis eventos', '', btn('startMore', 'Iniciar otro evento'))}<ul class="rows">${cards.map(({ e, p }) => html`<li><div><a class="t" href="#/events/${e.id}/overview">${e.name}</a><div class="m">${e.folio} · ${fdate(e.event_date)}</div></div><div>${badge(L.event, e.status)}</div></li>`)}</ul>`;
  });
  submits.startEvent = async (d) => { const e = await post('/api/my/events', d); toast('Evento creado'); location.hash = `#/events/${e.id}/wizard`; };
  actions.startMore = () => modal('Iniciar otro evento', html`${field('name', 'Nombre', { required: true })}${field('type', 'Tipo', { type: 'select', empty: false, options: EVENT_TYPES })}${field('event_date', 'Fecha tentativa', { type: 'date' })}`, async (d) => { const e = await post('/api/my/events', d); location.hash = `#/events/${e.id}/wizard`; }, { submit: 'Crear' });
  for (const [path, tab] of [['/quote', 'quote'], ['/requests', 'requests'], ['/payments', 'payments'], ['/tasks', 'tasks'], ['/guests', 'guests'], ['/timeline', 'timeline'], ['/documents', 'documents']])
    route(path, async () => { const e = await firstEvent(); location.replace(e ? `#/events/${e.id}/${tab}` : '#/'); return html``; });

  const TABS = [['overview', 'Resumen'], ['wizard', 'Tu información'], ['catalog', 'Catálogo'], ['requests', 'Mis solicitudes'], ['quote', 'Presupuesto'], ['payments', 'Pagos'], ['documents', 'Documentos'], ['timeline', 'Cronograma'], ['guests', 'Invitados y mesas'], ['tasks', 'Tareas'], ['changes', 'Cambios']];
  route('/events/:id', ({ id }) => { location.replace(`#/events/${id}/overview`); return html``; });
  route('/events/:id/:tab', async ({ id, tab }) => {
    const { event: e, progress } = await get(`/api/events/${id}`);
    const panels = { overview: () => overview(e, progress), wizard: () => wizard(e), catalog: () => catalog(e), requests: () => requests(e), quote: () => quote(e), payments: () => payments(e), documents: () => documentsPanel(id, { upload: true }), timeline: () => timelinePanel(id), guests: () => guestsPanel(id), tasks: () => tasksPanel(id), changes: () => changesPanel(id) };
    return html`${head(e.name, html`${e.folio} · ${fdate(e.event_date)} · ${badge(L.event, e.status)}`)}${tabs(`/events/${id}`, TABS, tab)}${await (panels[tab] ?? panels.overview)()}`;
  });

  async function overview(e, progress) {
    const [{ requests: reqs }, { tasks }, bal] = await Promise.all([get(`/api/events/${e.id}/requests`), get(`/api/events/${e.id}/tasks`), get(`/api/events/${e.id}/balance`)]);
    const steps = [];
    if (!e.brief_submitted_at) steps.push(['Completa y envía la información de tu evento', `#/events/${e.id}/wizard`]);
    if (reqs.some((r) => r.status === 'quote_sent')) steps.push(['Tienes una propuesta esperando tu respuesta', `#/events/${e.id}/quote`]);
    for (const r of reqs.filter((x) => x.status === 'info_required')) steps.push([`Tu planner necesita información sobre «${r.service_name}»`, `#/events/${e.id}/requests`]);
    for (const t of tasks.filter((x) => x.status !== 'completed').slice(0, 4)) steps.push([`Tarea: ${t.title}${t.due_date ? ` (para el ${fdate(t.due_date)})` : ''}`, `#/events/${e.id}/tasks`]);
    return html`<div class="grid2"><section class="block"><h2>Próximos pasos</h2>${steps.length ? html`<ul class="rows">${steps.map(([t, h]) => html`<li><a href="${h}">${t}</a></li>`)}</ul>` : html`<p class="m">Por ahora no tienes pasos pendientes. Te avisaremos cuando haya novedades.</p>`}</section>
      <section class="block"><h2>Avance</h2>${progress.percent !== null ? html`<progress value="${progress.percent}" max="100" aria-label="Avance de tus tareas"></progress><p class="m">${progress.tasks_done} de ${progress.tasks_total} tareas completadas</p>` : html`<p class="m">Aún no hay tareas asignadas a ti.</p>`}${kv([['Servicios en tu proyecto', reqs.filter((r) => !['cancelled', 'rejected'].includes(r.status)).length], ['Confirmados', reqs.filter((r) => ['confirmed', 'contracted', 'completed'].includes(r.status)).length], ['Presupuesto aprobado', bal.accepted_version ? money(bal.contracted_cents) : 'Aún sin aprobar'], ['Saldo pendiente', bal.accepted_version ? money(bal.balance_cents) : '—']])}</section></div>
      ${e.notes_client ? html`<p class="note">${e.notes_client}</p>` : ''}`;
  }

  // ───── Asistente guiado: guarda el progreso en cada paso ─────
  async function wizard(e) {
    const brief = JSON.parse(e.brief || '{}'); const step = Math.min(Math.max(Number(new URLSearchParams(location.hash.split('?')[1] ?? '').get('step') ?? e.brief_step ?? 0), 0), 9); const def = STEPS[step];
    const prev = step > 0 ? html`<a class="btn secondary" href="#/events/${e.id}/wizard?step=${step - 1}">Atrás</a>` : '';
    let body;
    if (def.review) body = html`<p>Revisa lo que nos compartiste. Puedes volver a cualquier paso antes de enviar.</p>${Object.keys(brief).length ? kv(Object.entries(brief).map(([k, v]) => [k, Array.isArray(v) ? v.join(', ') : v])) : html`<p class="m">Aún no hay información. Completa los pasos anteriores.</p>`}${e.brief_submitted_at ? html`<p class="note">Enviaste tu información el ${fdt(e.brief_submitted_at)}. Puedes actualizarla y volver a enviarla.</p>` : ''}`;
    else if (def.services) { const { categories } = await get('/api/catalog'); const sel = brief['Servicios de interés'] ?? []; body = html`<fieldset class="fieldset"><legend>Selecciona lo que te interesa</legend><div class="checks">${categories.map((c, i) => html`<div class="field check"><input type="checkbox" id="sv${i}" name="services" value="${c.name}" ${raw(sel.includes(c.name) ? 'checked' : '')}><label for="sv${i}">${c.name}</label></div>`)}</div></fieldset>`; }
    else body = html`${def.f.map((x, i) => field(`q${i}`, x.k, { type: x.type, options: x.options, value: brief[x.k] ?? '', rows: 3 }))}${def.note ? html`<p class="hint">${def.note}</p>` : ''}`;
    return html`<section class="block"><p class="m">Paso ${step + 1} de 10</p><progress value="${step + 1}" max="10" aria-label="Progreso del asistente"></progress><h2>${def.t}</h2>
      <form data-submit="saveStep" data-event="${e.id}" data-step="${step}" novalidate>${body}<div class="head-actions">${prev}<button class="btn secondary" type="button" data-action="exitWizard">Guardar y salir</button><button class="btn primary" type="submit" data-final="${def.review ? '1' : ''}">${def.review ? 'Enviar a mi planner' : 'Guardar y continuar'}</button></div><small class="err" data-err="_form" role="alert"></small></form></section>`;
  }
  submits.saveStep = async (d, f) => {
    const step = Number(f.dataset.step); const def = STEPS[step]; const { event: e } = await get(`/api/events/${f.dataset.event}`); const brief = JSON.parse(e.brief || '{}');
    if (def.services) brief['Servicios de interés'] = d.services ?? []; else if (def.f) def.f.forEach((x, i) => { if (d[`q${i}`] !== undefined) brief[x.k] = d[`q${i}`]; else delete brief[x.k]; });
    const final = !!def.review; const exit = f.dataset.exit === '1';
    await put(`/api/events/${e.id}/brief`, { data: JSON.stringify(brief) === '{}' ? {} : brief, step: Math.min(final ? 9 : step + 1, 9), submit: final });
    if (final) { toast('Información enviada a tu planner'); location.hash = `#/events/${e.id}/overview`; } else if (exit) { toast('Progreso guardado'); location.hash = `#/events/${e.id}/overview`; } else location.hash = `#/events/${e.id}/wizard?step=${step + 1}`;
  };

  actions.exitWizard = (el) => { const f = el.closest('form'); f.dataset.exit = '1'; f.requestSubmit(); };

  // ───── Catálogo ─────
  async function catalog(e) {
    const q = new URLSearchParams(location.hash.split('?')[1] ?? ''); const p = new URLSearchParams(); if (q.get('q')) p.set('q', q.get('q')); if (q.get('category')) p.set('category', q.get('category'));
    const { categories, services } = await get(`/api/catalog?${p}`);
    return html`<section class="block"><h2>Catálogo de servicios</h2><p class="note">Los precios mostrados son de referencia. Tu planner te enviará una propuesta formal; nada se contrata hasta que la apruebes y se confirme la disponibilidad.</p>
      <form data-submit="filterCat" data-event="${e.id}" class="inline" role="search">${field('q', 'Buscar', { value: q.get('q') ?? '' })}${field('category', 'Categoría', { type: 'select', value: q.get('category') ?? '', options: categories.map((c) => [c.id, c.name]) })}<button class="btn secondary" type="submit">Filtrar</button></form>
      ${services.length ? html`<ul class="rows">${services.map((s) => html`<li><div><span class="t">${s.name}</span><div class="m">${s.description ?? ''}</div><div class="m">${s.base_price_cents != null && s.price_type !== 'quote' ? `Desde ${money(s.base_price_cents)} · ${L.priceType[s.price_type]}` : L.priceType[s.price_type]}${s.packages.length ? ` · ${s.packages.length} paquete(s)` : ''}</div></div>${btn('addSvc', 'Agregar a mi proyecto', { event: e.id, id: s.id, name: s.name, min: s.min_qty_milli, unit: s.unit_label ?? '', pk: JSON.stringify(s.packages) }, 'primary sm')}</li>`)}</ul>` : empty('No hay servicios con estos filtros')}</section>`;
  }
  submits.filterCat = (d, f) => { location.hash = `#/events/${f.dataset.event}/catalog?${new URLSearchParams(d)}`; };
  actions.addSvc = (el) => { const pk = JSON.parse(el.dataset.pk); modal(`Agregar «${el.dataset.name}»`, html`${pk.length ? field('package_id', 'Paquete', { type: 'select', options: pk.map((p) => [p.id, `${p.name} — ${money(p.price_cents)}`]) }) : ''}${field('qty', `Cantidad${el.dataset.unit ? ` (${el.dataset.unit})` : ''}`, { type: 'number', value: fromMilli(Number(el.dataset.min)), step: 'any', required: true })}${field('client_notes', 'Comentarios para tu planner', { type: 'textarea' })}`, async (d) => { await post(`/api/events/${el.dataset.event}/requests`, { service_id: el.dataset.id, package_id: d.package_id, qty_milli: toMilli(d.qty), client_notes: d.client_notes }); toast('Solicitud enviada a tu planner'); location.hash = `#/events/${el.dataset.event}/requests`; }, { submit: 'Enviar solicitud' }); };

  async function requests(e) {
    const { requests: rs } = await get(`/api/events/${e.id}/requests`); const can = ['draft', 'requested', 'in_review', 'info_required', 'quote_preparing', 'quote_sent'];
    return html`<section class="block"><h2>Mis solicitudes</h2>${table([{ label: 'Servicio', render: (r) => html`<b>${r.service_name}</b>${r.package_name ? html` · ${r.package_name}` : ''}<div class="m">${r.client_notes ?? ''}</div>${r.planner_message ? html`<div class="note">Mensaje de tu planner: ${r.planner_message}</div>` : ''}` }, { label: 'Cantidad', render: (r) => `${fromMilli(r.qty_milli)} ${r.unit_label ?? ''}` }, { label: 'Estado', render: (r) => badge(L.request, r.status) }, { label: '', render: (r) => (can.includes(r.status) ? btn('cancelReq', 'Retirar', { id: r.id }, 'secondary sm') : '') }], rs, 'Aún no has solicitado servicios. Explora el catálogo.')}
      <p class="m">«Aprobado por ti» no significa «contratado»: tu planner debe confirmar la disponibilidad con el proveedor.</p></section>`;
  }
  actions.cancelReq = async (el) => { if (!(await confirmBox('¿Retirar esta solicitud?', 'Retirar'))) return; await post(`/api/requests/${el.dataset.id}/status`, { to: 'cancelled' }); reload(); };

  async function quote(e) {
    const { versions } = await get(`/api/events/${e.id}/quote`); const latest = versions[0];
    return html`<section class="block"><h2>Presupuesto y propuestas</h2>${versions.length ? versions.map((v) => html`<div class="block"><h3>Propuesta ${v.version} ${v.status === 'accepted' ? raw('<span class="badge s-accepted">Aprobada por ti</span>') : badge(L.quote, v.status)}</h3>
      ${table([{ label: 'Concepto', render: (i) => i.description }, { label: 'Cantidad', render: (i) => fromMilli(i.qty_milli) }, { label: 'Precio unitario', render: (i) => money(i.unit_price_cents) }, { label: 'Descuento', render: (i) => money(i.discount_cents) }, { label: 'Total con IVA', render: (i) => money(i.line_total_cents) }], v.items)}
      ${kv([['Subtotal', money(v.subtotal_cents)], ['Descuentos', money(v.discount_cents)], ['Cargos adicionales', v.charges_cents ? `${money(v.charges_cents)}${v.charges_note ? ` (${v.charges_note})` : ''}` : '—'], ['IVA', money(v.tax_cents)], ['Total', html`<b>${money(v.total_cents)}</b>`], ['Anticipo requerido', money(v.advance_cents)]])}${v.note ? html`<p class="note">${v.note}</p>` : ''}
      ${v.id === latest.id && v.status === 'sent' ? html`<div class="head-actions">${btn('respondQuote', 'Aprobar propuesta', { event: e.id, v: v.version, ok: '1' }, 'primary')}${btn('respondQuote', 'No estoy de acuerdo', { event: e.id, v: v.version, ok: '' }, 'secondary')}</div>` : ''}</div>`) : empty('Todavía no tienes una propuesta', 'Cuando tu planner la prepare, te avisaremos.')}</section>`;
  }
  actions.respondQuote = (el) => {
    if (el.dataset.ok) return confirmBox('Al aprobar aceptas esta propuesta de precios. La contratación definitiva se confirma cuando tu planner verifique la disponibilidad de cada proveedor.', 'Aprobar propuesta').then(async (ok) => { if (!ok) return; await post(`/api/events/${el.dataset.event}/quote/respond`, { version: Number(el.dataset.v), accept: true }); toast('Propuesta aprobada'); reload(); });
    modal('Rechazar propuesta', field('reason', 'Cuéntanos qué te gustaría cambiar', { type: 'textarea' }), async (d) => { await post(`/api/events/${el.dataset.event}/quote/respond`, { version: Number(el.dataset.v), accept: false, reason: d.reason }); reload(); }, { submit: 'Enviar' });
  };

  async function payments(e) {
    const [bal, { payments: ps }] = await Promise.all([get(`/api/events/${e.id}/balance`), get(`/api/events/${e.id}/payments`)]);
    return html`<section class="block"><h2>Pagos</h2>${kv([['Total aprobado', bal.accepted_version ? money(bal.contracted_cents) : 'Aún sin propuesta aprobada'], ['Pagado', money(bal.paid_cents)], ['Saldo pendiente', bal.accepted_version ? html`<b>${money(bal.balance_cents)}</b>` : '—'], ['Anticipo requerido', bal.advance_cents ? money(bal.advance_cents) : '—']])}
      ${table([{ label: 'Concepto', render: (p) => p.concept ?? 'Pago' }, { label: 'Importe', render: (p) => money(p.amount_cents) }, { label: 'Pagado', render: (p) => money(p.paid_cents) }, { label: 'Vence', render: (p) => fdate(p.due_date) }, { label: 'Estado', render: (p) => badge(L.payment, p.status) }], ps, 'Aún no hay pagos programados')}<p class="m">Los pagos se registran por tu planner; recibirás confirmación cuando se aplique cada uno.</p></section>`;
  }
}
