// Mini-framework sin dependencias: plantillas con escape automático, API, formularios, modales, enrutador.
export class Safe { constructor(s) { this.s = s; } }
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const rend = (v) => (v instanceof Safe ? v.s : Array.isArray(v) ? v.map(rend).join('') : v == null || v === false ? '' : esc(v));
export const html = (strings, ...vals) => new Safe(strings.reduce((o, s, i) => o + s + (i < vals.length ? rend(vals[i]) : ''), ''));
export const raw = (s) => new Safe(s);
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export const state = { user: null, brand: {}, locale: {}, unread: 0 };
export const can = (p) => !!state.user && (state.user.permissions.includes('*') || state.user.permissions.includes(p));

// ───── API ─────
export class ApiError extends Error { constructor(status, body) { super(body?.error?.message ?? 'Error de conexión'); this.status = status; this.details = body?.error?.details; this.code = body?.error?.code; } }
export async function api(method, path, body) {
  let res;
  try { res = await fetch(path, { method, headers: { 'x-requested-with': 'fetch', ...(body !== undefined ? { 'content-type': 'application/json' } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined, credentials: 'same-origin' }); }
  catch { throw new ApiError(0, { error: { message: 'Sin conexión con el servidor. Revisa tu internet e inténtalo de nuevo.' } }); }
  const text = await res.text(); let data = {}; try { data = text ? JSON.parse(text) : {}; } catch { data = {}; }
  if (res.status === 401 && state.user && !path.startsWith('/api/auth/')) { state.user = null; location.hash = '#/login'; }
  if (!res.ok) throw new ApiError(res.status, data);
  return data;
}
export const get = (p) => api('GET', p); export const post = (p, b = {}) => api('POST', p, b);
export const patch = (p, b) => api('PATCH', p, b); export const put = (p, b) => api('PUT', p, b);

// ───── Formato ─────
export const money = (c, cur = 'MXN') => new Intl.NumberFormat('es-MX', { style: 'currency', currency: cur }).format((c ?? 0) / 100);
export const fdate = (d) => (d && /^\d{4}-\d{2}-\d{2}/.test(d) ? `${d.slice(8, 10)}/${d.slice(5, 7)}/${d.slice(0, 4)}` : d || '—');
export const fdt = (iso) => (iso ? new Date(iso).toLocaleString('es-MX', { dateStyle: 'short', timeStyle: 'short' }) : '—');
export const parseMoney = (s) => { const t = String(s).replace(/[$\s,]/g, ''); if (!/^-?\d+(\.\d{1,2})?$/.test(t)) throw new Error('Importe inválido (ej. 1,250.50)'); return Math.round(parseFloat(t) * 100); };
export const toMilli = (s) => { const n = Number(String(s).replace(',', '.')); if (!Number.isFinite(n) || n <= 0) throw new Error('Cantidad inválida'); return Math.round(n * 1000); };
export const fromMilli = (m) => (m % 1000 === 0 ? String(m / 1000) : (m / 1000).toFixed(3).replace(/0+$/, ''));
export const uuid = () => crypto.randomUUID();

// ───── Etiquetas (los estados siempre se muestran con texto, no solo con color) ─────
export const L = {
  event: { prospect: 'Prospecto', initial_consult: 'Consulta inicial', preparing: 'En preparación', proposal_drafting: 'Propuesta en elaboración', proposal_sent: 'Propuesta enviada', pending_approval: 'Pendiente de aprobación', contracted: 'Contratado', planning: 'En planificación', confirmed: 'Confirmado', in_execution: 'En ejecución', finished: 'Finalizado', closed: 'Cerrado administrativamente', cancelled: 'Cancelado', archived: 'Archivado' },
  request: { draft: 'Borrador', requested: 'Solicitado', in_review: 'En revisión', info_required: 'Información adicional requerida', quote_preparing: 'Cotización en preparación', quote_sent: 'Cotización enviada — pendiente de tu respuesta', client_approved: 'Aprobado por el cliente (pendiente de confirmar disponibilidad)', pending_vendor: 'Pendiente de confirmación del proveedor', confirmed: 'Confirmado', contracted: 'Contratado', rejected: 'Rechazado', cancelled: 'Cancelado', completed: 'Completado' },
  assignment: { requested: 'Solicitud pendiente', accepted: 'Aceptada (por confirmar)', rejected: 'Rechazada', confirmed: 'Confirmada', completed: 'Completada', cancelled: 'Cancelada' },
  payment: { pending: 'Pendiente', scheduled: 'Programado', in_review: 'En revisión', paid: 'Pagado', partially_paid: 'Parcialmente pagado', overdue: 'Vencido', refunded: 'Reembolsado', cancelled: 'Cancelado' },
  task: { pending: 'Pendiente', in_progress: 'En proceso', blocked: 'Bloqueada', completed: 'Completada', cancelled: 'Cancelada' },
  vendor: { prospect: 'Prospecto', evaluating: 'En evaluación', docs_pending: 'Documentación pendiente', approved: 'Aprobado', active: 'Activo', suspended: 'Suspendido', inactive: 'Inactivo', temporarily_unavailable: 'No disponible temporalmente' },
  priceType: { fixed: 'Precio fijo', per_person: 'Por persona', per_hour: 'Por hora', per_day: 'Por día', per_unit: 'Por unidad', per_meter: 'Por metro', per_package: 'Por paquete', custom: 'Personalizado', quote: 'Sujeto a cotización' },
  guest: { pending: 'Pendiente', invited: 'Invitación enviada', confirmed: 'Confirmado', declined: 'Rechazado', no_response: 'Sin respuesta', waitlist: 'En lista de espera', attended: 'Asistió', no_show: 'No asistió' },
  severity: { low: 'Baja', medium: 'Media', high: 'Alta', critical: 'Crítica' }, incident: { open: 'Abierta', in_progress: 'En proceso', resolved: 'Resuelta' },
  change: { pending: 'Pendiente', approved: 'Aprobada', rejected: 'Rechazada' }, quote: { sent: 'Enviada', accepted: 'Aceptada', rejected: 'Rechazada', superseded: 'Reemplazada', draft: 'Borrador' },
  eventType: { boda: 'Boda', xv: 'XV años', 'cumpleaños': 'Cumpleaños', aniversario: 'Aniversario', bautizo: 'Bautizo', graduacion: 'Graduación', corporativo: 'Evento empresarial', congreso: 'Congreso', lanzamiento: 'Lanzamiento de marca', privado: 'Evento privado', otro: 'Otro' },
  phase: { prep: 'Preparación', exec: 'Ejecución', teardown: 'Desmontaje' },
};
export const EVENT_TYPES = Object.entries(L.eventType);
export const badge = (map, key) => html`<span class="badge s-${key}">${map[key] ?? key}</span>`;

// ───── Componentes de formulario ─────
export function field(name, label, o = {}) {
  const id = `f-${name}`; const req = o.required ? ' required' : ''; const val = o.value ?? '';
  const common = `id="${id}" name="${name}"${req}${o.t ? ` data-t="${o.t}"` : ''}${o.hint ? ` aria-describedby="${id}-h"` : ''}${o.placeholder ? ` placeholder="${esc(o.placeholder)}"` : ''}`;
  let control;
  if (o.type === 'textarea') control = raw(`<textarea ${common} rows="${o.rows ?? 3}" maxlength="${o.max ?? 2000}">${esc(val)}</textarea>`);
  else if (o.type === 'select') control = raw(`<select ${common}>${o.empty !== false ? '<option value="">—</option>' : ''}${(o.options ?? []).map(([v, t]) => `<option value="${esc(v)}"${String(v) === String(val) ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select>`);
  else if (o.type === 'checkbox') return html`<div class="field check"><input type="checkbox" ${raw(common)} data-t="bool"${raw(o.checked ? ' checked' : '')}><label for="${id}">${label}</label><small class="err" data-err="${name}" role="alert"></small></div>`;
  else control = raw(`<input ${common} type="${o.type ?? 'text'}" value="${esc(val)}"${o.min !== undefined ? ` min="${o.min}"` : ''}${o.step ? ` step="${o.step}"` : ''}${o.type === 'number' ? ' inputmode="decimal"' : ''}${o.autocomplete ? ` autocomplete="${o.autocomplete}"` : ''}>`);
  return html`<div class="field"><label for="${id}">${label}${o.required ? raw('<span class="req" aria-hidden="true"> *</span>') : ''}</label>${control}${o.hint ? html`<small id="${id}-h" class="hint">${o.hint}</small>` : ''}<small class="err" data-err="${name}" role="alert"></small></div>`;
}
export function collect(form) {
  const out = {};
  for (const el of form.elements) {
    if (!el.name || el.disabled || el.tagName === 'BUTTON' || el.type === 'file') continue;
    const t = el.dataset.t;
    if (el.type === 'checkbox') { if (t === 'bool') out[el.name] = el.checked; else if (el.checked) (out[el.name] ||= []).push(el.value); continue; }
    const v = String(el.value).trim(); if (v === '') continue;
    try { out[el.name] = t === 'money' ? parseMoney(v) : t === 'qty' ? toMilli(v) : t === 'int' ? parseInt(v, 10) : v; }
    catch (e) { throw Object.assign(new Error(e.message), { field: el.name }); }
  }
  return out;
}
function showErrors(form, details, msg) {
  $$('.err', form).forEach((e) => (e.textContent = '')); $$('[aria-invalid]', form).forEach((e) => e.removeAttribute('aria-invalid'));
  let first = null;
  for (const [k, m] of Object.entries(details ?? {})) { const s = $(`[data-err="${k}"]`, form); if (s) { s.textContent = m; const i = $(`[name="${k}"]`, form); i?.setAttribute('aria-invalid', 'true'); first ||= i; } }
  first?.focus(); return !!first || !msg;
}

// ───── Toast, modal, confirmación ─────
export function toast(msg, kind = 'ok') {
  const box = $('#toasts'); const t = document.createElement('div'); t.className = `toast ${kind}`; t.textContent = msg; box.append(t);
  try { sessionStorage.setItem('pendingToast', JSON.stringify({ msg, kind, t: Date.now() })); } catch { /* sin almacenamiento */ }
  setTimeout(() => { t.remove(); try { sessionStorage.removeItem('pendingToast'); } catch { /* */ } }, kind === 'err' ? 7000 : 3500);
}
const handlers = new WeakMap(); export const actions = {}; export const submits = {};
export function modal(title, body, onSubmit, o = {}) {
  const d = document.createElement('dialog'); d.className = 'modal'; d.setAttribute('aria-labelledby', 'mt');
  d.innerHTML = `<form method="dialog" novalidate><header><h2 id="mt">${esc(title)}</h2><button type="button" class="btn ghost" data-close aria-label="Cerrar">✕</button></header><div class="body">${body.s ?? esc(body)}</div><footer><small class="err form-err" role="alert" data-err="_form"></small><button type="button" class="btn secondary" data-close>Cancelar</button>${onSubmit ? `<button class="btn primary" type="submit">${esc(o.submit ?? 'Guardar')}</button>` : ''}</footer></form>`;
  document.body.append(d); const form = $('form', d);
  d.addEventListener('close', () => d.remove());
  if (onSubmit) handlers.set(form, async (data) => { await onSubmit(data, form); d.close(); });
  d.showModal(); $('input:not([type=hidden]),select,textarea', d)?.focus(); return d;
}
export const confirmBox = (msg, label = 'Confirmar') => new Promise((res) => {
  const d = modal('Confirmación', html`<p>${msg}</p>`, null); const f = $('footer', d); const b = document.createElement('button'); b.className = 'btn danger'; b.type = 'button'; b.textContent = label; f.append(b);
  b.addEventListener('click', () => { res(true); d.close(); }); d.addEventListener('close', () => res(false));
});

// ───── Delegación de eventos (sin manejadores en línea: CSP estricta) ─────
async function guard(fn, form) {
  const btn = form ? $('button[type=submit]', form) : null; if (btn) btn.disabled = true;
  try { return await fn(); }
  catch (e) {
    const known = e instanceof ApiError || e.field !== undefined;
    if (!known) console.error(e);
    const msg = known ? e.message : 'Ocurrió un error inesperado. Inténtalo de nuevo.';
    const slot = form && $('[data-err="_form"]', form);
    if (form) showErrors(form, e.field ? { [e.field]: e.message } : e.details, msg);
    if (slot) slot.textContent = msg; else toast(msg, 'err');
  } finally { if (btn) btn.disabled = false; }
}
document.addEventListener('click', (e) => {
  const c = e.target.closest('[data-close]'); if (c) { c.closest('dialog')?.close(); return; }
  const t = e.target.closest('[data-action]'); if (!t) return; e.preventDefault();
  const fn = actions[t.dataset.action]; if (fn) guard(() => fn(t, e));
});
document.addEventListener('submit', (e) => {
  const f = e.target; if (!(f instanceof HTMLFormElement)) return;
  const fn = handlers.get(f) ?? submits[f.dataset.submit]; if (!fn) return; e.preventDefault();
  guard(async () => { showErrors(f, {}, ''); const msg = $('[data-err="_form"]', f); if (msg) msg.textContent = ''; await fn(collect(f), f); }, f);
});

// ───── Enrutador ─────
const routes = [];
export const route = (pattern, handler) => { const keys = []; const re = new RegExp('^' + pattern.replace(/:([a-z]+)/g, (_m, k) => { keys.push(k); return '([^/]+)'; }) + '$'); routes.push({ re, keys, handler }); };
export const query = () => new URLSearchParams((location.hash.split('?')[1] ?? ''));
export const here = () => location.hash.slice(1).split('?')[0] || '/';
let rendering = 0;
export async function dispatch(mount) {
  const path = here(); const r = routes.find((x) => x.re.test(path));
  const id = ++rendering; mount(html`<div class="skeleton" aria-busy="true"><span class="sr">Cargando…</span></div>`);
  if (!r) return mount(html`<div class="empty"><h2>No encontramos esta página</h2><p><a href="#/">Volver al inicio</a></p></div>`);
  const m = path.match(r.re); const params = {}; r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
  try { const out = await r.handler(params); if (id === rendering) mount(out); }
  catch (e) { if (id !== rendering) return; mount(html`<div class="empty" role="alert"><h2>${e.status === 404 ? 'No encontramos lo que buscas' : e.status === 403 ? 'No tienes acceso a esta sección' : 'No pudimos cargar esta sección'}</h2><p>${e.message}</p><button class="btn secondary" data-action="reload">Reintentar</button></div>`); }
}
actions.reload = () => location.reload();

// ───── Piezas de UI reutilizables ─────
export const empty = (title, text = '') => html`<div class="empty"><h3>${title}</h3>${text ? html`<p>${text}</p>` : ''}</div>`;
export function table(cols, rows, emptyMsg = 'Sin resultados') {
  if (!rows.length) return empty(emptyMsg);
  return html`<div class="tablewrap"><table class="table"><thead><tr>${cols.map((c) => html`<th scope="col">${c.label}</th>`)}</tr></thead><tbody>${rows.map((r) => html`<tr>${cols.map((c) => html`<td data-label="${c.label}">${c.render(r)}</td>`)}</tr>`)}</tbody></table></div>`;
}
export const kv = (pairs) => html`<dl class="kv">${pairs.filter((p) => p).map(([k, v]) => html`<div><dt>${k}</dt><dd>${v ?? '—'}</dd></div>`)}</dl>`;
export const head = (title, sub, actionsHtml) => html`<header class="page-head"><div><h1>${title}</h1>${sub ? html`<p class="sub">${sub}</p>` : ''}</div>${actionsHtml ? html`<div class="head-actions">${actionsHtml}</div>` : ''}</header>`;
export const tabs = (base, list, cur) => html`<nav class="tabs" aria-label="Secciones del evento">${list.map(([k, t]) => html`<a href="#${base}/${k}" ${raw(k === cur ? 'aria-current="page"' : '')}>${t}</a>`)}</nav>`;
export const btn = (action, label, data = {}, cls = 'secondary') => html`<button type="button" class="btn ${cls}" data-action="${action}" ${raw(Object.entries(data).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' '))}>${label}</button>`;
export function fileToBase64(file) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = () => rej(new Error('No se pudo leer el archivo')); r.readAsDataURL(file); }); }
export function calendar(ym, itemsByDate, linkFor) {
  const [Y, M] = ym.split('-').map(Number); const first = new Date(Date.UTC(Y, M - 1, 1)); const start = (first.getUTCDay() + 6) % 7; const days = new Date(Date.UTC(Y, M, 0)).getUTCDate();
  const cells = []; for (let i = 0; i < start; i++) cells.push(null); for (let d = 1; d <= days; d++) cells.push(d); while (cells.length % 7) cells.push(null);
  const names = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  return html`<div class="cal" role="grid" aria-label="Calendario ${ym}">${names.map((n) => html`<div class="cal-h" role="columnheader">${n}</div>`)}${cells.map((d) => { if (!d) return html`<div class="cal-c off"></div>`; const key = `${ym}-${String(d).padStart(2, '0')}`; const its = itemsByDate[key] ?? []; return html`<div class="cal-c ${its.length ? 'has' : ''}" role="gridcell"><span class="cal-d">${d}</span>${its.slice(0, 3).map((i) => html`<a class="cal-i" href="${linkFor(i)}">${i.label}</a>`)}${its.length > 3 ? html`<span class="more">+${its.length - 3} más</span>` : ''}</div>`; })}</div>`;
}
export const shiftMonth = (ym, n) => { const [Y, M] = ym.split('-').map(Number); const d = new Date(Date.UTC(Y, M - 1 + n, 1)); return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`; };
export const clearRoutes = () => { routes.length = 0; };
