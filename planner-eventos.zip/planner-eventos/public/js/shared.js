import { html, raw, $, state, can, get, post, patch, put, api, route, actions, submits, modal, toast, confirmBox, field, table, empty, head, badge, kv, btn, L, fdate, fdt, money, fileToBase64, query } from './core.js';

// ───── Notificaciones ─────
export function registerShared() {
  route('/notifications', async () => {
    const { notifications } = await get('/api/notifications');
    return html`${head('Notificaciones', 'Avisos de tus eventos y servicios', btn('readAll', 'Marcar todo como leído'))}
      ${notifications.length ? html`<ul class="rows">${notifications.map((n) => html`<li><div><div class="t">${n.read_at ? '' : raw('<span class="badge s-info">Nueva</span> ')}${n.priority === 'high' ? raw('<span class="badge s-high">Prioritaria</span> ') : ''}${n.link ? html`<a href="${n.link}" data-action="readOne" data-id="${n.id}">${n.title}</a>` : n.title}</div>${n.body ? html`<div class="m">${n.body}</div>` : ''}</div><time class="m">${fdt(n.created_at)}</time></li>`)}</ul>` : empty('Sin notificaciones', 'Cuando haya novedades aparecerán aquí.')}`;
  });
  actions.readAll = async () => { await post('/api/notifications/read', { all: true }); await refreshUnread(); location.reload(); };
  actions.readOne = async (el) => { await post('/api/notifications/read', { ids: [el.dataset.id] }); location.hash = el.getAttribute('href'); };

  // ───── Mensajes (siempre con la planner) ─────
  route('/messages', async () => {
    const { conversations } = await get('/api/conversations'); const staff = state.user.role === 'owner' || state.user.role === 'staff';
    return html`${head('Mensajes', staff ? 'Conversaciones con clientes y proveedores' : 'Tu comunicación con tu planner', staff ? '' : btn('newConv', 'Nuevo mensaje', {}, 'primary'))}
      ${conversations.length ? html`<ul class="rows">${conversations.map((c) => html`<li><div><a class="t" href="#/messages/${c.id}">${c.subject}</a><div class="m">${staff ? `${c.participant_name} · ` : ''}${c.folio ?? 'General'}</div></div><time class="m">${fdate(c.created_at)}</time></li>`)}</ul>` : empty('Aún no hay conversaciones', staff ? 'Escribe desde el detalle de un evento.' : 'Escribe a tu planner para resolver cualquier duda.')}
      <p class="note">Toda la comunicación pasa por tu planner. La plataforma no ofrece mensajes directos entre clientes y proveedores.</p>`;
  });
  route('/messages/:id', async ({ id }) => {
    const { conversation, messages } = await get(`/api/conversations/${id}/messages`);
    return html`${head(conversation.subject, '', html`<a class="btn secondary" href="#/messages">Volver</a>`)}
      <div class="chat" aria-live="polite">${messages.map((m) => html`<div class="msg ${m.author_id === state.user.id ? 'mine' : ''}"><small>${fdt(m.created_at)}</small>${m.body}</div>`)}</div>
      <form data-submit="sendMsg" data-id="${id}" novalidate>${field('body', 'Escribe tu mensaje', { type: 'textarea', required: true, max: 4000 })}<button class="btn primary" type="submit">Enviar</button><small class="err" data-err="_form" role="alert"></small></form>`;
  });
  submits.sendMsg = async (d, f) => { await post(`/api/conversations/${f.dataset.id}/messages`, d); location.reload(); };
  actions.newConv = async () => {
    const evs = (await get('/api/events')).events;
    modal('Nuevo mensaje para tu planner', html`${field('subject', 'Asunto', { required: true })}${evs.length ? field('event_id', 'Evento relacionado', { type: 'select', options: evs.map((e) => [e.id, `${e.folio} · ${e.name}`]) }) : ''}${field('body', 'Mensaje', { type: 'textarea', required: true, max: 4000 })}`,
      async (d) => { const r = await post('/api/conversations', d); toast('Mensaje enviado'); location.hash = `#/messages/${r.id}`; }, { submit: 'Enviar' });
  };
  actions.msgUser = async (el) => {
    modal(`Mensaje para ${el.dataset.name}`, html`${field('subject', 'Asunto', { required: true })}${field('body', 'Mensaje', { type: 'textarea', required: true })}`,
      async (d) => { const r = await post('/api/conversations', { ...d, participant_user_id: el.dataset.user, event_id: el.dataset.event || undefined }); toast('Mensaje enviado'); location.hash = `#/messages/${r.id}`; }, { submit: 'Enviar' });
  };

  // ───── Cuenta ─────
  route('/account', async () => {
    const u = state.user;
    return html`${head('Mi cuenta', u.email)}
      <div class="grid2"><section class="block"><h2>Perfil y avisos</h2><form data-submit="saveProfile" novalidate>${field('display_name', 'Nombre', { value: u.display_name, required: true })}
        ${field('mute', 'Silenciar avisos no esenciales (los críticos siempre se envían)', { type: 'checkbox', checked: !!u.prefs.mute_noncritical })}<button class="btn primary" type="submit">Guardar</button><small class="err" data-err="_form" role="alert"></small></form></section>
      <section class="block"><h2>Cambiar contraseña</h2><form data-submit="changePw" novalidate>${field('current', 'Contraseña actual', { type: 'password', required: true, autocomplete: 'current-password' })}${field('next', 'Nueva contraseña', { type: 'password', required: true, autocomplete: 'new-password', hint: 'Mínimo 10 caracteres, con letras y números.' })}<button class="btn primary" type="submit">Cambiar contraseña</button><small class="err" data-err="_form" role="alert"></small></form></section></div>`;
  });
  submits.saveProfile = async (d) => { await patch('/api/me', { display_name: d.display_name, prefs: { mute_noncritical: !!d.mute } }); const me = await get('/api/me'); state.user = me.user; toast('Perfil actualizado'); };
  submits.changePw = async (d, f) => { await post('/api/me/password', d); f.reset(); toast('Contraseña actualizada'); };
}
export async function refreshUnread() { try { state.unread = (await get('/api/notifications')).unread; const b = $('#unread'); if (b) { b.textContent = state.unread || ''; b.hidden = !state.unread; } } catch { /* sin sesión */ } }

// ───── Paneles de evento compartidos (planner y cliente) ─────
export async function documentsPanel(eventId, { upload = true, staff = false } = {}) {
  const { documents } = await get(`/api/events/${eventId}/documents`);
  return html`<section class="block"><h2>Documentos</h2>
    ${table([{ label: 'Nombre', render: (d) => html`${d.name} <span class="m">v${d.version}</span>` }, { label: 'Tipo', render: (d) => d.kind }, ...(staff ? [{ label: 'Visible para', render: (d) => ({ internal: 'Solo planner', client: 'Cliente', vendor: 'Proveedores asignados' })[d.visibility] }] : []), { label: 'Fecha', render: (d) => fdate(d.created_at) }, { label: '', render: (d) => btn('dl', 'Descargar', { id: d.id }, 'secondary sm') }], documents, 'Aún no hay documentos')}
    ${upload ? html`<form data-submit="upDoc" data-event="${eventId}" class="fieldset" novalidate><legend>Subir documento (PDF, imagen, TXT o CSV, máx. 5 MB)</legend>
      <div class="inline"><div class="field"><label for="f-file">Archivo</label><input id="f-file" name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.txt,.csv" required></div>${field('kind', 'Tipo', { type: 'select', options: [['contrato', 'Contrato'], ['cotizacion', 'Cotización'], ['comprobante', 'Comprobante de pago'], ['referencia', 'Referencia visual'], ['menu', 'Menú'], ['plano', 'Plano'], ['otro', 'Otro']], empty: false })}
      ${staff ? field('visibility', 'Visible para', { type: 'select', empty: false, options: [['internal', 'Solo planner'], ['client', 'Cliente'], ['vendor', 'Proveedores asignados (selección abajo)']] }) : ''}</div>
      <button class="btn primary" type="submit">Subir</button><small class="err" data-err="_form" role="alert"></small></form>` : ''}</section>`;
}
actions.dl = async (el) => { const { url } = await post(`/api/documents/${el.dataset.id}/link`); location.href = url; };
submits.upDoc = async (d, f) => {
  const file = f.elements.file.files[0]; if (!file) throw Object.assign(new Error('Selecciona un archivo'), { field: 'file' });
  const mime = file.type || ({ pdf: 'application/pdf', csv: 'text/csv', txt: 'text/plain' })[file.name.split('.').pop().toLowerCase()] || '';
  const body = { name: file.name, kind: d.kind, mime, data_base64: await fileToBase64(file) };
  if (d.visibility) { body.visibility = d.visibility; if (d.visibility === 'vendor') { const as = (await get(`/api/events/${f.dataset.event}/assignments`)).assignments; body.vendor_ids = [...new Set(as.filter((a) => !['rejected', 'cancelled'].includes(a.status)).map((a) => a.vendor_id))]; } }
  await post(`/api/events/${f.dataset.event}/documents`, body); toast('Documento subido'); location.reload();
};

export async function tasksPanel(eventId, { staff = false } = {}) {
  const { tasks } = await get(`/api/events/${eventId}/tasks`);
  const sel = tasks.filter((t) => t.status !== 'cancelled');
  return html`<section class="block"><h2>Tareas ${staff ? btn('newTask', 'Nueva tarea', { event: eventId }, 'secondary sm') : ''}</h2>
    ${table([{ label: 'Tarea', render: (t) => html`<b>${t.title}</b>${t.description ? html`<div class="m">${t.description}</div>` : ''}` }, ...(staff ? [{ label: 'Para', render: (t) => ({ internal: 'Interna', client: 'Cliente', vendor: 'Proveedor' })[t.audience] }] : []), { label: 'Fecha límite', render: (t) => fdate(t.due_date) }, { label: 'Estado', render: (t) => badge(L.task, t.status) },
      { label: '', render: (t) => (t.status === 'completed' ? '' : btn('doneTask', 'Marcar completada', { id: t.id }, 'secondary sm')) }], sel, 'Sin tareas por ahora')}</section>`;
}
actions.doneTask = async (el) => { await post(`/api/tasks/${el.dataset.id}/status`, { to: 'completed' }); toast('Tarea completada'); location.reload(); };
actions.newTask = (el) => modal('Nueva tarea', html`${field('title', 'Título', { required: true })}${field('description', 'Descripción', { type: 'textarea' })}${field('due_date', 'Fecha límite', { type: 'date' })}${field('audience', 'Quién la ve', { type: 'select', empty: false, options: [['internal', 'Solo planner'], ['client', 'Cliente']] })}${field('priority', 'Prioridad', { type: 'select', empty: false, value: 'normal', options: [['low', 'Baja'], ['normal', 'Normal'], ['high', 'Alta'], ['urgent', 'Urgente']] })}`, async (d) => { await post(`/api/events/${el.dataset.event}/tasks`, d); toast('Tarea creada'); location.reload(); });

export async function timelinePanel(eventId, { staff = false } = {}) {
  const r = await get(`/api/events/${eventId}/timeline`);
  const byDay = {}; for (const i of r.items) (byDay[i.item_date] ||= []).push(i);
  return html`<section class="block"><h2>Cronograma ${staff ? btn('newTl', 'Agregar actividad', { event: eventId }, 'secondary sm') : ''}</h2>
    ${staff && r.alerts.length ? html`<div class="note warn" role="alert"><b>Conflictos detectados (tú decides cómo resolverlos):</b><ul>${r.alerts.map((a) => html`<li>${a.message}</li>`)}</ul></div>` : ''}
    ${r.items.length ? Object.entries(byDay).map(([d, its]) => html`<h3>${fdate(d)}</h3><ul class="rows">${its.map((i) => html`<li><div><span class="t">${i.start_time}–${i.end_time} · ${i.title}</span><div class="m">${[i.location, i.instructions].filter(Boolean).join(' · ')}</div></div>${staff ? html`<span>${i.locked ? raw('<span class="badge s-confirmed">Confirmada</span> ') : ''}${btn('editTl', 'Editar', { id: i.id, s: i.start_time, e: i.end_time, d: i.item_date, locked: i.locked ? '1' : '' }, 'secondary sm')}</span>` : ''}</li>`)}</ul>`) : empty('Aún no hay actividades en el cronograma')}</section>`;
}
actions.newTl = (el) => modal('Nueva actividad', html`${field('title', 'Actividad', { required: true })}<div class="grid2">${field('item_date', 'Fecha', { type: 'date', required: true })}${field('start_time', 'Inicio', { type: 'time', required: true })}${field('end_time', 'Fin', { type: 'time', required: true })}</div>${field('location', 'Ubicación')}${field('instructions', 'Instrucciones', { type: 'textarea' })}`, async (d) => { const r = await post(`/api/events/${el.dataset.event}/timeline`, d); toast(r.alerts.length ? `Guardada con ${r.alerts.length} aviso(s) de conflicto` : 'Actividad agregada', r.alerts.length ? 'err' : 'ok'); location.reload(); });
actions.editTl = (el) => modal('Editar actividad', html`${el.dataset.locked ? html`<p class="note warn">Esta actividad está confirmada: indica el motivo; se notificará a los afectados y quedará registrado.</p>` : ''}<div class="grid2">${field('item_date', 'Fecha', { type: 'date', value: el.dataset.d })}${field('start_time', 'Inicio', { type: 'time', value: el.dataset.s })}${field('end_time', 'Fin', { type: 'time', value: el.dataset.e })}</div>${field('reason', 'Motivo del cambio', { required: !!el.dataset.locked })}`, async (d) => { await patch(`/api/timeline/${el.dataset.id}`, d); toast('Actividad actualizada'); location.reload(); });

export async function guestsPanel(eventId) {
  const { guests, tables } = await get(`/api/events/${eventId}/guests`);
  const seats = guests.filter((g) => !['declined', 'no_show', 'waitlist'].includes(g.status)).reduce((s, g) => s + 1 + g.companions, 0);
  return html`<section class="block"><h2>Invitados <span class="m">${seats} lugares previstos · ${guests.length} registros</span></h2>
    <div class="head-actions">${btn('newGuest', 'Agregar invitado', { event: eventId }, 'secondary sm')}${btn('importGuests', 'Importar CSV', { event: eventId }, 'secondary sm')}${btn('newTable', 'Nueva mesa', { event: eventId }, 'secondary sm')}</div>
    ${table([{ label: 'Nombre', render: (g) => html`<b>${g.name}</b>${g.dietary ? html`<div class="m">Alimentación: ${g.dietary}</div>` : ''}` }, { label: 'Acompañantes', render: (g) => g.companions }, { label: 'Estado', render: (g) => badge(L.guest, g.status) }, { label: 'Mesa', render: (g) => g.table_name ?? 'Sin asignar' }, { label: '', render: (g) => btn('editGuest', 'Editar / asignar mesa', { id: g.id, status: g.status, table: g.table_id ?? '', event: eventId }, 'secondary sm') }], guests, 'Aún no hay invitados')}
    ${tables.length ? html`<h3>Mesas</h3><ul class="rows">${tables.map((t) => html`<li><span class="t">${t.name}</span><span>${t.seats_used}/${t.capacity} lugares ${t.seats_used > t.capacity ? raw('<span class="badge s-overdue">Sobrecupo</span>') : ''}</span></li>`)}</ul>` : ''}</section>`;
}
actions.newGuest = (el) => modal('Nuevo invitado', html`${field('name', 'Nombre', { required: true })}${field('email', 'Correo', { type: 'email' })}${field('companions', 'Acompañantes', { t: 'int', type: 'number', value: 0, min: 0 })}${field('dietary', 'Restricciones alimentarias')}${field('accessibility', 'Necesidades de accesibilidad')}`, async (d) => { await post(`/api/events/${el.dataset.event}/guests`, d); toast('Invitado agregado'); location.reload(); });
actions.importGuests = (el) => modal('Importar invitados (CSV)', html`<p class="hint">Primera fila con encabezados: nombre, correo, teléfono, grupo, acompañantes, alimentación.</p>${field('csv', 'Pega el contenido del CSV', { type: 'textarea', rows: 8, required: true, max: 400000 })}`, async (d) => { const r = await post(`/api/events/${el.dataset.event}/guests/import`, d); toast(`${r.created} importados${r.errors.length ? `, ${r.errors.length} con error (línea ${r.errors[0].line}: ${r.errors[0].message})` : ''}`, r.errors.length ? 'err' : 'ok'); location.reload(); }, { submit: 'Importar' });
actions.newTable = (el) => modal('Nueva mesa', html`${field('name', 'Nombre', { required: true })}${field('capacity', 'Capacidad', { t: 'int', type: 'number', required: true, min: 1 })}`, async (d) => { await post(`/api/events/${el.dataset.event}/tables`, d); location.reload(); });
actions.editGuest = async (el) => {
  const { tables } = await get(`/api/events/${el.dataset.event}/guests`);
  modal('Editar invitado', html`${field('status', 'Estado', { type: 'select', empty: false, value: el.dataset.status, options: Object.entries(L.guest) })}${field('table_id', 'Mesa', { type: 'select', value: el.dataset.table, options: tables.map((t) => [t.id, `${t.name} (${t.seats_used}/${t.capacity})`]) })}`,
    async (d) => { await patch(`/api/guests/${el.dataset.id}`, { status: d.status }); await post(`/api/guests/${el.dataset.id}/seat`, { table_id: d.table_id ?? null }); toast('Invitado actualizado'); location.reload(); });
};
export async function changesPanel(eventId, { staff = false } = {}) {
  const { change_requests: crs } = await get(`/api/events/${eventId}/change-requests`);
  return html`<section class="block"><h2>Solicitudes de cambio ${btn('newChange', 'Solicitar un cambio', { event: eventId }, 'secondary sm')}</h2>
    ${table([{ label: 'Motivo', render: (c) => html`${c.reason}${c.decision_note ? html`<div class="m">Respuesta: ${c.decision_note}</div>` : ''}` }, ...(staff ? [{ label: 'Solicitó', render: (c) => c.requester }] : []), { label: 'Fecha', render: (c) => fdate(c.created_at) }, { label: 'Estado', render: (c) => badge(L.change, c.status) },
      ...(staff ? [{ label: '', render: (c) => (c.status === 'pending' ? html`${btn('decide', 'Aprobar', { id: c.id, ok: '1' }, 'primary sm')} ${btn('decide', 'Rechazar', { id: c.id, ok: '' }, 'secondary sm')}` : '') }] : [])], crs, 'Sin solicitudes de cambio')}</section>`;
}
actions.newChange = (el) => modal('Solicitar un cambio', html`<p class="hint">Tu planner revisará la solicitud. Ningún cambio se aplica hasta que sea aprobado.</p>${field('reason', 'Describe el cambio que necesitas', { type: 'textarea', required: true })}`, async (d) => { await post(`/api/events/${el.dataset.event}/change-requests`, d); toast('Solicitud enviada'); location.reload(); }, { submit: 'Enviar solicitud' });
actions.decide = async (el) => { await post(`/api/change-requests/${el.dataset.id}/decide`, { approve: !!el.dataset.ok }); toast('Decisión registrada'); location.reload(); };
void put; void api; void can; void money; void confirmBox; void kv; void query;
