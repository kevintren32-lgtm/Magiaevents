import { html, raw, state, get, post, put, route, actions, submits, modal, toast, confirmBox, field, table, empty, head, badge, kv, btn, calendar, shiftMonth, L, fdate, fdt, fromMilli, query } from './core.js';
const reload = () => location.reload();
const today = () => new Date().toISOString().slice(0, 10);
const asgLine = (a) => html`<li><div><a class="t" href="#/assignments/${a.id}">${a.title}</a><div class="m">${a.service} · ${fdate(a.date)} ${a.start_time ?? ''}–${a.end_time ?? ''}</div></div>${badge(L.assignment, a.status)}</li>`;

export function registerVendor() {
  route('/', async () => {
    const { assignments: as } = await get('/api/vendor/assignments');
    const pending = as.filter((a) => a.status === 'requested'); const upcoming = as.filter((a) => ['accepted', 'confirmed'].includes(a.status) && a.date >= today()).sort((x, y) => (x.date + x.start_time).localeCompare(y.date + y.start_time)); const next = upcoming[0];
    return html`${head(`Hola, ${state.user.display_name.split(' ')[0]}`, 'Esto es lo que necesitas hacer')}
      <section class="block"><h2>Próximo servicio</h2>${next ? html`<div class="note"><a href="#/assignments/${next.id}"><b>${next.title}</b></a><br>${next.service} · ${fdate(next.date)} · llegada ${next.arrival_time ?? '—'} · servicio ${next.start_time}–${next.end_time}<br>${badge(L.assignment, next.status)}</div>` : html`<p class="m">No tienes servicios próximos.</p>`}</section>
      <div class="grid2"><section class="block"><h2>Solicitudes pendientes de tu respuesta</h2>${pending.length ? html`<ul class="rows">${pending.map(asgLine)}</ul>` : html`<p class="m">No tienes solicitudes pendientes.</p>`}</section>
      <section class="block"><h2>Próximas asignaciones</h2>${upcoming.length ? html`<ul class="rows">${upcoming.slice(0, 5).map(asgLine)}</ul>` : html`<p class="m">Sin asignaciones próximas.</p>`}</section></div>
      <section class="block"><h2>Historial</h2>${as.filter((a) => a.status === 'completed').length ? html`<ul class="rows">${as.filter((a) => a.status === 'completed').slice(-5).map(asgLine)}</ul>` : html`<p class="m">Aún no hay servicios completados.</p>`}</section>`;
  });

  route('/agenda', async () => {
    const { assignments: as } = await get('/api/vendor/assignments'); const ym = query().get('m') ?? today().slice(0, 7); const by = {};
    for (const a of as.filter((x) => !['rejected', 'cancelled'].includes(x.status))) (by[a.date] ||= []).push({ label: `${a.start_time ?? ''} ${a.service ?? a.title}`, id: a.id });
    const { blackouts, availability } = await get('/api/vendor/profile'); void availability;
    return html`${head('Agenda', 'Tus servicios asignados')}<div class="cal-nav"><a class="btn secondary sm" href="#/agenda?m=${shiftMonth(ym, -1)}" aria-label="Mes anterior">‹</a><strong>${ym}</strong><a class="btn secondary sm" href="#/agenda?m=${shiftMonth(ym, 1)}" aria-label="Mes siguiente">›</a></div>${calendar(ym, by, (i) => `#/assignments/${i.id}`)}
      ${blackouts.length ? html`<h3>Bloqueos de disponibilidad</h3><ul class="rows">${blackouts.map((b) => html`<li><span>${fdate(b.start_date)} – ${fdate(b.end_date)}</span><span class="m">${b.reason ?? ''}</span></li>`)}</ul>` : ''}`;
  });

  route('/assignments', async () => {
    const { assignments: as } = await get('/api/vendor/assignments'); const f = query().get('f') ?? 'open';
    const sets = { open: (a) => ['requested', 'accepted', 'confirmed'].includes(a.status), done: (a) => ['completed'].includes(a.status), all: () => true };
    return html`${head('Mis asignaciones')}<nav class="tabs" aria-label="Filtro">${[['open', 'Pendientes y próximas'], ['done', 'Completadas'], ['all', 'Todas']].map(([k, t]) => html`<a href="#/assignments?f=${k}" ${raw(k === f ? 'aria-current="page"' : '')}>${t}</a>`)}</nav>${as.filter(sets[f]).length ? html`<ul class="rows">${as.filter(sets[f]).map(asgLine)}</ul>` : empty('Sin asignaciones en esta vista')}`;
  });

  route('/assignments/:id', async ({ id }) => {
    const r = await get(`/api/vendor/assignments/${id}`); const a = r.assignment; const phases = ['prep', 'exec', 'teardown'];
    return html`${head(a.title, html`${a.service} · ${badge(L.assignment, a.status)}`, html`<a class="btn secondary" href="#/assignments">Volver</a>`)}
      ${a.status === 'requested' ? html`<div class="note warn"><b>Esta solicitud espera tu respuesta.</b><div class="head-actions">${btn('vRespond', 'Aceptar', { id, ok: '1' }, 'primary')}${btn('vRespond', 'Rechazar', { id, ok: '' }, 'secondary')}</div></div>` : ''}
      ${a.status === 'accepted' ? html`<p class="note">Aceptaste esta solicitud. Tu planner la confirmará formalmente.</p>` : ''}
      <section class="block"><h2>Ficha operativa</h2>${kv([['Folio', a.folio], ['Tipo de evento', a.event_type], ['Fecha', fdate(a.date)], ['Llegada', a.arrival_time], ['Montaje', a.setup_time], ['Inicio del servicio', a.start_time], ['Fin del servicio', a.end_time], ['Desmontaje', a.teardown_time], ['Ubicación y acceso', a.location ?? 'Se compartirá cuando tu planner la autorice'], ['Cantidad', fromMilli(a.qty_milli)], ['Personal necesario', a.staff_needed], ['Requerimientos', a.requirements], ['Instrucciones', a.instructions]])}</section>
      ${a.status === 'confirmed' ? html`<section class="block"><h2>Registro del servicio</h2><div class="head-actions">${btn('vStep', a.arrived_at ? `Llegada: ${fdt(a.arrived_at)}` : 'Confirmar llegada', { id, s: 'arrive', done: a.arrived_at ? '1' : '' }, a.arrived_at ? 'secondary' : 'primary')}${btn('vStep', a.started_at ? `Inicio: ${fdt(a.started_at)}` : 'Confirmar inicio', { id, s: 'start', done: a.started_at ? '1' : '' }, a.started_at || !a.arrived_at ? 'secondary' : 'primary')}${btn('vStep', 'Confirmar finalización', { id, s: 'finish', done: a.finished_at ? '1' : '' }, a.started_at ? 'primary' : 'secondary')}</div></section>` : ''}
      <section class="block"><h2>Checklist</h2>${r.checklist.length ? phases.map((ph) => (r.checklist.some((c) => c.phase === ph) ? html`<h3>${L.phase[ph]}</h3><ul class="rows">${r.checklist.filter((c) => c.phase === ph).map((c) => html`<li><span>${c.text}</span><button type="button" class="btn ${c.done ? 'primary' : 'secondary'} sm" data-action="vCheck" data-id="${c.id}" aria-pressed="${c.done ? 'true' : 'false'}">${c.done ? '✓ Hecho' : 'Marcar como hecho'}</button></li>`)}</ul>` : '')) : html`<p class="m">Tu planner no ha definido un checklist.</p>`}</section>
      ${r.tasks.length ? html`<section class="block"><h2>Tareas</h2><ul class="rows">${r.tasks.map((t) => html`<li><span>${t.title}<div class="m">${t.description ?? ''}</div></span>${t.status === 'completed' ? badge(L.task, 'completed') : btn('vTask', 'Completar', { id: t.id }, 'secondary sm')}</li>`)}</ul></section>` : ''}
      ${r.timeline.length ? html`<section class="block"><h2>Tu cronograma</h2><ul class="rows">${r.timeline.map((t) => html`<li><span>${fdate(t.item_date)} ${t.start_time}–${t.end_time} · ${t.title}<div class="m">${t.instructions ?? ''}</div></span></li>`)}</ul></section>` : ''}
      <section class="block"><h2>Documentos</h2>${r.documents.length ? html`<ul class="rows">${r.documents.map((d) => html`<li><span>${d.name}</span>${btn('dl', 'Descargar', { id: d.id }, 'secondary sm')}</li>`)}</ul>` : html`<p class="m">No hay documentos compartidos contigo.</p>`}</section>
      <div class="head-actions">${btn('vIncident', 'Reportar incidencia', { id }, 'secondary')}${btn('vChange', 'Solicitar un cambio a la planner', { id }, 'secondary')}</div>`;
  });
  actions.vRespond = (el) => { if (el.dataset.ok) return post(`/api/vendor/assignments/${el.dataset.id}/respond`, { accept: true }).then(() => { toast('Solicitud aceptada'); reload(); }); modal('Rechazar solicitud', field('reason', 'Motivo del rechazo', { type: 'textarea', required: true }), async (d) => { await post(`/api/vendor/assignments/${el.dataset.id}/respond`, { accept: false, reason: d.reason }); toast('Respuesta enviada'); location.hash = '#/assignments'; }, { submit: 'Rechazar' }); };
  actions.vStep = async (el) => { if (el.dataset.done) return; if (el.dataset.s === 'finish' && !(await confirmBox('¿Confirmas que el servicio terminó?', 'Sí, finalizó'))) return; await post(`/api/vendor/assignments/${el.dataset.id}/${el.dataset.s}`); toast('Registrado'); reload(); };
  actions.vCheck = async (el) => { await post(`/api/vendor/checklist/${el.dataset.id}/toggle`); reload(); };
  actions.vTask = async (el) => { await post(`/api/vendor/tasks/${el.dataset.id}/complete`); reload(); };
  actions.vIncident = (el) => modal('Reportar incidencia', html`${field('description', 'Qué ocurrió', { type: 'textarea', required: true })}${field('severity', 'Gravedad', { type: 'select', empty: false, value: 'medium', options: Object.entries(L.severity) })}`, async (d) => { await post(`/api/vendor/assignments/${el.dataset.id}/incidents`, d); toast('Incidencia enviada a la planner'); }, { submit: 'Enviar' });
  actions.vChange = (el) => modal('Solicitar un cambio', html`<p class="hint">No puedes modificar las condiciones aprobadas; tu planner revisará tu solicitud.</p>${field('reason', 'Qué necesitas cambiar y por qué', { type: 'textarea', required: true })}`, async (d) => { await post(`/api/vendor/assignments/${el.dataset.id}/change-requests`, d); toast('Solicitud enviada'); }, { submit: 'Enviar' });

  route('/availability', async () => {
    const { availability, blackouts } = await get('/api/vendor/profile');
    return html`${head('Disponibilidad', 'Confirma las fechas en las que puedes trabajar')}<div class="grid2"><section class="block"><h2>Marcar una fecha</h2><form data-submit="vAvail" novalidate>${field('date', 'Fecha', { type: 'date', required: true })}${field('status', 'Estado', { type: 'select', empty: false, options: [['available', 'Disponible'], ['unavailable', 'No disponible']] })}${field('capacity', 'Servicios que puedes atender ese día', { t: 'int', type: 'number', value: 1, min: 1 })}<button class="btn primary" type="submit">Guardar</button><small class="err" data-err="_form" role="alert"></small></form></section>
      <section class="block"><h2>Bloquear un periodo</h2><form data-submit="vBlackout" novalidate>${field('start_date', 'Desde', { type: 'date', required: true })}${field('end_date', 'Hasta', { type: 'date', required: true })}${field('reason', 'Motivo (vacaciones, mantenimiento…)')}<button class="btn primary" type="submit">Bloquear</button><small class="err" data-err="_form" role="alert"></small></form></section></div>
      <section class="block"><h2>Fechas registradas</h2>${availability.length ? html`<ul class="rows">${availability.map((x) => html`<li><span>${fdate(x.date)}</span><span class="badge ${x.status === 'available' ? 's-confirmed' : 's-rejected'}">${x.status === 'available' ? 'Disponible' : 'No disponible'}</span></li>`)}</ul>` : html`<p class="m">Aún no has registrado fechas.</p>`}${blackouts.length ? html`<h3>Bloqueos</h3><ul class="rows">${blackouts.map((b) => html`<li><span>${fdate(b.start_date)} – ${fdate(b.end_date)}</span><span class="m">${b.reason ?? ''}</span></li>`)}</ul>` : ''}</section>`;
  });
  submits.vAvail = async (d, f) => { await put('/api/vendor/availability', d); toast('Disponibilidad guardada'); reload(); void f; };
  submits.vBlackout = async (d) => { await post('/api/vendor/blackouts', d); toast('Periodo bloqueado'); reload(); };

  route('/profile', async () => {
    const { profile: p } = await get('/api/vendor/profile');
    return html`${head('Perfil comercial', p.business_name)}<p class="note">Para modificar tus datos comerciales, escribe a tu planner desde «Mensajes».</p>${kv([['Contacto', p.contact_name], ['Teléfono', p.phone], ['Correo', p.email], ['Ciudad', p.city], ['Categorías', p.categories.join(', ')], ['Cobertura', p.coverage], ['Tiempo de montaje', `${p.setup_minutes} min`], ['Tiempo de desmontaje', `${p.teardown_minutes} min`], ['Requerimientos técnicos', p.tech_requirements], ['Condiciones de pago', p.payment_terms], ['Política de cancelación', p.cancellation_policy], ['Descripción', p.description]])}`;
  });
}
