// Copia consistente de la base (VACUUM INTO) + copia de documentos. Uso: node scripts/backup.ts [carpeta-destino]
import fs from 'node:fs';
import path from 'node:path';
import { Db } from '../src/lib/db.ts';
import { config } from '../src/config.ts';

const dest = path.resolve(process.argv[2] ?? path.join(config.root, 'backups'));
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const dir = path.join(dest, stamp); fs.mkdirSync(dir, { recursive: true });
const db = new Db(config.dbPath);
db.raw.exec(`VACUUM INTO '${path.join(dir, 'app.db').replace(/'/g, "''")}'`);
db.close();
if (fs.existsSync(config.storageDir)) fs.cpSync(config.storageDir, path.join(dir, 'storage'), { recursive: true });
// comprobación: la copia abre y pasa PRAGMA integrity_check
const chk = new Db(path.join(dir, 'app.db')); const r = chk.get('PRAGMA integrity_check'); chk.close();
if (r?.integrity_check !== 'ok') { console.error('La copia NO pasó la verificación de integridad'); process.exit(1); }
console.log(`Copia verificada en ${dir}`);
