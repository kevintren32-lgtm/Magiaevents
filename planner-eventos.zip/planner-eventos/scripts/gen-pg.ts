// Genera supabase/migrations/0001_schema.sql a partir del esquema SQLite real (misma fuente de verdad).
// SIN PROBAR contra PostgreSQL (el entorno de desarrollo no tenía PostgreSQL): revísalo con `supabase db reset` en un proyecto local.
import fs from 'node:fs';
import path from 'node:path';
import { Db, migrate } from '../src/lib/db.ts';
import { config } from '../src/config.ts';

const db = new Db(':memory:'); migrate(db, path.join(config.root, 'migrations', 'sqlite'));
const tables = db.all(`SELECT name, sql FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' AND name <> 'schema_migrations' ORDER BY rowid`);
const FLAGS = new Set(['is_demo', 'active', 'done', 'verified', 'locked', 'show_to_client', 'visible_to_client', 'location_visible', 'enabled', 'signature_valid']);
const JSONB = new Set(['permissions', 'prefs', 'brief', 'details', 'items', 'params', 'categories', 'payload', 'before_json', 'after_json', 'value']);
const DATES = new Set(['event_date', 'due_date', 'paid_date', 'expense_date', 'service_date', 'item_date', 'start_date', 'end_date', 'date', 'expires_on']);
const TIMES = new Set(['start_time', 'end_time', 'arrival_time', 'setup_time', 'teardown_time']);

function pgType(table: string, col: string, sqlite: string): string {
  if ((table === 'sessions' && col === 'id') || (table === 'audit_logs' && col === 'entity_id')) return 'text';
  if (col === 'id' || (col.endsWith('_id') && col !== 'external_id')) return 'uuid';
  if (JSONB.has(col)) return 'jsonb';
  if (DATES.has(col)) return 'date';
  if (TIMES.has(col)) return 'time';
  if (col.endsWith('_at') || col.endsWith('_until')) return 'timestamptz';
  if (FLAGS.has(col)) return 'boolean';
  if (sqlite === 'REAL') return 'double precision';
  if (sqlite === 'INTEGER') return col.endsWith('_cents') ? 'bigint' : 'integer';
  return 'text';
}
function pgDefault(type: string, d: string | null): string {
  if (d == null) return '';
  if (/strftime/.test(d)) return ' DEFAULT now()';
  if (type === 'boolean') return ` DEFAULT ${d.trim() === '1' ? 'true' : 'false'}`;
  if (type === 'jsonb') return ` DEFAULT ${d}::jsonb`;
  return ` DEFAULT ${d}`;
}

const out: string[] = ['-- 0001_schema.sql — GENERADO por scripts/gen-pg.ts desde migrations/sqlite. NO EDITAR A MANO: regenera con `npm run gen:pg`.', '-- Estado: sin probar contra PostgreSQL.', 'create extension if not exists pgcrypto;', ''];
const fks: string[] = []; const extra: string[] = [];
for (const t of tables) {
  const cols = db.all(`PRAGMA table_info(${t.name})`); const pks = cols.filter((c) => c.pk).sort((a, b) => a.pk - b.pk).map((c) => c.name);
  const sqlNoComments = t.sql.replace(/--.*$/gm, '');
  const checks = [...sqlNoComments.matchAll(/CHECK\s*(\((?:[^()]|\((?:[^()]|\([^()]*\))*\))*\))/g)].map((m) => m[1]);
  const lines: string[] = [];
  for (const c of cols) {
    const type = pgType(t.name, c.name, c.type);
    const isNocase = new RegExp(`\\b${c.name}\\b[^,]*COLLATE NOCASE`, 'i').test(sqlNoComments);
    const uniqueInline = new RegExp(`\\b${c.name}\\b[^,]*\\bUNIQUE\\b`, 'i').test(sqlNoComments) && !isNocase && !pks.includes(c.name);
    const idDefault = c.name === 'id' && type === 'uuid' ? ' DEFAULT gen_random_uuid()' : '';
    lines.push(`  ${c.name} ${type}${c.notnull || pks.includes(c.name) ? ' NOT NULL' : ''}${idDefault || pgDefault(type, c.dflt_value)}${uniqueInline ? ' UNIQUE' : ''}`);
    if (isNocase) extra.push(`create unique index uq_${t.name}_${c.name}_lower on ${t.name} (lower(${c.name}));`);
  }
  if (pks.length) lines.push(`  PRIMARY KEY (${pks.join(', ')})`);
  for (const u of db.all(`PRAGMA index_list(${t.name})`).filter((i) => i.origin === 'u' && !i.partial)) {
    const ic = db.all(`PRAGMA index_info(${u.name})`).map((x) => x.name);
    if (ic.length > 1) lines.push(`  UNIQUE (${ic.join(', ')})`);
  }
  for (const ck of checks) lines.push(`  CHECK ${ck.replace(/\b(is_demo|active)\b/g, '$1')}`);
  out.push(`create table ${t.name} (\n${lines.join(',\n')}\n);`, '');
  for (const f of db.all(`PRAGMA foreign_key_list(${t.name})`)) fks.push(`alter table ${t.name} add constraint fk_${t.name}_${f.from} foreign key (${f.from}) references ${f.table}(${f.to})${f.on_delete !== 'NO ACTION' ? ` on delete ${String(f.on_delete).toLowerCase()}` : ''};`);
}
for (const i of db.all(`SELECT sql FROM sqlite_master WHERE type = 'index' AND sql IS NOT NULL ORDER BY rowid`)) out.push(i.sql.replace(/\s+/g, ' ') + ';');
out.push('', '-- Claves foráneas', ...fks, '', '-- Unicidad de correo sin distinguir mayúsculas', ...extra, '');
out.push(`-- Tablas de solo anexado
create function app_forbid_mutation() returns trigger language plpgsql as $$ begin raise exception '% es de solo anexado: registra un movimiento compensatorio', tg_table_name; end $$;
create trigger audit_logs_append_only before update or delete on audit_logs for each row execute function app_forbid_mutation();
create trigger financial_adjustments_append_only before update or delete on financial_adjustments for each row execute function app_forbid_mutation();
`);
fs.mkdirSync(path.join(config.root, 'supabase', 'migrations'), { recursive: true });
fs.writeFileSync(path.join(config.root, 'supabase', 'migrations', '0001_schema.sql'), out.join('\n'));
fs.writeFileSync(path.join(config.root, 'supabase', 'tables.json'), JSON.stringify(Object.fromEntries(tables.map((t) => [t.name, db.all(`PRAGMA table_info(${t.name})`).map((c) => c.name)])), null, 1));
console.log(`Generado: ${tables.length} tablas, ${fks.length} claves foráneas`);
