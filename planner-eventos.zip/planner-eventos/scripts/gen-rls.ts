// Genera supabase/migrations/0002_rls.sql: funciones de ayuda, RLS por tabla y vistas de portal (cliente/proveedor).
// Valida que cada tabla/columna exista en el esquema real. SIN PROBAR contra PostgreSQL.
import fs from 'node:fs';
import path from 'node:path';
import { config } from '../src/config.ts';

const schema: Record<string, string[]> = JSON.parse(fs.readFileSync(path.join(config.root, 'supabase', 'tables.json'), 'utf8'));
const tbl = (t: string) => { if (!schema[t]) throw new Error(`tabla inexistente: ${t}`); return t; };
const cols = (t: string, list: string[]) => { for (const c of list) if (!schema[tbl(t)].includes(c)) throw new Error(`columna inexistente: ${t}.${c}`); return list; };
const except = (t: string, ex: string[]) => { cols(t, ex); return schema[tbl(t)].filter((c) => !ex.includes(c)); };
const out: string[] = [];
const sql = (s: string) => out.push(s);

sql(`-- 0002_rls.sql — GENERADO por scripts/gen-rls.ts. NO EDITAR A MANO. SIN PROBAR contra PostgreSQL.
-- Modelo: (1) RLS activo en TODAS las tablas; (2) sin políticas de escritura: toda escritura la hace el servidor
-- con la clave service_role, que valida reglas de negocio; (3) el personal lee tablas base según permisos;
-- (4) clientes y proveedores leen SOLO mediante vistas de portal con columnas autorizadas.

create schema if not exists app;
alter table users add constraint users_auth_fk foreign key (id) references auth.users(id) on delete cascade;

create or replace function app.me_org() returns uuid language sql stable security definer set search_path = public, pg_temp
as $$ select org_id from users where id = auth.uid() and status = 'active' $$;
create or replace function app.me_role() returns text language sql stable security definer set search_path = public, pg_temp
as $$ select role from users where id = auth.uid() and status = 'active' $$;
create or replace function app.is_staff() returns boolean language sql stable security definer set search_path = public, pg_temp
as $$ select coalesce(app.me_role() in ('owner','staff'), false) $$;
create or replace function app.has_perm(p text) returns boolean language sql stable security definer set search_path = public, pg_temp
as $$ select exists (select 1 from users where id = auth.uid() and status = 'active' and (role = 'owner' or (role = 'staff' and permissions ? p))) $$;
create or replace function app.me_client() returns uuid language sql stable security definer set search_path = public, pg_temp
as $$ select c.id from clients c join users u on u.id = c.user_id where u.id = auth.uid() and u.status = 'active' $$;
create or replace function app.me_vendor() returns uuid language sql stable security definer set search_path = public, pg_temp
as $$ select v.id from vendors v join users u on u.id = v.user_id where u.id = auth.uid() and u.status = 'active' $$;
create or replace function app.can_event(e uuid) returns boolean language sql stable security definer set search_path = public, pg_temp
as $$ select exists (
  select 1 from events ev join users u on u.id = auth.uid() and u.status = 'active' and u.org_id = ev.org_id
  where ev.id = e and (
    u.role = 'owner'
    or (u.role = 'staff' and (u.permissions ? 'events.read_all' or exists (select 1 from event_staff s where s.event_id = ev.id and s.user_id = u.id)))
    or (u.role = 'client' and exists (select 1 from client_event_memberships m join clients c on c.id = m.client_id where m.event_id = ev.id and c.user_id = u.id))
  )) $$;
revoke all on function app.me_org(), app.me_role(), app.is_staff(), app.has_perm(text), app.me_client(), app.me_vendor(), app.can_event(uuid) from public, anon;
grant execute on function app.me_org(), app.me_role(), app.is_staff(), app.has_perm(text), app.me_client(), app.me_vendor(), app.can_event(uuid) to authenticated;
grant usage on schema app to authenticated;

-- Base: nada por defecto
`);
for (const t of Object.keys(schema)) sql(`alter table ${t} enable row level security;`);
sql(`revoke all on all tables in schema public from anon, authenticated;\n`);

type Rule = { t: string; using: string; perm?: string; grantCols?: string[]; name?: string };
const org = 'org_id = app.me_org()';
const ev = (c = 'event_id') => `app.can_event(${c})`;
const viaVendor = (t: string, col = 'vendor_id') => `exists (select 1 from vendors v where v.id = ${t}.${col} and v.org_id = app.me_org())`;
const rules: Rule[] = [
  { t: 'organizations', using: 'id = app.me_org()' },
  { t: 'organization_settings', using: org, perm: 'settings.manage' },
  { t: 'users', using: `id = auth.uid() or (${org} and app.has_perm('users.manage'))`, grantCols: except('users', ['password_hash', 'failed_attempts', 'locked_until']) },
  { t: 'invitations', using: org, perm: 'users.manage' },
  { t: 'email_outbox', using: `${org} and app.me_role() = 'owner'` },
  { t: 'clients', using: org, perm: 'clients.manage' },
  { t: 'vendors', using: org, perm: 'vendors.manage', grantCols: except('vendors', ['tax_data']) },
  { t: 'vendor_availability', using: viaVendor('vendor_availability'), perm: 'vendors.manage' },
  { t: 'vendor_blackouts', using: viaVendor('vendor_blackouts'), perm: 'vendors.manage' },
  { t: 'vendor_evaluations', using: org, perm: 'vendors.manage' },
  { t: 'events', using: `${org} and ${ev('id')}` },
  { t: 'event_staff', using: ev() },
  { t: 'client_event_memberships', using: ev() },
  { t: 'service_categories', using: org },
  { t: 'service_catalog', using: org },
  { t: 'service_packages', using: `exists (select 1 from service_catalog s where s.id = service_packages.service_id and s.org_id = app.me_org())` },
  { t: 'service_requests', using: `${org} and ${ev()}` },
  { t: 'quotes', using: `${org} and ${ev()}` },
  { t: 'quote_versions', using: `exists (select 1 from quotes q where q.id = quote_versions.quote_id and q.org_id = app.me_org() and ${ev('q.event_id')})` },
  { t: 'quote_items', using: `exists (select 1 from quote_versions qv join quotes q on q.id = qv.quote_id where qv.id = quote_items.version_id and q.org_id = app.me_org() and ${ev('q.event_id')})` },
  { t: 'service_assignments', using: `${org} and ${ev()}`, perm: 'logistics.manage', grantCols: except('service_assignments', ['cost_cents', 'actual_cost_cents']) },
  { t: 'assignment_checklist', using: `exists (select 1 from service_assignments a where a.id = assignment_checklist.assignment_id and a.org_id = app.me_org() and ${ev('a.event_id')})`, perm: 'logistics.manage' },
  { t: 'payments', using: `${org} and ${ev()}`, perm: 'finance.view' },
  { t: 'payment_transactions', using: org, perm: 'finance.view' },
  { t: 'expenses', using: `${org} and ${ev()}`, perm: 'finance.view' },
  { t: 'financial_adjustments', using: `${org} and ${ev()}`, perm: 'finance.view' },
  { t: 'tables_seating', using: ev() },
  { t: 'guests', using: `${org} and ${ev()}` },
  { t: 'tasks', using: `${org} and ${ev()}` },
  { t: 'task_dependencies', using: `exists (select 1 from tasks t where t.id = task_dependencies.task_id and t.org_id = app.me_org() and ${ev('t.event_id')})` },
  { t: 'task_templates', using: org },
  { t: 'timeline_items', using: `${org} and ${ev()}` },
  { t: 'timeline_dependencies', using: `exists (select 1 from timeline_items i where i.id = timeline_dependencies.item_id and i.org_id = app.me_org() and ${ev('i.event_id')})` },
  { t: 'documents', using: `${org} and (uploaded_by = auth.uid() or (app.has_perm('documents.manage') and ((event_id is null and app.has_perm('vendors.manage')) or (event_id is not null and ${ev()}))))` },
  { t: 'document_permissions', using: `exists (select 1 from documents d where d.id = document_permissions.document_id and d.org_id = app.me_org())`, perm: 'documents.manage' },
  { t: 'incidents', using: `${org} and ${ev()}`, perm: 'logistics.manage' },
  { t: 'change_requests', using: `${org} and (requested_by = auth.uid() or (app.is_staff() and ${ev()}))` },
  { t: 'audit_logs', using: org, perm: 'audit.view' },
  { t: 'integrations', using: org, perm: 'settings.manage' },
  { t: 'automation_rules', using: org, perm: 'settings.manage' },
  { t: 'automation_runs', using: org, perm: 'settings.manage' },
  { t: 'data_requests', using: `user_id = auth.uid() or (${org} and app.has_perm('users.manage'))` },
  { t: 'consents', using: `user_id = auth.uid()` },
  { t: 'notifications', using: `user_id = auth.uid()` },
];
const staffOnly = new Set(['organization_settings', 'invitations', 'email_outbox', 'clients', 'vendors', 'vendor_availability', 'vendor_blackouts', 'vendor_evaluations', 'event_staff', 'service_categories', 'service_catalog', 'service_packages', 'service_requests', 'quotes', 'quote_versions', 'quote_items', 'service_assignments', 'assignment_checklist', 'payments', 'payment_transactions', 'expenses', 'financial_adjustments', 'guests', 'tables_seating', 'tasks', 'task_dependencies', 'task_templates', 'timeline_items', 'timeline_dependencies', 'documents', 'document_permissions', 'incidents', 'audit_logs', 'integrations', 'automation_rules', 'automation_runs', 'client_event_memberships', 'events']);
for (const r of rules) {
  tbl(r.t); const staff = staffOnly.has(r.t) ? 'app.is_staff() and ' : '';
  const cond = `${staff}(${r.using})${r.perm ? ` and app.has_perm('${r.perm}')` : ''}`;
  sql(r.grantCols ? `grant select (${cols(r.t, r.grantCols).join(', ')}) on ${r.t} to authenticated;` : `grant select on ${r.t} to authenticated;`);
  sql(`create policy ${r.t}_select on ${r.t} for select to authenticated using (${cond});`);
}
// Conversaciones: el participante (cliente o proveedor) ve las suyas; la planner, las de su ámbito. Nunca entre cliente y proveedor.
sql(`grant select on conversations, messages, message_attachments to authenticated;
create policy conversations_select on conversations for select to authenticated using (
  participant_user_id = auth.uid()
  or (app.is_staff() and ${org} and ((event_id is not null and ${ev()}) or (event_id is null and app.has_perm(case kind when 'client' then 'clients.manage' else 'vendors.manage' end)))));
create policy messages_select on messages for select to authenticated using (exists (select 1 from conversations c where c.id = messages.conversation_id));
create policy message_attachments_select on message_attachments for select to authenticated using (exists (select 1 from messages m where m.id = message_attachments.message_id));
-- (las políticas de messages/attachments heredan la visibilidad de conversations, que también tiene RLS)
`);
sql(`-- Sin políticas (solo servidor con service_role): counters, sessions, password_resets, rate_limits, webhook_events.
-- Sin políticas de INSERT/UPDATE/DELETE en ninguna tabla: las escrituras pasan por el servidor.

-- Costos de proveedor: solo con permiso de finanzas (las columnas se excluyeron del grant de service_assignments)
create view staff_assignment_costs as
  select a.id, a.event_id, a.vendor_id, a.cost_cents, a.actual_cost_cents from service_assignments a
  where app.is_staff() and app.has_perm('finance.view') and a.org_id = app.me_org() and app.can_event(a.event_id);
create view staff_vendor_tax_data as
  select v.id, v.tax_data from vendors v where app.has_perm('finance.view') and v.org_id = app.me_org();
`);

// ───── Vistas de portal: cliente ─────
const evCols = except('events', ['notes_internal', 'planner_id', 'cancel_reason', 'org_id']);
const reqCols = except('service_requests', ['planner_notes', 'org_id']);
sql(`-- ───── Portal del cliente (vistas con permisos del propietario; filtran por membresía) ─────
create view portal_events as select ${evCols.map((c) => `e.${c}`).join(', ')} from events e where app.me_role() = 'client' and app.can_event(e.id);
create view portal_requests as select ${reqCols.map((c) => `r.${c}`).join(', ')}, s.name as service_name, s.unit_label from service_requests r join service_catalog s on s.id = r.service_id where app.me_role() = 'client' and app.can_event(r.event_id);
create view portal_quote_versions as select qv.*, q.event_id from quote_versions qv join quotes q on q.id = qv.quote_id where app.me_role() = 'client' and qv.status <> 'draft' and app.can_event(q.event_id);
create view portal_quote_items as select i.*, q.event_id from quote_items i join quote_versions qv on qv.id = i.version_id join quotes q on q.id = qv.quote_id where app.me_role() = 'client' and qv.status <> 'draft' and app.can_event(q.event_id);
create view portal_payments as select ${cols('payments', ['id', 'event_id', 'concept', 'amount_cents', 'paid_cents', 'due_date', 'paid_date', 'status']).join(', ')} from payments where app.me_role() = 'client' and direction = 'in' and status <> 'cancelled' and app.can_event(event_id);
create view portal_tasks as select ${cols('tasks', ['id', 'event_id', 'title', 'description', 'due_date', 'priority', 'status', 'completed_at']).join(', ')} from tasks where app.me_role() = 'client' and audience = 'client' and app.can_event(event_id);
create view portal_timeline as select ${cols('timeline_items', ['id', 'event_id', 'item_date', 'start_time', 'end_time', 'title', 'location', 'status']).join(', ')} from timeline_items where app.me_role() = 'client' and show_to_client and app.can_event(event_id);
create view portal_documents as select ${cols('documents', ['id', 'event_id', 'kind', 'name', 'mime', 'size_bytes', 'version', 'status', 'visibility', 'uploaded_by', 'created_at']).join(', ')} from documents where app.me_role() = 'client' and event_id is not null and app.can_event(event_id) and (visibility = 'client' or uploaded_by = auth.uid());
create view portal_guests as select * from guests where app.me_role() = 'client' and app.can_event(event_id);
create view portal_tables as select * from tables_seating where app.me_role() = 'client' and app.can_event(event_id);
create view portal_catalog as select ${cols('service_catalog', ['id', 'category_id', 'name', 'description', 'price_type', 'base_price_cents', 'unit_label', 'min_qty_milli', 'max_qty_milli', 'tax_bps', 'advance_bps', 'details']).join(', ')} from service_catalog where app.me_role() = 'client' and active and visible_to_client and org_id = app.me_org();
create view portal_catalog_packages as select p.id, p.service_id, p.name, p.description, p.price_cents from service_packages p join service_catalog s on s.id = p.service_id where app.me_role() = 'client' and p.active and s.active and s.visible_to_client and s.org_id = app.me_org();

-- ───── Portal del proveedor: sin costos, sin cliente, sin nombre del evento, sin otros proveedores ─────
create view vendor_assignments as
  select a.id, a.status, a.public_title, e.type as event_type, e.folio, a.service_description, a.qty_milli, a.service_date,
         a.arrival_time, a.setup_time, a.start_time, a.end_time, a.teardown_time,
         case when a.location_visible then a.location_detail end as location,
         a.instructions, a.requirements, a.staff_needed, a.reject_reason, a.arrived_at, a.started_at, a.finished_at
  from service_assignments a join events e on e.id = a.event_id
  where app.me_role() = 'vendor' and a.vendor_id = app.me_vendor();
create view vendor_checklist as select k.id, k.assignment_id, k.phase, k.text, k.done from assignment_checklist k join service_assignments a on a.id = k.assignment_id where app.me_role() = 'vendor' and a.vendor_id = app.me_vendor();
create view vendor_tasks as select t.id, t.assignment_id, t.title, t.description, t.due_date, t.status from tasks t join service_assignments a on a.id = t.assignment_id where app.me_role() = 'vendor' and t.audience = 'vendor' and a.vendor_id = app.me_vendor();
create view vendor_timeline as select i.id, i.assignment_id, i.item_date, i.start_time, i.end_time, i.title, i.instructions, i.status from timeline_items i where app.me_role() = 'vendor' and i.vendor_id = app.me_vendor();
create view vendor_documents as select d.id, d.event_id, d.kind, d.name, d.mime, d.size_bytes from documents d where app.me_role() = 'vendor' and d.status = 'active' and (d.uploaded_by = auth.uid() or d.vendor_id = app.me_vendor() or exists (select 1 from document_permissions p where p.document_id = d.id and p.vendor_id = app.me_vendor()));
create view vendor_profile as select ${except('vendors', ['internal_notes', 'tax_data', 'org_id', 'is_demo', 'status', 'user_id']).join(', ')} from vendors where app.me_role() = 'vendor' and id = app.me_vendor();
create view vendor_availability_own as select ${cols('vendor_availability', ['date', 'status', 'capacity', 'note']).join(', ')} from vendor_availability where app.me_role() = 'vendor' and vendor_id = app.me_vendor();
`);
sql(`grant select on staff_assignment_costs, staff_vendor_tax_data, portal_events, portal_requests, portal_quote_versions, portal_quote_items, portal_payments, portal_tasks, portal_timeline, portal_documents, portal_guests, portal_tables, portal_catalog, portal_catalog_packages, vendor_assignments, vendor_checklist, vendor_tasks, vendor_timeline, vendor_documents, vendor_profile, vendor_availability_own to authenticated;`);
const file = out.join('\n');
const missing = Object.keys(schema).filter((t) => !file.includes(`alter table ${t} enable row level security;`));
if (missing.length) throw new Error('Sin RLS: ' + missing.join(', '));
let d = 0; for (const ch of file) { if (ch === '(') d++; else if (ch === ')') d--; if (d < 0) throw new Error('paréntesis desbalanceados'); } if (d) throw new Error('paréntesis desbalanceados');
fs.writeFileSync(path.join(config.root, 'supabase', 'migrations', '0002_rls.sql'), file);
console.log(`RLS: ${Object.keys(schema).length} tablas con RLS, ${rules.length + 3} políticas, 21 vistas`);
