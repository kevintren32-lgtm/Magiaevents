// Uso:  node scripts/seed.ts --owner-email tu@correo.com [--org "Nombre"] [--demo]
// Crea la organización y la cuenta propietaria con una contraseña aleatoria que se imprime UNA sola vez.
import { Db, migrate } from '../src/lib/db.ts';
import { config } from '../src/config.ts';
import path from 'node:path';
import { bootstrapOrg, seedDemo, strongPassword } from '../src/seed.ts';

const arg = (n: string) => { const i = process.argv.indexOf(`--${n}`); return i > 0 ? process.argv[i + 1] : undefined; };
const demo = process.argv.includes('--demo');
if (demo && config.env === 'production') { console.error('Los datos de demostración están prohibidos en producción.'); process.exit(1); }
const db = new Db(config.dbPath); migrate(db, path.join(config.root, 'migrations', 'sqlite'));
let org = db.get('SELECT id FROM organizations LIMIT 1'); let ownerId: string;
if (!org) {
  const email = arg('owner-email'); if (!email) { console.error('Falta --owner-email'); process.exit(1); }
  const pw = strongPassword();
  const r = await bootstrapOrg(db, { orgName: arg('org') ?? 'Mi empresa de eventos', ownerEmail: email, ownerName: arg('owner-name') ?? 'Administradora', ownerPassword: pw });
  org = { id: r.orgId }; ownerId = r.ownerId;
  console.log(`\nPropietaria creada\n  correo: ${email}\n  contraseña: ${pw}\n  (guárdala ahora; no se vuelve a mostrar. Cámbiala al iniciar sesión)\n`);
} else ownerId = db.get(`SELECT id FROM users WHERE org_id = ? AND role = 'owner' LIMIT 1`, org.id)!.id;
if (demo) {
  const creds = await seedDemo(db, org.id, ownerId);
  console.log('Usuarios de DEMOSTRACIÓN (contraseñas aleatorias; para eliminarlos borra la base de datos de demo):');
  for (const c of creds) console.log(`  ${c.role.padEnd(7)} ${c.email}  ${c.password}`);
}
db.close();
