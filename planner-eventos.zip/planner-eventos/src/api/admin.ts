import type { Router } from '../http.ts';
import { HttpError, conflict, forbidden, invalid, notFound } from '../lib/errors.ts';
import { sha256, token } from '../lib/crypto.ts';
import { uid } from '../lib/db.ts';
import { parse, v } from '../lib/validate.ts';
import { PERMS, audit, hasPerm, need } from '../services.ts';

const SETTING_KEYS = ['brand', 'locale', 'tax', 'legal', 'privacy_policy', 'privacy_visibility'];
const HEX = /^#[0-9a-fA-F]{6}$/;
const FONT = /^[A-Za-z0-9 ,'"\-]{1,160}$/;

export function register(r: Router) {
  r.get('/api/users', (c) => { need(c.user!, 'users.manage');
    return { users: c.db.all('SELECT id, email, display_name, role, permissions, status, created_at FROM users WHERE org_id = ? ORDER BY created_at', c.user!.org_id).map((u) => ({ ...u, permissions: JSON.parse(u.permissions) })) };
  });

  r.post('/api/users/invite', (c) => { need(c.user!, 'users.manage');
    const b = parse(c.body, { email: v.email(), role: v.oneOf(['staff', 'client', 'vendor']), display_name: v.str({ max: 120, optional: true }), permissions: v.strArr({ optional: true }), client_id: v.id({ optional: true }), vendor_id: v.id({ optional: true }) });
    const perms: string[] = b.permissions ? JSON.parse(b.permissions) : [];
    if (perms.some((p) => !(PERMS as readonly string[]).includes(p))) throw invalid('Permiso desconocido', { permissions: 'Valor no permitido' });
    if (b.role === 'staff' && c.user!.role !== 'owner' && perms.some((p) => !hasPerm(c.user!, p))) throw forbidden('No puedes otorgar permisos que tú no tienes');
    if (b.role === 'client' && !c.db.get('SELECT 1 x FROM clients WHERE id = ? AND org_id = ?', b.client_id ?? '', c.user!.org_id)) throw invalid('Indica un cliente válido', { client_id: 'Obligatorio' });
    if (b.role === 'vendor' && !c.db.get('SELECT 1 x FROM vendors WHERE id = ? AND org_id = ?', b.vendor_id ?? '', c.user!.org_id)) throw invalid('Indica un proveedor válido', { vendor_id: 'Obligatorio' });
    if (c.db.get('SELECT 1 x FROM users WHERE email = ?', b.email)) throw conflict('Ya existe una cuenta con ese correo');
    const t = token();
    const id = uid();
    c.db.run('INSERT INTO invitations (id, org_id, email, role, display_name, permissions, client_id, vendor_id, token_hash, expires_at, invited_by) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
      id, c.user!.org_id, b.email, b.role, b.display_name ?? null, JSON.stringify(b.role === 'staff' ? perms : []), b.role === 'client' ? b.client_id : null, b.role === 'vendor' ? b.vendor_id : null, sha256(t), new Date(Date.now() + 7 * 86400_000).toISOString(), c.user!.id);
    const link = `/#/invite?token=${t}`;
    c.db.run('INSERT INTO email_outbox (id, org_id, to_email, template, subject, body) VALUES (?,?,?,?,?,?)', uid(), c.user!.org_id, b.email, 'invitation', 'Te invitaron a la plataforma', `Activa tu cuenta: ${link}`);
    audit(c, 'user.invite', 'invitation', id, null, { email: b.email, role: b.role, permissions: perms });
    // Sin proveedor de correo configurado: el enlace se entrega a la planner para que lo comparta manualmente.
    return { ok: true, email_status: 'queued_not_sent', invite_url: link };
  });

  r.patch('/api/users/:id', (c) => { need(c.user!, 'users.manage');
    const b = parse(c.body, { permissions: v.strArr({ optional: true }), status: v.oneOf(['active', 'disabled'], { optional: true }) });   // el rol NO es editable
    const t = c.db.get('SELECT * FROM users WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id);
    if (!t) throw notFound('Usuario');
    if (t.role === 'owner') throw forbidden('La cuenta propietaria no se puede modificar desde aquí');
    if (t.id === c.user!.id) throw forbidden('No puedes modificar tu propia cuenta desde aquí');
    if (b.permissions) {
      if (t.role !== 'staff') throw invalid('Solo el personal interno tiene permisos configurables');
      const perms: string[] = JSON.parse(b.permissions);
      if (perms.some((p) => !(PERMS as readonly string[]).includes(p))) throw invalid('Permiso desconocido');
      if (c.user!.role !== 'owner' && perms.some((p) => !hasPerm(c.user!, p))) throw forbidden('No puedes otorgar permisos que tú no tienes');
    }
    c.db.tx(() => {
      c.db.run('UPDATE users SET permissions = COALESCE(?, permissions), status = COALESCE(?, status), updated_at = ? WHERE id = ?', b.permissions ?? null, b.status ?? null, new Date().toISOString(), t.id);
      if (b.status === 'disabled') c.db.run('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL', new Date().toISOString(), t.id);
      audit(c, b.status ? `user.${b.status}` : 'user.permissions', 'user', t.id, { permissions: JSON.parse(t.permissions), status: t.status }, { permissions: b.permissions ? JSON.parse(b.permissions) : undefined, status: b.status });
    });
    return { ok: true };
  });

  r.put('/api/settings/:key', (c) => { need(c.user!, 'settings.manage');
    if (!SETTING_KEYS.includes(c.params.key)) throw notFound('Configuración');
    const val = c.body?.value;
    if (typeof val !== 'object' || val === null) throw invalid('Valor inválido');
    if (c.params.key === 'brand') for (const [k, x] of Object.entries(val)) {
      if (/color/i.test(k) && !HEX.test(String(x))) throw invalid(`Color inválido en «${k}» (usa #RRGGBB)`);
      if (/font/i.test(k) && !FONT.test(String(x))) throw invalid(`Tipografía inválida en «${k}»`);
      if (/logo|cover/i.test(k) && x && !/^https:\/\//.test(String(x))) throw invalid(`«${k}» debe ser una URL https`);
    }
    const s = JSON.stringify(val); if (s.length > 20000) throw invalid('Demasiado grande');
    const old = c.db.get('SELECT value FROM organization_settings WHERE org_id = ? AND key = ?', c.user!.org_id, c.params.key);
    c.db.run('INSERT INTO organization_settings (org_id, key, value, updated_at) VALUES (?,?,?,?) ON CONFLICT(org_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at', c.user!.org_id, c.params.key, s, new Date().toISOString());
    audit(c, 'settings.update', 'setting', c.params.key, old ? JSON.parse(old.value) : null, val);
    return { ok: true };
  });
  r.get('/api/settings', (c) => { need(c.user!, 'settings.manage');
    const out: Record<string, unknown> = {};
    for (const row of c.db.all('SELECT key, value FROM organization_settings WHERE org_id = ?', c.user!.org_id)) out[row.key] = JSON.parse(row.value);
    return { settings: out };
  });

  r.get('/api/audit', (c) => { need(c.user!, 'audit.view');
    const entity = c.query.get('entity'); const lim = Math.min(Number(c.query.get('limit') ?? 100) || 100, 500);
    const rows = entity ? c.db.all('SELECT a.*, u.display_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE a.org_id = ? AND a.entity = ? ORDER BY a.created_at DESC LIMIT ?', c.user!.org_id, entity, lim)
      : c.db.all('SELECT a.*, u.display_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE a.org_id = ? ORDER BY a.created_at DESC LIMIT ?', c.user!.org_id, lim);
    return { logs: rows };
  });
  r.get('/api/integrations', (c) => { need(c.user!, 'settings.manage');
    return { integrations: c.db.all('SELECT kind, status, notes FROM integrations WHERE org_id = ?', c.user!.org_id) };
  });
  r.get('/api/outbox', (c) => { if (c.user!.role !== 'owner') throw forbidden();
    return { emails: c.db.all('SELECT id, to_email, template, subject, body, status, created_at FROM email_outbox WHERE org_id = ? ORDER BY created_at DESC LIMIT 50', c.user!.org_id), note: 'No hay proveedor de correo conectado: estos mensajes NO se han enviado.' };
  });
  void HttpError;
}
