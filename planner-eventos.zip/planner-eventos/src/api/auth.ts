import type { Router, Ctx } from '../http.ts';
import { Reply } from '../http.ts';
import { HttpError, forbidden, invalid, notFound, tooMany } from '../lib/errors.ts';
import { hashPassword, passwordProblem, sha256, token, verifyPassword } from '../lib/crypto.ts';
import { uid } from '../lib/db.ts';
import { config } from '../config.ts';
import { parse, v } from '../lib/validate.ts';
import { audit, rateLimit } from '../services.ts';

const GENERIC = () => new HttpError(401, 'invalid_credentials', 'Credenciales inválidas o cuenta temporalmente bloqueada');
const cookie = (val: string, maxAge: number) => `sid=${encodeURIComponent(val)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${config.secureCookies ? '; Secure' : ''}`;
const iso = (ms: number) => new Date(ms).toISOString();

export function meView(c: Ctx) {
  const u = c.user!;
  return { id: u.id, email: u.email, display_name: u.display_name, role: u.role, permissions: u.role === 'owner' ? ['*'] : u.permissions, client_id: u.client_id, vendor_id: u.vendor_id, prefs: u.prefs };
}

export function register(r: Router) {
  r.open('POST', '/api/auth/login', async (c) => {
    const b = parse(c.body, { email: v.str({ max: 254 }), password: v.str({ max: 200 }) });
    const email = String(b.email).toLowerCase();
    if (!rateLimit(c.db, `login:ip:${c.ip}`, 30, 900) || !rateLimit(c.db, `login:email:${email}`, 10, 900)) throw tooMany();
    const u = c.db.get('SELECT * FROM users WHERE email = ?', email);
    const ok = await verifyPassword(b.password, u?.password_hash);
    const locked = !!(u?.locked_until && u.locked_until > iso(Date.now()));
    if (!u || !ok || locked || u.status !== 'active') {
      if (u && !locked && u.status === 'active') {
        const n = u.failed_attempts + 1;
        c.db.run('UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?', n, n >= 5 ? iso(Date.now() + 15 * 60_000) : null, u.id);
      }
      audit({ db: c.db, user: null, ip: c.ip }, 'auth.login', 'user', u?.id ?? null, null, { email }, null, 'fail', u?.org_id);
      throw GENERIC();
    }
    c.db.run('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?', u.id);
    const t = token();
    c.db.run('INSERT INTO sessions (id, user_id, expires_at, user_agent) VALUES (?,?,?,?)', sha256(t), u.id, iso(Date.now() + config.sessionTtlHours * 3600_000), String(c.req.headers['user-agent'] ?? '').slice(0, 200));
    c.setCookie(cookie(t, config.sessionTtlHours * 3600));
    audit({ db: c.db, user: { org_id: u.org_id, id: u.id } as any, ip: c.ip }, 'auth.login', 'user', u.id, null, null);
    c.user = { id: u.id, org_id: u.org_id, role: u.role, email: u.email, display_name: u.display_name, permissions: JSON.parse(u.permissions), client_id: null, vendor_id: null, prefs: JSON.parse(u.prefs) };
    const cl = c.db.get('SELECT id FROM clients WHERE user_id = ?', u.id), vn = c.db.get('SELECT id FROM vendors WHERE user_id = ?', u.id);
    c.user.client_id = cl?.id ?? null; c.user.vendor_id = vn?.id ?? null;
    return { user: meView(c) };
  });

  r.post('/api/auth/logout', (c) => {
    c.db.run('UPDATE sessions SET revoked_at = ? WHERE id = ?', iso(Date.now()), sha256(c.cookies.sid));
    c.setCookie(cookie('', 0));
    return { ok: true };
  });

  r.open('GET', '/api/me', (c) => ({ user: c.user ? meView(c) : null }));

  r.patch('/api/me', (c) => {
    const b = parse(c.body, { display_name: v.str({ max: 120, optional: true }), phone: v.str({ max: 40, optional: true, nullable: true }), prefs: v.json({ optional: true }) });
    const prefs = b.prefs ? JSON.parse(b.prefs) : undefined;
    if (prefs && (typeof prefs.mute_noncritical !== 'boolean' && prefs.mute_noncritical !== undefined)) throw invalid('Preferencia inválida');
    c.db.run('UPDATE users SET display_name = COALESCE(?, display_name), phone = COALESCE(?, phone), prefs = COALESCE(?, prefs), updated_at = ? WHERE id = ?',
      b.display_name ?? null, b.phone ?? null, prefs ? JSON.stringify({ mute_noncritical: !!prefs.mute_noncritical }) : null, new Date().toISOString(), c.user!.id);
    return { ok: true };
  });

  r.post('/api/me/password', async (c) => {
    const b = parse(c.body, { current: v.str({ max: 200 }), next: v.str({ max: 200 }) });
    const u = c.db.get('SELECT password_hash FROM users WHERE id = ?', c.user!.id)!;
    if (!(await verifyPassword(b.current, u.password_hash))) throw invalid('La contraseña actual no es correcta', { current: 'Incorrecta' });
    const prob = passwordProblem(b.next, c.user!.email); if (prob) throw invalid(prob, { next: prob });
    c.db.run('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?', await hashPassword(b.next), iso(Date.now()), c.user!.id);
    c.db.run('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND id <> ? AND revoked_at IS NULL', iso(Date.now()), c.user!.id, sha256(c.cookies.sid));
    audit(c, 'auth.password_change', 'user', c.user!.id, null, null);
    return { ok: true };
  });

  // Respuesta idéntica exista o no la cuenta (anti-enumeración). Sin proveedor de correo, el enlace queda en la bandeja de salida.
  r.open('POST', '/api/auth/forgot', (c) => {
    const b = parse(c.body, { email: v.email() });
    if (!rateLimit(c.db, `forgot:ip:${c.ip}`, 10, 900)) throw tooMany();
    const u = c.db.get(`SELECT id, org_id, email FROM users WHERE email = ? AND status = 'active'`, b.email);
    if (u) {
      const t = token();
      c.db.run('INSERT INTO password_resets (id, user_id, token_hash, expires_at) VALUES (?,?,?,?)', uid(), u.id, sha256(t), iso(Date.now() + 3600_000));
      c.db.run('INSERT INTO email_outbox (id, org_id, to_email, template, subject, body) VALUES (?,?,?,?,?,?)', uid(), u.org_id, u.email, 'password_reset', 'Restablece tu contraseña', `Enlace (válido 1 hora): /#/reset?token=${t}`);
    }
    return { ok: true, message: 'Si el correo existe, recibirás instrucciones para restablecer tu contraseña.' };
  });

  r.open('POST', '/api/auth/reset', async (c) => {
    const b = parse(c.body, { token: v.str({ max: 200 }), password: v.str({ max: 200 }) });
    const pr = c.db.get('SELECT * FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > ?', sha256(b.token), iso(Date.now()));
    if (!pr) throw new HttpError(400, 'invalid_token', 'El enlace no es válido o ya caducó. Solicita uno nuevo.');
    const u = c.db.get('SELECT email FROM users WHERE id = ?', pr.user_id)!;
    const prob = passwordProblem(b.password, u.email); if (prob) throw invalid(prob, { password: prob });
    const h = await hashPassword(b.password);
    c.db.tx(() => {
      c.db.run('UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?', h, pr.user_id);
      c.db.run('UPDATE password_resets SET used_at = ? WHERE id = ?', iso(Date.now()), pr.id);
      c.db.run('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL', iso(Date.now()), pr.user_id);
    });
    return { ok: true };
  });

  r.open('POST', '/api/auth/accept-invite', async (c) => {
    const b = parse(c.body, { token: v.str({ max: 200 }), password: v.str({ max: 200 }), display_name: v.str({ max: 120, optional: true }), accept_privacy: v.bool() });
    if (!b.accept_privacy) throw invalid('Debes aceptar el aviso de privacidad', { accept_privacy: 'Obligatorio' });
    const inv = c.db.get('SELECT * FROM invitations WHERE token_hash = ? AND accepted_at IS NULL AND revoked_at IS NULL AND expires_at > ?', sha256(b.token), iso(Date.now()));
    if (!inv) throw new HttpError(400, 'invalid_token', 'La invitación no es válida o ya caducó');
    const prob = passwordProblem(b.password, inv.email); if (prob) throw invalid(prob, { password: prob });
    if (c.db.get('SELECT 1 x FROM users WHERE email = ?', inv.email)) throw new HttpError(409, 'conflict', 'Ya existe una cuenta con ese correo');
    const h = await hashPassword(b.password);
    const id = uid();
    c.db.tx(() => {
      c.db.run('INSERT INTO users (id, org_id, email, password_hash, display_name, role, permissions, status) VALUES (?,?,?,?,?,?,?,?)', id, inv.org_id, inv.email, h, b.display_name ?? inv.display_name ?? inv.email, inv.role, inv.permissions, 'active');
      if (inv.client_id) c.db.run('UPDATE clients SET user_id = ? WHERE id = ? AND user_id IS NULL', id, inv.client_id);
      if (inv.vendor_id) c.db.run('UPDATE vendors SET user_id = ? WHERE id = ? AND user_id IS NULL', id, inv.vendor_id);
      c.db.run('UPDATE invitations SET accepted_at = ? WHERE id = ?', iso(Date.now()), inv.id);
      c.db.run('INSERT INTO consents (id, user_id, kind, version) VALUES (?,?,?,?)', uid(), id, 'privacy_notice', '1');
      audit({ db: c.db, user: null, ip: c.ip }, 'auth.invite_accepted', 'user', id, null, { role: inv.role }, null, 'ok', inv.org_id);
    });
    return { ok: true };
  });

  r.open('GET', '/api/health', (c) => { c.db.get('SELECT 1 x'); return { ok: true }; });   // para monitoreo: no revela datos
  r.open('GET', '/api/brand', (c) => {
    const org = c.db.get('SELECT id, name FROM organizations ORDER BY created_at LIMIT 1');
    if (!org) return { name: 'Plataforma de eventos' };
    const s: Record<string, any> = {};
    for (const row of c.db.all('SELECT key, value FROM organization_settings WHERE org_id = ? AND key IN (?,?)', org.id, 'brand', 'locale')) s[row.key] = JSON.parse(row.value);
    return { org_name: org.name, brand: s.brand ?? {}, locale: s.locale ?? {} };
  });
  void forbidden; void notFound; void Reply;
}
