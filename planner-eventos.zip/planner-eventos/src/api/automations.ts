import type { Router } from '../http.ts';
import { notFound } from '../lib/errors.ts';
import { uid } from '../lib/db.ts';
import type { Db } from '../lib/db.ts';
import { parse, v } from '../lib/validate.ts';
import { addDays, todayIn } from '../lib/time.ts';
import { audit, need, notify, notifyClients, notifyPlanners } from '../services.ts';

type Rule = (db: Db, orgId: string, today: string, params: Record<string, any>) => number;
const count = (db: Db) => db.raw.prepare('SELECT changes() n').get().n as number;

// Cada regla es idempotente: usa dedupe_key, así que ejecutarla varias veces no duplica notificaciones.
const RULES: Record<string, Rule> = {
  mark_overdue_payments(db, org, today) {
    const rows = db.all(`SELECT p.id, p.event_id, e.folio FROM payments p JOIN events e ON e.id = p.event_id WHERE p.org_id = ? AND p.direction = 'in' AND p.status IN ('pending','scheduled','partially_paid') AND p.due_date < ?`, org, today);
    for (const p of rows) { db.run(`UPDATE payments SET status = 'overdue', updated_at = ? WHERE id = ?`, new Date().toISOString(), p.id); notifyPlanners(db, org, p.event_id, { type: 'payment_overdue', title: 'Pago vencido', body: p.folio, link: `#/events/${p.event_id}`, priority: 'high', dedupe: `overdue:${p.id}` }); }
    return rows.length;
  },
  payment_reminders(db, org, today, params) {
    const days = Number(params.days ?? 5); let n = 0;
    for (const p of db.all(`SELECT id, event_id, due_date FROM payments WHERE org_id = ? AND direction = 'in' AND status IN ('pending','scheduled','partially_paid') AND due_date BETWEEN ? AND ?`, org, today, addDays(today, days))) {
      notifyClients(db, org, p.event_id, { type: 'payment_due', title: 'Tienes un pago próximo', body: `Vence el ${p.due_date}`, link: '#/payments', dedupe: `payrem:${p.id}:${p.due_date}` }); n++;
    }
    return n;
  },
  document_expiry(db, org, today, params) {
    let n = 0;
    for (const d of db.all(`SELECT id, event_id, name, expires_on FROM documents WHERE org_id = ? AND status = 'active' AND expires_on IS NOT NULL AND expires_on <= ?`, org, addDays(today, Number(params.days ?? 30)))) { notifyPlanners(db, org, d.event_id, { type: 'document_expiry', title: 'Documento por vencer', body: `${d.name} · ${d.expires_on}`, dedupe: `docexp:${d.id}:${d.expires_on}` }); n++; }
    return n;
  },
  overdue_tasks(db, org, today) {
    let n = 0;
    for (const t of db.all(`SELECT id, event_id, title, assignee_user_id, audience, due_date FROM tasks WHERE org_id = ? AND status IN ('pending','in_progress','blocked') AND due_date < ?`, org, today)) {
      if (t.assignee_user_id) notify(db, { orgId: org, userId: t.assignee_user_id, eventId: t.event_id, type: 'task_overdue', title: 'Tarea atrasada', body: t.title, dedupe: `taskodue:${t.id}` });
      else if (t.audience === 'client') notifyClients(db, org, t.event_id, { type: 'task_overdue', title: 'Tarea atrasada', body: t.title, link: '#/tasks', dedupe: `taskodue:${t.id}` });
      else notifyPlanners(db, org, t.event_id, { type: 'task_overdue', title: 'Tarea atrasada', body: t.title, dedupe: `taskodue:${t.id}` });
      n++;
    }
    return n;
  },
  services_without_vendor(db, org) {
    let n = 0;
    for (const r of db.all(`SELECT r.id, r.event_id, e.folio FROM service_requests r JOIN events e ON e.id = r.event_id WHERE r.org_id = ? AND r.status = 'client_approved' AND NOT EXISTS (SELECT 1 FROM service_assignments a WHERE a.request_id = r.id AND a.status NOT IN ('rejected','cancelled'))`, org)) { notifyPlanners(db, org, r.event_id, { type: 'service_unassigned', title: 'Servicio aprobado sin proveedor', body: r.folio, link: `#/events/${r.event_id}`, dedupe: `unassigned:${r.id}` }); n++; }
    return n;
  },
  vendors_unconfirmed(db, org, today, params) {
    let n = 0;
    for (const a of db.all(`SELECT a.id, a.event_id, e.folio FROM service_assignments a JOIN events e ON e.id = a.event_id WHERE a.org_id = ? AND a.status = 'requested' AND a.created_at < ?`, org, new Date(Date.parse(today) - Number(params.days ?? 3) * 86400000).toISOString())) { notifyPlanners(db, org, a.event_id, { type: 'vendor_unconfirmed', title: 'Proveedor sin responder', body: a.folio, link: `#/events/${a.event_id}`, dedupe: `vunconf:${a.id}` }); n++; }
    return n;
  },
  upcoming_events(db, org, today, params) {
    let n = 0;
    for (const e of db.all(`SELECT id, folio, event_date FROM events WHERE org_id = ? AND status IN ('confirmed','planning','contracted') AND event_date BETWEEN ? AND ?`, org, today, addDays(today, Number(params.days ?? 7)))) { notifyPlanners(db, org, e.id, { type: 'event_upcoming', title: 'Evento próximo', body: `${e.folio} · ${e.event_date}`, link: `#/events/${e.id}`, dedupe: `upcoming:${e.id}` }); n++; }
    return n;
  },
  pending_guest_confirmations(db, org, today) {
    let n = 0;
    for (const e of db.all(`SELECT e.id, e.folio, COUNT(g.id) k FROM events e JOIN guests g ON g.event_id = e.id WHERE e.org_id = ? AND g.status IN ('invited','pending','no_response') AND e.event_date BETWEEN ? AND ? GROUP BY e.id`, org, today, addDays(today, 30))) { notifyClients(db, org, e.id, { type: 'guest_pending', title: 'Invitados sin confirmar', body: `${e.k} invitados pendientes`, link: '#/guests', dedupe: `guestpend:${e.id}:${today.slice(0, 7)}` }); n++; }
    return n;
  },
};

export function runAutomations(db: Db, orgId: string, now = new Date()) {
  const today = todayIn('America/Mexico_City', now); const results: { kind: string; status: string; created: number; error?: string }[] = [];
  for (const rule of db.all('SELECT * FROM automation_rules WHERE org_id = ? AND enabled = 1', orgId)) {
    const started = new Date().toISOString(); const fn = RULES[rule.kind];
    try { const created = db.tx(() => fn(db, orgId, today, JSON.parse(rule.params))); db.run('INSERT INTO automation_runs (id, org_id, rule_id, started_at, finished_at, status, created_count) VALUES (?,?,?,?,?,?,?)', uid(), orgId, rule.id, started, new Date().toISOString(), 'ok', created); results.push({ kind: rule.kind, status: 'ok', created }); }
    catch (e) { db.run('INSERT INTO automation_runs (id, org_id, rule_id, started_at, finished_at, status, error) VALUES (?,?,?,?,?,?,?)', uid(), orgId, rule.id, started, new Date().toISOString(), 'error', (e as Error).message.slice(0, 300)); results.push({ kind: rule.kind, status: 'error', created: 0, error: (e as Error).message }); }
  }
  void count; return results;
}
export const AUTOMATION_KINDS = Object.keys(RULES);

export function register(r: Router) {
  r.get('/api/automations', (c) => { need(c.user!, 'settings.manage');
    return { rules: c.db.all('SELECT * FROM automation_rules WHERE org_id = ?', c.user!.org_id), runs: c.db.all('SELECT r.kind, a.started_at, a.status, a.created_count, a.error FROM automation_runs a JOIN automation_rules r ON r.id = a.rule_id WHERE a.org_id = ? ORDER BY a.started_at DESC LIMIT 30', c.user!.org_id) };
  });
  r.post('/api/automations/run', (c) => { need(c.user!, 'settings.manage'); const out = runAutomations(c.db, c.user!.org_id); audit(c, 'automation.run', 'automation', null, null, { results: out.length }); return { results: out }; });
  r.patch('/api/automations/:id', (c) => { need(c.user!, 'settings.manage');
    const b = parse(c.body, { enabled: v.bool() });
    if (!c.db.run('UPDATE automation_rules SET enabled = ? WHERE id = ? AND org_id = ?', b.enabled, c.params.id, c.user!.org_id).changes) throw notFound('Regla');
    return { ok: true };
  });
}
