import fs from 'node:fs';
import path from 'node:path';
import type { Router, Ctx, User } from '../http.ts';
import { Reply } from '../http.ts';
import { forbidden, invalid, notFound, conflict } from '../lib/errors.ts';
import { uid } from '../lib/db.ts';
import type { Row } from '../lib/db.ts';
import { parse, v } from '../lib/validate.ts';
import { config } from '../config.ts';
import { sha256, signDownload, token, verifyDownload } from '../lib/crypto.ts';
import { audit, getEvent, hasPerm, isStaff, need, notify, notifyPlanners } from '../services.ts';
import { accessibleEventIds } from './events.ts';

const MIMES: Record<string, (b: Buffer) => boolean> = {
  'application/pdf': (b) => b.subarray(0, 5).toString('latin1') === '%PDF-',
  'image/png': (b) => b.subarray(0, 8).toString('hex') === '89504e470d0a1a0a',
  'image/jpeg': (b) => b[0] === 0xff && b[1] === 0xd8,
  'image/webp': (b) => b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP',
  'text/plain': (b) => !b.includes(0),
  'text/csv': (b) => !b.includes(0),
};

/** Regla única de acceso a un documento (se reevalúa en listado, enlace y descarga). */
export function canSeeDoc(c: Ctx, d: Row): boolean {
  const u = c.user!;
  if (d.org_id !== u.org_id) return false;
  if (u.role === 'owner') return true;
  if (u.role === 'staff') {
    if (!u.permissions.includes('documents.manage') && d.uploaded_by !== u.id) return false;
    if (d.event_id) { const ids = accessibleEventIds(c); return ids === 'all' || ids.includes(d.event_id); }
    return u.permissions.includes('vendors.manage') || d.uploaded_by === u.id;
  }
  if (d.uploaded_by === u.id) return true;
  if (u.role === 'client') return !!d.event_id && d.visibility === 'client' && !!u.client_id && !!c.db.get('SELECT 1 x FROM client_event_memberships WHERE event_id = ? AND client_id = ?', d.event_id, u.client_id);
  if (u.role === 'vendor') return !!u.vendor_id && d.status === 'active' && (d.vendor_id === u.vendor_id || !!c.db.get('SELECT 1 x FROM document_permissions WHERE document_id = ? AND vendor_id = ?', d.id, u.vendor_id));
  return false;
}

function storeDocument(c: Ctx, eventId: string | null, vendorId: string | null, b: Record<string, any>, visibility: string, vendorIds: string[]) {
  const check = MIMES[b.mime]; if (!check) throw invalid('Tipo de archivo no permitido (PDF, PNG, JPG, WEBP, TXT o CSV)', { mime: 'No permitido' });
  if (!/^[A-Za-z0-9+/=\s]+$/.test(b.data_base64)) throw invalid('Archivo codificado incorrectamente');
  const buf = Buffer.from(b.data_base64, 'base64');
  if (!buf.length) throw invalid('El archivo está vacío');
  if (buf.length > config.maxUploadBytes) throw invalid(`El archivo supera ${Math.round(config.maxUploadBytes / 1048576)} MB`);
  if (!check(buf)) throw invalid('El contenido del archivo no corresponde a su tipo');
  const key = token(32).replace(/[^A-Za-z0-9]/g, 'x');
  const dir = path.join(config.storageDir, c.user!.org_id); fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, key), buf, { mode: 0o600 });
  let version = 1; let supersedes: string | null = null;
  if (b.supersedes_id) { const old = c.db.get('SELECT * FROM documents WHERE id = ? AND org_id = ?', b.supersedes_id, c.user!.org_id); if (!old || !canSeeDoc(c, old)) throw notFound('Documento'); version = old.version + 1; supersedes = old.id; }
  const id = uid();
  c.db.tx(() => {
    c.db.run('INSERT INTO documents (id, org_id, event_id, vendor_id, kind, name, storage_key, mime, size_bytes, sha256, version, supersedes_id, visibility, expires_on, uploaded_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      id, c.user!.org_id, eventId, vendorId, b.kind ?? 'other', b.name, key, b.mime, buf.length, sha256(buf), version, supersedes, visibility, b.expires_on, c.user!.id);
    if (supersedes) c.db.run(`UPDATE documents SET status = 'archived' WHERE id = ?`, supersedes);
    for (const vid of vendorIds) c.db.run('INSERT OR IGNORE INTO document_permissions (document_id, vendor_id) VALUES (?,?)', id, vid);
    audit(c, 'document.upload', 'document', id, null, { name: b.name, kind: b.kind, version, visibility });
  });
  return { id, version };
}
const DOC = { name: v.str({ max: 200 }), kind: v.str({ max: 40, optional: true }), mime: v.str({ max: 60 }), data_base64: v.str({ max: 8_000_000, min: 4 }), expires_on: v.date({ optional: true }), supersedes_id: v.id({ optional: true }) };

function convAccess(c: Ctx, id: string): Row {
  const cv = c.db.get('SELECT * FROM conversations WHERE id = ? AND org_id = ?', id, c.user!.org_id); if (!cv) throw notFound('Conversación');
  const u = c.user!;
  if (cv.participant_user_id === u.id) return cv;
  if (u.role === 'owner') return cv;
  if (u.role === 'staff') {
    if (cv.event_id) { const ids = accessibleEventIds(c); if (ids === 'all' || ids.includes(cv.event_id)) return cv; }
    else if (hasPerm(u, cv.kind === 'client' ? 'clients.manage' : 'vendors.manage')) return cv;
  }
  throw notFound('Conversación');
}

export function register(r: Router) {
  // ───── Documentos ─────
  r.post('/api/events/:id/documents', (c) => {
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { ...DOC, visibility: v.oneOf(['internal', 'client', 'vendor'], { optional: true }), vendor_ids: v.strArr({ optional: true }) });
    let visibility = b.visibility ?? 'internal'; let vendorIds: string[] = b.vendor_ids ? JSON.parse(b.vendor_ids) : [];
    if (isStaff(c.user!)) { need(c.user!, 'documents.manage'); for (const vid of vendorIds) if (!c.db.get('SELECT 1 x FROM service_assignments WHERE event_id = ? AND vendor_id = ?', e.id, vid)) throw invalid('Solo puedes compartir con proveedores asignados a este evento'); }
    else if (c.user!.role === 'client') { visibility = 'internal'; vendorIds = []; }   // lo que sube el cliente solo lo ve la planner y él mismo
    else throw forbidden();
    const out = storeDocument(c, e.id, null, b, visibility, vendorIds);
    if (!isStaff(c.user!)) notifyPlanners(c.db, e.org_id, e.id, { type: 'document_uploaded', title: 'El cliente subió un documento', body: e.folio, link: `#/events/${e.id}` });
    return out;
  });
  r.post('/api/vendor/documents', (c) => {
    if (c.user!.role !== 'vendor' || !c.user!.vendor_id) throw forbidden();
    const b = parse(c.body, DOC);
    return storeDocument(c, null, c.user!.vendor_id, b, 'internal', []);
  });
  r.get('/api/events/:id/documents', (c) => {
    const e = getEvent(c, c.params.id);
    const rows = c.db.all(`SELECT id, org_id, event_id, vendor_id, kind, name, mime, size_bytes, version, status, visibility, expires_on, uploaded_by, created_at FROM documents WHERE event_id = ? ORDER BY created_at DESC`, e.id);
    return { documents: rows.filter((d) => canSeeDoc(c, d)).map(({ org_id, ...x }) => { void org_id; return x; }) };
  });
  r.post('/api/documents/:id/link', (c) => {
    const d = c.db.get('SELECT * FROM documents WHERE id = ?', c.params.id);
    if (!d || !canSeeDoc(c, d)) throw notFound('Documento');
    audit(c, 'document.link', 'document', d.id, null, null);
    return { url: `/api/documents/${d.id}/download?${signDownload(d.id, c.user!.id)}`, expires_in: 120 };
  });
  r.get('/api/documents/:id/download', (c) => {
    const d = c.db.get('SELECT * FROM documents WHERE id = ?', c.params.id);
    if (!d || !canSeeDoc(c, d) || !verifyDownload(d.id, c.user!.id, c.query.get('exp') ?? '', c.query.get('sig') ?? '')) throw notFound('Documento');
    const file = path.join(config.storageDir, d.org_id, d.storage_key);
    if (!fs.existsSync(file)) throw notFound('Archivo');
    audit(c, 'document.download', 'document', d.id, null, null);
    return new Reply(200, fs.readFileSync(file), { 'content-type': d.mime, 'content-disposition': `attachment; filename="${encodeURIComponent(d.name)}"`, 'x-content-type-options': 'nosniff' });
  });

  // ───── Conversaciones (siempre con la planner) ─────
  r.get('/api/conversations', (c) => {
    const u = c.user!; let rows: Row[];
    if (isStaff(u)) rows = c.db.all(`SELECT cv.*, p.display_name AS participant_name, e.folio FROM conversations cv JOIN users p ON p.id = cv.participant_user_id LEFT JOIN events e ON e.id = cv.event_id WHERE cv.org_id = ? ORDER BY cv.created_at DESC LIMIT 200`, u.org_id).filter((cv) => { try { convAccess(c, cv.id); return true; } catch { return false; } });
    else rows = c.db.all(`SELECT cv.id, cv.kind, cv.subject, cv.event_id, cv.created_at, e.folio FROM conversations cv LEFT JOIN events e ON e.id = cv.event_id WHERE cv.participant_user_id = ? ORDER BY cv.created_at DESC`, u.id);
    return { conversations: rows };
  });
  r.post('/api/conversations', (c) => {
    const u = c.user!;
    const b = parse(c.body, { event_id: v.id({ optional: true }), subject: v.str({ max: 160 }), body: v.str({ max: 4000, optional: true }), participant_user_id: v.id({ optional: true }) });
    let participant: User | Row | undefined; let kind: 'client' | 'vendor';
    if (isStaff(u)) {
      participant = c.db.get(`SELECT id, role FROM users WHERE id = ? AND org_id = ? AND role IN ('client','vendor') AND status = 'active'`, b.participant_user_id ?? '', u.org_id);
      if (!participant) throw invalid('Destinatario no válido', { participant_user_id: 'Debe ser un cliente o proveedor activo' });
      kind = participant.role;
    } else { participant = { id: u.id, role: u.role }; kind = u.role as 'client' | 'vendor'; }
    if (b.event_id) {
      if (isStaff(u)) getEvent(c, b.event_id);
      const ok = kind === 'client'
        ? c.db.get('SELECT 1 x FROM client_event_memberships m JOIN clients cl ON cl.id = m.client_id WHERE m.event_id = ? AND cl.user_id = ?', b.event_id, participant!.id)
        : c.db.get('SELECT 1 x FROM service_assignments a JOIN vendors vn ON vn.id = a.vendor_id WHERE a.event_id = ? AND vn.user_id = ?', b.event_id, participant!.id);
      if (!ok) throw notFound('Evento');
    }
    const id = uid();
    c.db.tx(() => {
      c.db.run('INSERT INTO conversations (id, org_id, event_id, kind, participant_user_id, subject) VALUES (?,?,?,?,?,?)', id, u.org_id, b.event_id, kind, participant!.id, b.subject);
      if (b.body) c.db.run('INSERT INTO messages (id, conversation_id, author_id, body) VALUES (?,?,?,?)', uid(), id, u.id, b.body);
    });
    if (!isStaff(u)) notifyPlanners(c.db, u.org_id, b.event_id ?? null, { type: 'message', title: 'Tienes un mensaje nuevo', link: '#/messages' });
    else notify(c.db, { orgId: u.org_id, userId: participant!.id, type: 'message', title: 'Tienes un mensaje nuevo', link: '#/messages' });
    return { id };
  });
  r.get('/api/conversations/:id/messages', (c) => {
    const cv = convAccess(c, c.params.id);
    return { conversation: { id: cv.id, subject: cv.subject, kind: cv.kind }, messages: c.db.all('SELECT m.id, m.body, m.created_at, m.author_id, (m.author_id = cv.participant_user_id) AS from_participant FROM messages m JOIN conversations cv ON cv.id = m.conversation_id WHERE m.conversation_id = ? ORDER BY m.created_at', cv.id) };
  });
  r.post('/api/conversations/:id/messages', (c) => {
    const cv = convAccess(c, c.params.id);
    const b = parse(c.body, { body: v.str({ max: 4000 }) });
    c.db.run('INSERT INTO messages (id, conversation_id, author_id, body) VALUES (?,?,?,?)', uid(), cv.id, c.user!.id, b.body);
    // Notificaciones genéricas: sin vista previa del contenido ni nombres de otros participantes
    if (c.user!.id === cv.participant_user_id) notifyPlanners(c.db, cv.org_id, cv.event_id, { type: 'message', title: 'Tienes un mensaje nuevo', link: '#/messages' });
    else notify(c.db, { orgId: cv.org_id, userId: cv.participant_user_id, type: 'message', title: 'Tienes un mensaje nuevo', link: '#/messages' });
    return { ok: true };
  });

  // ───── Notificaciones ─────
  r.get('/api/notifications', (c) => ({
    notifications: c.db.all('SELECT id, type, title, body, link, priority, read_at, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100', c.user!.id),
    unread: c.db.get('SELECT COUNT(*) n FROM notifications WHERE user_id = ? AND read_at IS NULL', c.user!.id)!.n,
  }));
  r.post('/api/notifications/read', (c) => {
    const b = parse(c.body, { ids: v.strArr({ optional: true, max: 200 }), all: v.bool({ optional: true }) });
    const now = new Date().toISOString();
    if (b.all) c.db.run('UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL', now, c.user!.id);
    else for (const id of b.ids ? JSON.parse(b.ids) : []) c.db.run('UPDATE notifications SET read_at = ? WHERE id = ? AND user_id = ?', now, id, c.user!.id);
    return { ok: true };
  });
  void conflict;
}
