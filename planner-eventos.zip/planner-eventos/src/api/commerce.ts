import type { Router, Ctx } from '../http.ts';
import { conflict, forbidden, invalid, notFound } from '../lib/errors.ts';
import { uid } from '../lib/db.ts';
import type { Row } from '../lib/db.ts';
import { parse, v } from '../lib/validate.ts';
import { ASSIGNMENT_TRANSITIONS, CLIENT_CANCELLABLE, REQUEST_TRANSITIONS, canTransition } from '../domain/states.ts';
import { computeQuote } from '../domain/finance.ts';
import { checkAvailability } from '../domain/availability.ts';
import { lineAmount } from '../domain/money.ts';
import { audit, getEvent, isStaff, need, needStaff, notify, notifyClients, notifyPlanners, hasPerm } from '../services.ts';

const PRICE_TYPES = ['fixed', 'per_person', 'per_hour', 'per_day', 'per_unit', 'per_meter', 'per_package', 'custom', 'quote'] as const;

function clientService(s: Row) {   // proyección pública: sin notas internas ni proveedor
  const { internal_notes, vendor_id, active, visible_to_client, ...rest } = s;
  void internal_notes; void vendor_id; void active; void visible_to_client;
  return { ...rest, details: JSON.parse(rest.details) };
}
function getRequest(c: Ctx, id: string): { req: Row; event: Row } {
  const req = c.db.get('SELECT * FROM service_requests WHERE id = ? AND org_id = ?', id, c.user!.org_id);
  if (!req) throw notFound('Solicitud');
  return { req, event: getEvent(c, req.event_id) };
}
export function clientRequestView(r: Row) {
  const { planner_notes, ...rest } = r; void planner_notes; return rest;
}

export function register(r: Router) {
  // ───── Catálogo ─────
  r.get('/api/catalog', (c) => {
    const cats = c.db.all('SELECT id, name FROM service_categories WHERE org_id = ? ORDER BY sort, name', c.user!.org_id);
    if (isStaff(c.user!)) {
      need(c.user!, 'catalog.manage');
      return { categories: cats, services: c.db.all('SELECT * FROM service_catalog WHERE org_id = ? ORDER BY name', c.user!.org_id).map((s) => ({ ...s, details: JSON.parse(s.details) })) };
    }
    if (c.user!.role !== 'client') throw forbidden();
    const q = c.query.get('q'); const cat = c.query.get('category');
    let sql = 'SELECT * FROM service_catalog WHERE org_id = ? AND active = 1 AND visible_to_client = 1'; const p: any[] = [c.user!.org_id];
    if (cat) { sql += ' AND category_id = ?'; p.push(cat); }
    if (q) { sql += ' AND (name LIKE ? OR description LIKE ?)'; p.push(`%${q}%`, `%${q}%`); }
    const services = c.db.all(sql + ' ORDER BY name', ...p).map((s) => ({ ...clientService(s), packages: c.db.all('SELECT id, name, description, price_cents FROM service_packages WHERE service_id = ? AND active = 1', s.id) }));
    return { categories: cats, services };
  });
  r.post('/api/catalog/categories', (c) => { need(c.user!, 'catalog.manage');
    const b = parse(c.body, { name: v.str({ max: 80 }) }); const id = uid();
    c.db.run('INSERT INTO service_categories (id, org_id, name) VALUES (?,?,?)', id, c.user!.org_id, b.name);
    return { id, name: b.name };
  });
  const SVC = { category_id: v.id(), name: v.str({ max: 160 }), description: v.str({ max: 3000, optional: true }), price_type: v.oneOf(PRICE_TYPES, { optional: true }),
    base_price_cents: v.int({ min: 0, optional: true, nullable: true }), unit_label: v.str({ max: 40, optional: true }), min_qty_milli: v.int({ min: 1, optional: true }), max_qty_milli: v.int({ min: 1, optional: true, nullable: true }),
    tax_bps: v.int({ min: 0, max: 10000, optional: true }), advance_bps: v.int({ min: 0, max: 10000, optional: true }), visible_to_client: v.bool({ optional: true }), active: v.bool({ optional: true }),
    vendor_id: v.id({ optional: true, nullable: true }), internal_notes: v.str({ max: 2000, optional: true, nullable: true }), details: v.json({ optional: true }) };
  r.post('/api/catalog/services', (c) => { need(c.user!, 'catalog.manage');
    const b = parse(c.body, SVC);
    if (!c.db.get('SELECT 1 x FROM service_categories WHERE id = ? AND org_id = ?', b.category_id, c.user!.org_id)) throw invalid('Categoría no válida');
    if (b.vendor_id && !c.db.get('SELECT 1 x FROM vendors WHERE id = ? AND org_id = ?', b.vendor_id, c.user!.org_id)) throw invalid('Proveedor no válido');
    const id = uid();
    c.db.run(`INSERT INTO service_catalog (id, org_id, category_id, name, description, price_type, base_price_cents, unit_label, min_qty_milli, max_qty_milli, tax_bps, advance_bps, visible_to_client, active, vendor_id, internal_notes, details)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, id, c.user!.org_id, b.category_id, b.name, b.description, b.price_type ?? 'fixed', b.base_price_cents, b.unit_label, b.min_qty_milli ?? 1000, b.max_qty_milli, b.tax_bps ?? 1600, b.advance_bps ?? 5000, b.visible_to_client ?? 1, b.active ?? 1, b.vendor_id, b.internal_notes, b.details ?? '{}');
    audit(c, 'catalog.create', 'service', id, null, { name: b.name, price: b.base_price_cents });
    return c.db.get('SELECT * FROM service_catalog WHERE id = ?', id);
  });
  r.patch('/api/catalog/services/:id', (c) => { need(c.user!, 'catalog.manage');
    const s = c.db.get('SELECT * FROM service_catalog WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!s) throw notFound('Servicio');
    const spec: any = {}; for (const k of Object.keys(SVC)) spec[k] = (SVC as any)[k]; spec.category_id = v.id({ optional: true }); spec.name = v.str({ max: 160, optional: true });
    const b = parse(c.body, spec); const keys = Object.keys(b); if (!keys.length) return s;
    const priceChanged = b.base_price_cents !== undefined && b.base_price_cents !== s.base_price_cents;
    c.db.tx(() => {
      c.db.run(`UPDATE service_catalog SET ${keys.map((k) => `${k} = ?`).join(', ')}, price_version = price_version + ?, updated_at = ? WHERE id = ?`, ...keys.map((k) => b[k]), priceChanged ? 1 : 0, new Date().toISOString(), s.id);
      audit(c, priceChanged ? 'catalog.price_change' : 'catalog.update', 'service', s.id, Object.fromEntries(keys.map((k) => [k, s[k]])), b);
    });
    return c.db.get('SELECT * FROM service_catalog WHERE id = ?', s.id);
  });

  // ───── Solicitudes ─────
  r.get('/api/events/:id/requests', (c) => {
    const e = getEvent(c, c.params.id);
    const rows = c.db.all(`SELECT r.*, s.name AS service_name, s.price_type, s.unit_label, p.name AS package_name FROM service_requests r JOIN service_catalog s ON s.id = r.service_id LEFT JOIN service_packages p ON p.id = r.package_id WHERE r.event_id = ? ORDER BY r.created_at`, e.id);
    return { requests: isStaff(c.user!) ? rows : rows.map(clientRequestView) };
  });
  r.post('/api/events/:id/requests', (c) => {
    const e = getEvent(c, c.params.id);
    if (!isStaff(c.user!) && c.user!.role !== 'client') throw forbidden();
    if (isStaff(c.user!)) need(c.user!, 'events.write');
    const b = parse(c.body, { service_id: v.id(), package_id: v.id({ optional: true }), qty_milli: v.int({ min: 1, max: 100_000_000, optional: true }), client_notes: v.str({ max: 2000, optional: true }) });
    const s = c.db.get('SELECT * FROM service_catalog WHERE id = ? AND org_id = ?', b.service_id, c.user!.org_id);
    if (!s || (!isStaff(c.user!) && (!s.active || !s.visible_to_client))) throw notFound('Servicio');
    if (b.package_id && !c.db.get('SELECT 1 x FROM service_packages WHERE id = ? AND service_id = ? AND active = 1', b.package_id, s.id)) throw invalid('Paquete no válido');
    const qty = b.qty_milli ?? s.min_qty_milli;
    if (qty < s.min_qty_milli || (s.max_qty_milli && qty > s.max_qty_milli)) throw invalid('Cantidad fuera del rango permitido para este servicio', { qty_milli: 'Fuera de rango' });
    if (['cancelled', 'archived', 'closed'].includes(e.status)) throw conflict('El evento ya no admite solicitudes');
    const id = uid();
    c.db.run('INSERT INTO service_requests (id, org_id, event_id, service_id, package_id, qty_milli, client_notes, status, created_by) VALUES (?,?,?,?,?,?,?,?,?)', id, c.user!.org_id, e.id, s.id, b.package_id, qty, b.client_notes, 'requested', c.user!.id);
    audit(c, 'request.create', 'service_request', id, null, { service: s.name, qty });
    if (!isStaff(c.user!)) notifyPlanners(c.db, c.user!.org_id, e.id, { type: 'request_new', title: 'Nueva solicitud de servicio', body: `${e.folio} · ${s.name}`, link: `#/events/${e.id}`, dedupe: `req:${id}` });
    return c.db.get('SELECT * FROM service_requests WHERE id = ?', id);
  });

  // La planner fija precio/descuento/notas (el cliente jamás puede). Si ya estaba aprobada, queda pendiente de una nueva versión.
  r.patch('/api/requests/:id', (c) => { need(c.user!, 'finance.manage');
    const { req } = getRequest(c, c.params.id);
    const b = parse(c.body, { unit_price_cents: v.int({ min: 0, optional: true }), discount_cents: v.int({ min: 0, optional: true }), tax_bps: v.int({ min: 0, max: 10000, optional: true }), qty_milli: v.int({ min: 1, optional: true }), planner_notes: v.str({ max: 2000, optional: true, nullable: true }), reason: v.str({ max: 300, optional: true }) });
    const { reason, ...f } = b; const keys = Object.keys(f); if (!keys.length) return req;
    const pricing = keys.some((k) => ['unit_price_cents', 'discount_cents', 'tax_bps', 'qty_milli'].includes(k));
    if (pricing && ['client_approved', 'pending_vendor', 'confirmed', 'contracted'].includes(req.status) && !reason) throw invalid('Cambiar un precio ya aprobado requiere indicar el motivo', { reason: 'Obligatorio' });
    c.db.tx(() => {
      c.db.run(`UPDATE service_requests SET ${keys.map((k) => `${k} = ?`).join(', ')}, price_version = price_version + ?, updated_at = ? WHERE id = ?`, ...keys.map((k) => f[k]), pricing ? 1 : 0, new Date().toISOString(), req.id);
      audit(c, pricing ? 'request.price_change' : 'request.update', 'service_request', req.id, Object.fromEntries(keys.map((k) => [k, req[k]])), f, reason);
    });
    return c.db.get('SELECT * FROM service_requests WHERE id = ?', req.id);
  });

  r.post('/api/requests/:id/status', (c) => {
    const { req, event } = getRequest(c, c.params.id);
    const b = parse(c.body, { to: v.oneOf(Object.keys(REQUEST_TRANSITIONS)), note: v.str({ max: 500, optional: true }) });
    if (!canTransition(REQUEST_TRANSITIONS, req.status, b.to)) throw conflict(`Transición no permitida: ${req.status} → ${b.to}`);
    if (!isStaff(c.user!)) {   // el cliente solo puede retirar su solicitud antes de aprobar
      if (!(b.to === 'cancelled' && CLIENT_CANCELLABLE.has(req.status))) throw forbidden('Solo tu planner puede realizar este cambio');
    } else {
      need(c.user!, 'events.write');
      if (['quote_sent', 'client_approved'].includes(b.to)) throw conflict('Ese estado se alcanza enviando la cotización / cuando el cliente la acepta');
      if (['pending_vendor'].includes(b.to)) throw conflict('Se alcanza al asignar un proveedor');
      if (b.to === 'confirmed' && !c.db.get(`SELECT 1 x FROM service_assignments WHERE request_id = ? AND status = 'confirmed'`, req.id) && c.db.get('SELECT vendor_id FROM service_catalog WHERE id = ?', req.service_id)?.vendor_id !== null) throw conflict('Confirma primero la asignación del proveedor');
    }
    c.db.tx(() => {
      c.db.run('UPDATE service_requests SET status = ?, planner_message = CASE WHEN ? IS NOT NULL AND ? IN (\'info_required\',\'rejected\') THEN ? ELSE planner_message END, updated_at = ? WHERE id = ?', b.to, b.note ?? null, b.to, b.note ?? null, new Date().toISOString(), req.id);
      audit(c, 'request.status', 'service_request', req.id, { status: req.status }, { status: b.to }, b.note);
    });
    const label = c.db.get('SELECT name FROM service_catalog WHERE id = ?', req.service_id)!.name;
    if (isStaff(c.user!) && ['info_required', 'rejected', 'confirmed'].includes(b.to)) notifyClients(c.db, event.org_id, event.id, { type: 'request_update', title: 'Actualización de tu solicitud', body: label, link: '#/requests' });
    if (!isStaff(c.user!)) notifyPlanners(c.db, event.org_id, event.id, { type: 'request_cancelled', title: 'El cliente retiró una solicitud', body: `${event.folio} · ${label}` });
    return { ok: true, status: b.to };
  });

  // ───── Cotizaciones (versionadas) ─────
  r.get('/api/events/:id/quote', (c) => {
    const e = getEvent(c, c.params.id);
    const q = c.db.get('SELECT * FROM quotes WHERE event_id = ?', e.id);
    if (!q) return { quote: null, versions: [] };
    const versions = c.db.all('SELECT * FROM quote_versions WHERE quote_id = ? ORDER BY version DESC', q.id)
      .filter((x) => isStaff(c.user!) || x.status !== 'draft')
      .map((x) => ({ ...x, items: c.db.all('SELECT * FROM quote_items WHERE version_id = ?', x.id) }));
    return { quote: q, versions };
  });

  r.post('/api/events/:id/quote/versions', (c) => { need(c.user!, 'finance.manage');
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { charges_cents: v.int({ min: 0, optional: true }), charges_note: v.str({ max: 300, optional: true }), note: v.str({ max: 1000, optional: true }) });
    const reqs = c.db.all(`SELECT r.*, s.name, s.tax_bps AS s_tax, s.advance_bps, s.base_price_cents, p.price_cents AS pkg_price FROM service_requests r JOIN service_catalog s ON s.id = r.service_id LEFT JOIN service_packages p ON p.id = r.package_id
      WHERE r.event_id = ? AND r.status IN ('in_review','quote_preparing','quote_sent','client_approved','pending_vendor','confirmed','contracted')`, e.id);
    if (!reqs.length) throw conflict('No hay solicitudes para cotizar');
    const lines = reqs.map((r2) => {
      const unit = r2.unit_price_cents ?? r2.pkg_price ?? r2.base_price_cents;
      if (unit == null) throw conflict(`Fija el precio de «${r2.name}» antes de cotizar`, { request_id: r2.id });
      return { description: r2.name, qtyMilli: r2.qty_milli, unitPriceCents: unit, discountCents: r2.discount_cents, taxBps: r2.tax_bps ?? r2.s_tax, requestId: r2.id };
    });
    let totals; try { totals = computeQuote(lines, { chargesCents: b.charges_cents, chargesTaxBps: lines[0].taxBps, advanceBps: reqs[0].advance_bps }); } catch (err) { throw invalid((err as Error).message); }
    const vid = uid();
    c.db.tx(() => {
      let q = c.db.get('SELECT * FROM quotes WHERE event_id = ?', e.id);
      if (!q) { const qid = uid(); c.db.run('INSERT INTO quotes (id, org_id, event_id) VALUES (?,?,?)', qid, e.org_id, e.id); q = { id: qid, current_version: 0 }; }
      const version = q.current_version + 1;
      c.db.run(`UPDATE quote_versions SET status = 'superseded' WHERE quote_id = ? AND status IN ('sent','accepted','draft')`, q.id);
      c.db.run('INSERT INTO quote_versions (id, quote_id, version, status, subtotal_cents, discount_cents, charges_cents, charges_note, tax_cents, total_cents, advance_cents, note, sent_at, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        vid, q.id, version, 'sent', totals.subtotalCents, totals.discountCents, totals.chargesCents, b.charges_note, totals.taxCents, totals.totalCents, totals.advanceCents, b.note, new Date().toISOString(), c.user!.id);
      for (const l of totals.lines) c.db.run('INSERT INTO quote_items (id, version_id, request_id, description, qty_milli, unit_price_cents, discount_cents, tax_bps, line_gross_cents, line_tax_cents, line_total_cents) VALUES (?,?,?,?,?,?,?,?,?,?,?)', uid(), vid, l.requestId ?? null, l.description, l.qtyMilli, l.unitPriceCents, l.discountCents ?? 0, l.taxBps, l.grossCents, l.taxCents, l.totalCents);
      c.db.run('UPDATE quotes SET current_version = ? WHERE id = ?', version, q.id);
      // Solo las solicitudes aún no contratadas vuelven a "cotización enviada"; las ya aprobadas requieren nueva aceptación
      c.db.run(`UPDATE service_requests SET status = 'quote_sent', updated_at = ? WHERE event_id = ? AND status IN ('in_review','quote_preparing','quote_sent','client_approved')`, new Date().toISOString(), e.id);
      if (['preparing', 'proposal_drafting'].includes(e.status)) c.db.run(`UPDATE events SET status = 'proposal_sent', updated_at = ? WHERE id = ?`, new Date().toISOString(), e.id);
      audit(c, 'quote.version', 'quote', q.id, null, { version, total_cents: totals.totalCents });
    });
    notifyClients(c.db, e.org_id, e.id, { type: 'quote_sent', title: 'Tienes una nueva propuesta disponible', body: 'Revisa y responde tu presupuesto', link: '#/quote', dedupe: `quote:${vid}` });
    return c.db.get('SELECT * FROM quote_versions WHERE id = ?', vid);
  });

  r.post('/api/events/:id/quote/respond', (c) => {
    if (c.user!.role !== 'client') throw forbidden('Solo el cliente responde la propuesta');
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { version: v.int({ min: 1 }), accept: v.bool(), reason: v.str({ max: 500, optional: true }) });
    const q = c.db.get('SELECT * FROM quotes WHERE event_id = ?', e.id); if (!q) throw notFound('Cotización');
    const ver = c.db.get('SELECT * FROM quote_versions WHERE quote_id = ? AND version = ?', q.id, b.version);
    if (!ver) throw notFound('Versión');
    if (ver.status !== 'sent' || ver.version !== q.current_version) throw conflict('Esta versión ya no está vigente. Revisa la propuesta más reciente.');
    c.db.tx(() => {
      if (b.accept) {
        c.db.run(`UPDATE quote_versions SET status = 'accepted', accepted_at = ?, accepted_by = ? WHERE id = ?`, new Date().toISOString(), c.user!.id, ver.id);
        c.db.run(`UPDATE service_requests SET status = 'client_approved', updated_at = ? WHERE status = 'quote_sent' AND id IN (SELECT request_id FROM quote_items WHERE version_id = ?)`, new Date().toISOString(), ver.id);
        c.db.run('UPDATE events SET budget_approved_cents = ?, status = CASE WHEN status IN (\'proposal_sent\',\'pending_approval\') THEN \'pending_approval\' ELSE status END, updated_at = ? WHERE id = ?', ver.total_cents, new Date().toISOString(), e.id);
      } else {
        c.db.run(`UPDATE quote_versions SET status = 'rejected', rejected_reason = ? WHERE id = ?`, b.reason ?? null, ver.id);
        c.db.run(`UPDATE service_requests SET status = 'quote_preparing', updated_at = ? WHERE status = 'quote_sent' AND event_id = ?`, new Date().toISOString(), e.id);
      }
      audit(c, b.accept ? 'quote.accept' : 'quote.reject', 'quote', q.id, { version: ver.version, status: ver.status }, { total_cents: ver.total_cents }, b.reason);
    });
    notifyPlanners(c.db, e.org_id, e.id, { type: 'quote_response', title: b.accept ? 'El cliente aceptó la propuesta' : 'El cliente rechazó la propuesta', body: e.folio, link: `#/events/${e.id}`, priority: 'high' });
    return { ok: true, accepted: !!b.accept };
  });

  // ───── Proveedores ─────
  const VSPEC = { business_name: v.str({ max: 160 }), legal_name: v.str({ max: 200, optional: true }), contact_name: v.str({ max: 120, optional: true }), phone: v.str({ max: 40, optional: true }), email: v.email({ optional: true }), address: v.str({ max: 300, optional: true }), city: v.str({ max: 100, optional: true }),
    categories: v.strArr({ optional: true }), description: v.str({ max: 2000, optional: true }), capacity_note: v.str({ max: 500, optional: true }), coverage: v.str({ max: 300, optional: true }), setup_minutes: v.int({ min: 0, max: 1440, optional: true }), teardown_minutes: v.int({ min: 0, max: 1440, optional: true }),
    tech_requirements: v.str({ max: 1000, optional: true }), payment_terms: v.str({ max: 500, optional: true }), cancellation_policy: v.str({ max: 500, optional: true }), status: v.oneOf(['prospect', 'evaluating', 'docs_pending', 'approved', 'active', 'suspended', 'inactive', 'temporarily_unavailable'], { optional: true }), internal_notes: v.str({ max: 2000, optional: true, nullable: true }) };
  const vendorView = (u: Ctx['user'], x: Row) => { const o: Row = { ...x, categories: JSON.parse(x.categories) }; if (!hasPerm(u!, 'finance.view')) delete o.tax_data; return o; };
  r.get('/api/vendors', (c) => { need(c.user!, 'vendors.manage'); return { vendors: c.db.all('SELECT * FROM vendors WHERE org_id = ? ORDER BY business_name', c.user!.org_id).map((x) => vendorView(c.user, x)) }; });
  r.post('/api/vendors', (c) => { need(c.user!, 'vendors.manage');
    const b = parse(c.body, VSPEC); const id = uid();
    c.db.run(`INSERT INTO vendors (id, org_id, business_name, legal_name, contact_name, phone, email, address, city, categories, description, capacity_note, coverage, setup_minutes, teardown_minutes, tech_requirements, payment_terms, cancellation_policy, status, internal_notes)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, id, c.user!.org_id, b.business_name, b.legal_name, b.contact_name, b.phone, b.email, b.address, b.city, b.categories ?? '[]', b.description, b.capacity_note, b.coverage, b.setup_minutes ?? 0, b.teardown_minutes ?? 0, b.tech_requirements, b.payment_terms, b.cancellation_policy, b.status ?? 'prospect', b.internal_notes);
    audit(c, 'vendor.create', 'vendor', id, null, { business_name: b.business_name });
    return vendorView(c.user, c.db.get('SELECT * FROM vendors WHERE id = ?', id)!);
  });
  r.patch('/api/vendors/:id', (c) => { need(c.user!, 'vendors.manage');
    const x = c.db.get('SELECT * FROM vendors WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!x) throw notFound('Proveedor');
    const spec: any = { ...VSPEC, business_name: v.str({ max: 160, optional: true }) }; if (hasPerm(c.user!, 'finance.view')) spec.tax_data = v.str({ max: 1000, optional: true, nullable: true });
    const b = parse(c.body, spec); const keys = Object.keys(b); if (!keys.length) return vendorView(c.user, x);
    c.db.run(`UPDATE vendors SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = ? WHERE id = ?`, ...keys.map((k) => b[k]), new Date().toISOString(), x.id);
    audit(c, 'vendor.update', 'vendor', x.id, Object.fromEntries(keys.filter((k) => k !== 'tax_data').map((k) => [k, x[k]])), Object.fromEntries(keys.filter((k) => k !== 'tax_data').map((k) => [k, b[k]])));
    return vendorView(c.user, c.db.get('SELECT * FROM vendors WHERE id = ?', x.id)!);
  });
  r.get('/api/vendors/:id/availability-check', (c) => { need(c.user!, 'vendors.manage');
    const x = c.db.get('SELECT * FROM vendors WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!x) throw notFound('Proveedor');
    const b = parse({ date: c.query.get('date'), start: c.query.get('start') ?? '00:00', end: c.query.get('end') ?? '23:59' }, { date: v.date(), start: v.time(), end: v.time() });
    return checkAvailability(availInput(c, x, b.date, b.start, b.end));
  });
  r.put('/api/vendors/:id/availability', (c) => { need(c.user!, 'vendors.manage'); return setAvailability(c, c.params.id); });
  r.put('/api/vendor/availability', (c) => { if (c.user!.role !== 'vendor' || !c.user!.vendor_id) throw forbidden(); return setAvailability(c, c.user!.vendor_id); });
  r.post('/api/vendors/:id/blackouts', (c) => { need(c.user!, 'vendors.manage'); return addBlackout(c, c.params.id); });
  r.post('/api/vendor/blackouts', (c) => { if (c.user!.role !== 'vendor' || !c.user!.vendor_id) throw forbidden(); return addBlackout(c, c.user!.vendor_id); });
  r.post('/api/vendors/:id/evaluations', (c) => { need(c.user!, 'vendors.manage');
    const x = c.db.get('SELECT id FROM vendors WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!x) throw notFound('Proveedor');
    const r5 = { optional: true, min: 1, max: 5 };
    const b = parse(c.body, { event_id: v.id({ optional: true }), punctuality: v.int(r5), quality: v.int(r5), compliance: v.int(r5), professionalism: v.int(r5), notes: v.str({ max: 1000, optional: true }) });
    c.db.run('INSERT INTO vendor_evaluations (id, org_id, vendor_id, event_id, punctuality, quality, compliance, professionalism, notes, created_by) VALUES (?,?,?,?,?,?,?,?,?,?)', uid(), c.user!.org_id, x.id, b.event_id, b.punctuality, b.quality, b.compliance, b.professionalism, b.notes, c.user!.id);
    return { ok: true };
  });

  // ───── Asignaciones (lado planner) ─────
  r.get('/api/events/:id/assignments', (c) => { needStaff(c.user!); need(c.user!, 'logistics.manage');
    const e = getEvent(c, c.params.id);
    return { assignments: c.db.all('SELECT a.*, v.business_name, v.user_id AS vendor_user_id FROM service_assignments a JOIN vendors v ON v.id = a.vendor_id WHERE a.event_id = ? ORDER BY a.service_date', e.id).map((a) => (hasPerm(c.user!, 'finance.view') ? a : { ...a, cost_cents: undefined, actual_cost_cents: undefined })) };
  });
  r.post('/api/requests/:id/assign', (c) => { need(c.user!, 'logistics.manage');
    const { req, event } = getRequest(c, c.params.id);
    if (!['client_approved', 'pending_vendor', 'in_review', 'quote_preparing'].includes(req.status) && req.status !== 'confirmed') throw conflict('La solicitud no está lista para asignar proveedor');
    if (!event.event_date) throw conflict('Define la fecha del evento antes de asignar proveedores');
    const b = parse(c.body, { vendor_id: v.id(), cost_cents: v.int({ min: 0, optional: true }), start_time: v.time(), end_time: v.time(), arrival_time: v.time({ optional: true }), setup_time: v.time({ optional: true }), teardown_time: v.time({ optional: true }), location_visible: v.bool({ optional: true }), location_detail: v.str({ max: 400, optional: true }), instructions: v.str({ max: 3000, optional: true }), requirements: v.str({ max: 1500, optional: true }), staff_needed: v.int({ min: 0, max: 500, optional: true }), checklist: v.json({ optional: true }), force: v.bool({ optional: true }) });
    const vendor = c.db.get('SELECT * FROM vendors WHERE id = ? AND org_id = ?', b.vendor_id, c.user!.org_id);
    if (!vendor) throw notFound('Proveedor');
    if (['suspended', 'inactive'].includes(vendor.status)) throw conflict('El proveedor está suspendido o inactivo');
    if (c.db.get(`SELECT 1 x FROM service_assignments WHERE request_id = ? AND status IN ('requested','accepted','confirmed')`, req.id)) throw conflict('Esta solicitud ya tiene una asignación activa');
    const av = checkAvailability(availInput(c, vendor, event.event_date, b.start_time, b.end_time));
    if (av.state === 'unavailable' && !b.force) throw conflict('El proveedor no está disponible', { reasons: av.reasons });
    const svc = c.db.get('SELECT name FROM service_catalog WHERE id = ?', req.service_id)!;
    const id = uid();
    c.db.tx(() => {
      c.db.run(`INSERT INTO service_assignments (id, org_id, event_id, request_id, vendor_id, public_title, service_description, qty_milli, cost_cents, service_date, arrival_time, setup_time, start_time, end_time, teardown_time, location_visible, location_detail, instructions, requirements, staff_needed, created_by)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, id, c.user!.org_id, event.id, req.id, vendor.id, `${event.type} · ${event.folio}`, svc.name, req.qty_milli, b.cost_cents ?? 0, event.event_date, b.arrival_time, b.setup_time, b.start_time, b.end_time, b.teardown_time, b.location_visible ?? 0, b.location_detail, b.instructions, b.requirements, b.staff_needed, c.user!.id);
      for (const it of b.checklist ? JSON.parse(b.checklist) : []) if (['prep', 'exec', 'teardown'].includes(it.phase) && typeof it.text === 'string') c.db.run('INSERT INTO assignment_checklist (id, assignment_id, phase, text) VALUES (?,?,?,?)', uid(), id, it.phase, String(it.text).slice(0, 200));
      c.db.run(`UPDATE service_requests SET status = 'pending_vendor', updated_at = ? WHERE id = ? AND status IN ('client_approved','pending_vendor','in_review','quote_preparing')`, new Date().toISOString(), req.id);
      audit(c, 'assignment.create', 'assignment', id, null, { vendor_id: vendor.id, request_id: req.id, availability: av.state, forced: !!b.force });
    });
    // La notificación al proveedor NO incluye nombre del cliente ni del evento
    if (vendor.user_id) notify(c.db, { orgId: c.user!.org_id, userId: vendor.user_id, type: 'assignment_request', title: 'Nueva solicitud de asignación', body: `${event.type} · ${event.folio} · ${event.event_date}`, link: `#/assignments/${id}`, priority: 'high' });
    return { id, availability: av };
  });
  r.post('/api/assignments/:id/status', (c) => { need(c.user!, 'logistics.manage');
    const a = c.db.get('SELECT * FROM service_assignments WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!a) throw notFound('Asignación');
    getEvent(c, a.event_id);
    const b = parse(c.body, { to: v.oneOf(['confirmed', 'cancelled', 'completed']), reason: v.str({ max: 300, optional: true }) });
    if (!canTransition(ASSIGNMENT_TRANSITIONS, a.status, b.to)) throw conflict(`Transición no permitida: ${a.status} → ${b.to}`);
    c.db.tx(() => {
      c.db.run('UPDATE service_assignments SET status = ?, updated_at = ? WHERE id = ?', b.to, new Date().toISOString(), a.id);
      if (b.to === 'confirmed' && a.request_id) c.db.run(`UPDATE service_requests SET status = 'confirmed', updated_at = ? WHERE id = ? AND status IN ('pending_vendor','client_approved')`, new Date().toISOString(), a.request_id);
      if (b.to === 'cancelled' && a.request_id) c.db.run(`UPDATE service_requests SET status = 'in_review', updated_at = ? WHERE id = ? AND status IN ('pending_vendor','confirmed')`, new Date().toISOString(), a.request_id);
      if (b.to === 'completed' && a.request_id) c.db.run(`UPDATE service_requests SET status = 'completed', updated_at = ? WHERE id = ?`, new Date().toISOString(), a.request_id);
      audit(c, `assignment.${b.to}`, 'assignment', a.id, { status: a.status }, { status: b.to }, b.reason);
    });
    const vu = c.db.get('SELECT user_id FROM vendors WHERE id = ?', a.vendor_id)?.user_id;
    if (vu && b.to !== 'completed') notify(c.db, { orgId: a.org_id, userId: vu, type: b.to === 'confirmed' ? 'assignment_confirmed' : 'assignment_cancelled', title: b.to === 'confirmed' ? 'Tu asignación fue confirmada' : 'Una asignación fue cancelada', body: a.public_title, link: `#/assignments/${a.id}` });
    return { ok: true };
  });
  r.patch('/api/assignments/:id', (c) => { need(c.user!, 'logistics.manage');
    const a = c.db.get('SELECT * FROM service_assignments WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!a) throw notFound('Asignación');
    getEvent(c, a.event_id);
    const b = parse(c.body, { cost_cents: v.int({ min: 0, optional: true }), actual_cost_cents: v.int({ min: 0, optional: true, nullable: true }), instructions: v.str({ max: 3000, optional: true }), arrival_time: v.time({ optional: true }), setup_time: v.time({ optional: true }), start_time: v.time({ optional: true }), end_time: v.time({ optional: true }), teardown_time: v.time({ optional: true }), reason: v.str({ max: 300, optional: true }) });
    const { reason, ...f } = b; const keys = Object.keys(f); if (!keys.length) return a;
    if ((f.cost_cents !== undefined || f.actual_cost_cents !== undefined)) need(c.user!, 'finance.manage');
    if (a.status === 'confirmed' && keys.some((k) => k.endsWith('_time')) && !reason) throw invalid('Cambiar horarios de un servicio confirmado requiere indicar el motivo', { reason: 'Obligatorio' });
    c.db.run(`UPDATE service_assignments SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = ? WHERE id = ?`, ...keys.map((k) => f[k]), new Date().toISOString(), a.id);
    audit(c, 'assignment.update', 'assignment', a.id, Object.fromEntries(keys.map((k) => [k, a[k]])), f, reason);
    return { ok: true };
  });
  void lineAmount;
}

function availInput(c: Ctx, vendor: Row, date: string, start: string, end: string, ignore?: string) {
  return {
    window: { date, start, end }, setupMin: vendor.setup_minutes, teardownMin: vendor.teardown_minutes, ignoreAssignmentId: ignore,
    blackouts: c.db.all('SELECT start_date, end_date FROM vendor_blackouts WHERE vendor_id = ?', vendor.id).map((b) => ({ start: b.start_date, end: b.end_date })),
    dayRows: c.db.all('SELECT date, status, capacity FROM vendor_availability WHERE vendor_id = ? AND date = ?', vendor.id, date) as any,
    assignments: c.db.all('SELECT id, status, service_date, start_time, end_time FROM service_assignments WHERE vendor_id = ? AND service_date = ?', vendor.id, date).map((a) => ({ id: a.id, status: a.status, date: a.service_date, start: a.start_time, end: a.end_time })),
  };
}
function setAvailability(c: Ctx, vendorId: string) {
  const x = c.db.get('SELECT id FROM vendors WHERE id = ? AND org_id = ?', vendorId, c.user!.org_id); if (!x) throw notFound('Proveedor');
  const b = parse(c.body, { date: v.date(), status: v.oneOf(['available', 'unavailable']), capacity: v.int({ min: 1, max: 50, optional: true }), note: v.str({ max: 200, optional: true }) });
  c.db.run('INSERT INTO vendor_availability (id, vendor_id, date, status, capacity, note) VALUES (?,?,?,?,?,?) ON CONFLICT(vendor_id, date) DO UPDATE SET status = excluded.status, capacity = excluded.capacity, note = excluded.note', uid(), x.id, b.date, b.status, b.capacity ?? 1, b.note);
  audit(c, 'vendor.availability', 'vendor', x.id, null, b);
  return { ok: true };
}
function addBlackout(c: Ctx, vendorId: string) {
  const x = c.db.get('SELECT id FROM vendors WHERE id = ? AND org_id = ?', vendorId, c.user!.org_id); if (!x) throw notFound('Proveedor');
  const b = parse(c.body, { start_date: v.date(), end_date: v.date(), reason: v.str({ max: 200, optional: true }) });
  if (b.end_date < b.start_date) throw invalid('La fecha final debe ser posterior a la inicial');
  c.db.run('INSERT INTO vendor_blackouts (id, vendor_id, start_date, end_date, reason) VALUES (?,?,?,?,?)', uid(), x.id, b.start_date, b.end_date, b.reason);
  return { ok: true };
}
export { availInput };
