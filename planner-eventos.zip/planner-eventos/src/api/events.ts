import type { Router, Ctx } from '../http.ts';
import { conflict, forbidden, invalid, notFound } from '../lib/errors.ts';
import { uid } from '../lib/db.ts';
import type { Db, Row } from '../lib/db.ts';
import { parse, v } from '../lib/validate.ts';
import { addDays, todayIn } from '../lib/time.ts';
import { EVENT_TRANSITIONS, canTransition } from '../domain/states.ts';
import { computeEventFinancials } from '../domain/finance.ts';
import { audit, clientEventView, getEvent, hasPerm, isStaff, need, needStaff, nextFolio, notifyPlanners } from '../services.ts';

export function accessibleEventIds(c: Ctx): string[] | 'all' {
  const u = c.user!;
  if (u.role === 'owner' || (u.role === 'staff' && u.permissions.includes('events.read_all'))) return 'all';
  if (u.role === 'staff') return c.db.all('SELECT event_id FROM event_staff WHERE user_id = ?', u.id).map((r) => r.event_id);
  if (u.role === 'client' && u.client_id) return c.db.all('SELECT event_id FROM client_event_memberships WHERE client_id = ?', u.client_id).map((r) => r.event_id);
  return [];
}

export function loadFinancials(db: Db, eventId: string) {
  const q = db.get(`SELECT qv.total_cents, qv.tax_cents FROM quotes q JOIN quote_versions qv ON qv.quote_id = q.id WHERE q.event_id = ? AND qv.status = 'accepted' ORDER BY qv.version DESC LIMIT 1`, eventId);
  return computeEventFinancials({
    contractedTotalCents: q?.total_cents ?? 0, contractedTaxCents: q?.tax_cents ?? 0,
    payments: db.all('SELECT direction, status, amount_cents, paid_cents, verified FROM payments WHERE event_id = ?', eventId).map((p) => ({ direction: p.direction, status: p.status, amountCents: p.amount_cents, paidCents: p.paid_cents, verified: !!p.verified })),
    assignments: db.all('SELECT status, cost_cents, actual_cost_cents FROM service_assignments WHERE event_id = ?', eventId).map((a) => ({ status: a.status, costCents: a.cost_cents, actualCostCents: a.actual_cost_cents })),
    expensesCents: db.get('SELECT COALESCE(SUM(amount_cents),0) s FROM expenses WHERE event_id = ?', eventId)!.s,
    adjustments: db.all('SELECT kind, amount_cents FROM financial_adjustments WHERE event_id = ?', eventId).map((a) => ({ kind: a.kind, amountCents: a.amount_cents })),
  });
}

/** Progreso real: tareas visibles para el cliente completadas / total (sin canceladas). null si no hay tareas. */
export function eventProgress(db: Db, eventId: string) {
  const t = db.get(`SELECT COUNT(*) total, SUM(status = 'completed') done FROM tasks WHERE event_id = ? AND audience = 'client' AND status <> 'cancelled'`, eventId)!;
  return { tasks_total: t.total, tasks_done: t.done ?? 0, percent: t.total ? Math.round(((t.done ?? 0) / t.total) * 100) : null };
}

const EVENT_FIELDS = { name: v.str({ max: 160, optional: true }), type: v.str({ max: 60, optional: true }), event_date: v.date({ optional: true }), start_time: v.time({ optional: true }), end_time: v.time({ optional: true }),
  timezone: v.str({ max: 60, optional: true }), venue_name: v.str({ max: 160, optional: true, nullable: true }), address: v.str({ max: 300, optional: true, nullable: true }), city: v.str({ max: 100, optional: true, nullable: true }),
  guests_estimated: v.int({ min: 0, max: 100000, optional: true, nullable: true }), budget_target_cents: v.int({ min: 0, optional: true, nullable: true }),
  notes_internal: v.str({ max: 4000, optional: true, nullable: true }), notes_client: v.str({ max: 4000, optional: true, nullable: true }) };

export function register(r: Router) {
  r.get('/api/events', (c) => {
    const ids = accessibleEventIds(c);
    const where: string[] = ['e.org_id = ?']; const p: any[] = [c.user!.org_id];
    if (ids !== 'all') { if (!ids.length) return { events: [], total: 0 }; where.push(`e.id IN (${ids.map(() => '?').join(',')})`); p.push(...ids); }
    for (const [k, col] of [['status', 'e.status'], ['type', 'e.type']] as const) if (c.query.get(k)) { where.push(`${col} = ?`); p.push(c.query.get(k)); }
    if (c.query.get('from')) { where.push('e.event_date >= ?'); p.push(c.query.get('from')); }
    if (c.query.get('to')) { where.push('e.event_date <= ?'); p.push(c.query.get('to')); }
    if (c.query.get('q')) { where.push('(e.name LIKE ? OR e.folio LIKE ?)'); p.push(`%${c.query.get('q')}%`, `%${c.query.get('q')}%`); }
    const page = Math.max(1, Number(c.query.get('page') ?? 1) || 1), size = Math.min(100, Number(c.query.get('size') ?? 25) || 25);
    const total = c.db.get(`SELECT COUNT(*) n FROM events e WHERE ${where.join(' AND ')}`, ...p)!.n;
    let rows = c.db.all(`SELECT e.* FROM events e WHERE ${where.join(' AND ')} ORDER BY COALESCE(e.event_date, '9999') ASC, e.created_at DESC LIMIT ? OFFSET ?`, ...p, size, (page - 1) * size);
    if (!isStaff(c.user!)) rows = rows.map(clientEventView);
    return { events: rows, total, page, size };
  });

  r.post('/api/events', (c) => {
    need(c.user!, 'events.write');
    const b = parse(c.body, { ...EVENT_FIELDS, name: v.str({ max: 160 }), type: v.str({ max: 60 }), client_id: v.id({ optional: true }), template_id: v.id({ optional: true }) });
    if (b.client_id && !c.db.get('SELECT 1 x FROM clients WHERE id = ? AND org_id = ?', b.client_id, c.user!.org_id)) throw invalid('Cliente no válido', { client_id: 'No existe' });
    const id = uid();
    c.db.tx(() => {
      const year = Number((b.event_date ?? new Date().toISOString()).slice(0, 4));
      const folio = nextFolio(c.db, c.user!.org_id, year);
      c.db.run(`INSERT INTO events (id, org_id, folio, name, type, event_date, start_time, end_time, timezone, venue_name, address, city, guests_estimated, budget_target_cents, notes_internal, notes_client, planner_id)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, id, c.user!.org_id, folio, b.name, b.type, b.event_date, b.start_time, b.end_time, b.timezone ?? 'America/Mexico_City', b.venue_name, b.address, b.city, b.guests_estimated, b.budget_target_cents, b.notes_internal, b.notes_client, c.user!.id);
      if (b.client_id) c.db.run('INSERT INTO client_event_memberships (event_id, client_id, kind) VALUES (?,?,?)', id, b.client_id, 'primary');
      if (c.user!.role === 'staff') c.db.run('INSERT OR IGNORE INTO event_staff (event_id, user_id, role) VALUES (?,?,?)', id, c.user!.id, 'coordinator');
      if (b.template_id) {
        const t = c.db.get('SELECT items FROM task_templates WHERE id = ? AND org_id = ?', b.template_id, c.user!.org_id);
        if (!t) throw invalid('Plantilla no válida', { template_id: 'No existe' });
        if (!b.event_date) throw invalid('Para usar una plantilla indica la fecha del evento', { event_date: 'Obligatoria con plantilla' });
        for (const it of JSON.parse(t.items)) c.db.run('INSERT INTO tasks (id, org_id, event_id, title, audience, priority, due_date, created_by) VALUES (?,?,?,?,?,?,?,?)', uid(), c.user!.org_id, id, it.title, it.audience ?? 'internal', it.priority ?? 'normal', addDays(b.event_date, it.offset_days ?? 0), c.user!.id);
      }
      audit(c, 'event.create', 'event', id, null, { folio, name: b.name, type: b.type });
    });
    return c.db.get('SELECT * FROM events WHERE id = ?', id);
  });

  // El cliente puede iniciar su propio proyecto (queda en «prospecto» hasta que la planner lo revise)
  r.post('/api/my/events', (c) => {
    if (c.user!.role !== 'client' || !c.user!.client_id) throw forbidden();
    const active = c.db.get(`SELECT COUNT(*) n FROM client_event_memberships m JOIN events e ON e.id = m.event_id WHERE m.client_id = ? AND e.status NOT IN ('cancelled','archived','closed')`, c.user!.client_id)!.n;
    if (active >= 3) throw conflict('Alcanzaste el máximo de eventos activos. Contacta a tu planner.');
    const b = parse(c.body, { name: v.str({ max: 160 }), type: v.str({ max: 60 }), event_date: v.date({ optional: true }), city: v.str({ max: 100, optional: true }), guests_estimated: v.int({ min: 0, max: 100000, optional: true }) });
    const id = uid();
    c.db.tx(() => {
      const folio = nextFolio(c.db, c.user!.org_id, Number((b.event_date ?? new Date().toISOString()).slice(0, 4)));
      c.db.run('INSERT INTO events (id, org_id, folio, name, type, event_date, city, guests_estimated) VALUES (?,?,?,?,?,?,?,?)', id, c.user!.org_id, folio, b.name, b.type, b.event_date, b.city, b.guests_estimated);
      c.db.run('INSERT INTO client_event_memberships (event_id, client_id, kind) VALUES (?,?,?)', id, c.user!.client_id, 'primary');
      audit(c, 'event.create_by_client', 'event', id, null, { folio });
      notifyPlanners(c.db, c.user!.org_id, null, { type: 'event_new', title: 'Nuevo evento iniciado por un cliente', body: `${folio} · ${b.name}`, link: `#/events/${id}` });
    });
    return clientEventView(c.db.get('SELECT * FROM events WHERE id = ?', id)!);
  });

  r.get('/api/events/:id', (c) => {
    const e = getEvent(c, c.params.id);
    if (isStaff(c.user!)) {
      return { event: e, clients: c.db.all('SELECT cl.id, cl.name, cl.email, cl.user_id, m.kind FROM client_event_memberships m JOIN clients cl ON cl.id = m.client_id WHERE m.event_id = ?', e.id),
        staff: c.db.all('SELECT u.id, u.display_name FROM event_staff s JOIN users u ON u.id = s.user_id WHERE s.event_id = ?', e.id), progress: eventProgress(c.db, e.id), allowed_next: EVENT_TRANSITIONS[e.status] };
    }
    return { event: clientEventView(e), progress: eventProgress(c.db, e.id) };
  });

  r.patch('/api/events/:id', (c) => {
    need(c.user!, 'events.write');
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { ...EVENT_FIELDS, reason: v.str({ max: 300, optional: true }), guests_confirmed: v.int({ min: 0, optional: true }) });
    const { reason, ...fields } = b;
    const dateChanged = fields.event_date && fields.event_date !== e.event_date;
    if (dateChanged && ['confirmed', 'in_execution'].includes(e.status) && !reason) throw invalid('Cambiar la fecha de un evento confirmado requiere indicar el motivo', { reason: 'Obligatorio' });
    const keys = Object.keys(fields); if (!keys.length) return e;
    c.db.tx(() => {
      c.db.run(`UPDATE events SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = ? WHERE id = ?`, ...keys.map((k) => fields[k]), new Date().toISOString(), e.id);
      const before: Row = {}; for (const k of keys) before[k] = e[k];
      audit(c, dateChanged ? 'event.date_change' : 'event.update', 'event', e.id, before, fields, reason);
    });
    return c.db.get('SELECT * FROM events WHERE id = ?', e.id);
  });

  r.post('/api/events/:id/status', (c) => {
    need(c.user!, 'events.write');
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { to: v.oneOf(Object.keys(EVENT_TRANSITIONS)), reason: v.str({ max: 300, optional: true }), override: v.bool({ optional: true }) });
    if (!canTransition(EVENT_TRANSITIONS, e.status, b.to)) throw conflict(`No se puede pasar de «${e.status}» a «${b.to}»`, { allowed: EVENT_TRANSITIONS[e.status] });
    if (b.to === 'cancelled' && !b.reason) throw invalid('Indica el motivo de la cancelación', { reason: 'Obligatorio' });
    const blockers: string[] = [];
    if (b.to === 'contracted' && !c.db.get(`SELECT 1 x FROM quotes q JOIN quote_versions qv ON qv.quote_id = q.id WHERE q.event_id = ? AND qv.status = 'accepted'`, e.id)) blockers.push('No existe una cotización aceptada por el cliente');
    if (b.to === 'confirmed' && c.db.get(`SELECT 1 x FROM service_requests WHERE event_id = ? AND status IN ('client_approved','pending_vendor')`, e.id)) blockers.push('Hay servicios aprobados sin confirmar con proveedor');
    if (b.to === 'closed') {
      const f = loadFinancials(c.db, e.id);
      if (f.clientBalance > 0) blockers.push('El cliente tiene saldo pendiente');
      if (f.vendorOwed > 0) blockers.push('Hay pagos pendientes a proveedores');
      if (c.db.get(`SELECT 1 x FROM incidents WHERE event_id = ? AND status <> 'resolved'`, e.id)) blockers.push('Hay incidencias abiertas');
    }
    if (blockers.length) {
      if (!(b.override && c.user!.role === 'owner' && b.reason)) throw conflict('No se puede completar el cambio de estado', { blockers, hint: 'La propietaria puede forzarlo indicando un motivo' });
    }
    c.db.tx(() => {
      c.db.run('UPDATE events SET status = ?, cancel_reason = COALESCE(?, cancel_reason), closed_at = CASE WHEN ? = \'closed\' THEN ? ELSE closed_at END, updated_at = ? WHERE id = ?', b.to, b.to === 'cancelled' ? b.reason : null, b.to, new Date().toISOString(), new Date().toISOString(), e.id);
      audit(c, 'event.status', 'event', e.id, { status: e.status }, { status: b.to, blockers_overridden: blockers.length ? blockers : undefined }, b.reason);
    });
    return { ok: true, status: b.to };
  });

  r.post('/api/events/:id/clients', (c) => {
    need(c.user!, 'clients.manage');
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { client_id: v.id(), kind: v.oneOf(['primary', 'participant'], { optional: true }) });
    if (!c.db.get('SELECT 1 x FROM clients WHERE id = ? AND org_id = ?', b.client_id, c.user!.org_id)) throw notFound('Cliente');
    c.db.run('INSERT OR REPLACE INTO client_event_memberships (event_id, client_id, kind) VALUES (?,?,?)', e.id, b.client_id, b.kind ?? 'participant');
    audit(c, 'event.membership', 'event', e.id, null, b);
    return { ok: true };
  });

  // Asistente del cliente: guarda progreso parcial; no exige completar todo
  r.put('/api/events/:id/brief', (c) => {
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { data: v.json(), step: v.int({ min: 0, max: 10 }), submit: v.bool({ optional: true }) });
    c.db.run('UPDATE events SET brief = ?, brief_step = ?, brief_submitted_at = CASE WHEN ? = 1 THEN ? ELSE brief_submitted_at END, updated_at = ? WHERE id = ?', b.data, b.step, b.submit ? 1 : 0, new Date().toISOString(), new Date().toISOString(), e.id);
    if (b.submit) notifyPlanners(c.db, c.user!.org_id, e.id, { type: 'brief_submitted', title: 'El cliente envió la información de su evento', body: e.folio, link: `#/events/${e.id}`, dedupe: `brief:${e.id}` });
    return { ok: true };
  });

  // ───── Clientes ─────
  r.get('/api/clients', (c) => { need(c.user!, 'clients.manage');
    const q = c.query.get('q');
    return { clients: q ? c.db.all('SELECT * FROM clients WHERE org_id = ? AND archived_at IS NULL AND (name LIKE ? OR email LIKE ?) ORDER BY name LIMIT 100', c.user!.org_id, `%${q}%`, `%${q}%`) : c.db.all('SELECT * FROM clients WHERE org_id = ? AND archived_at IS NULL ORDER BY name LIMIT 200', c.user!.org_id) };
  });
  r.post('/api/clients', (c) => { need(c.user!, 'clients.manage');
    const b = parse(c.body, { name: v.str({ max: 160 }), email: v.email({ optional: true }), phone: v.str({ max: 40, optional: true }), internal_notes: v.str({ max: 2000, optional: true }) });
    const id = uid();
    c.db.run('INSERT INTO clients (id, org_id, name, email, phone, internal_notes) VALUES (?,?,?,?,?,?)', id, c.user!.org_id, b.name, b.email, b.phone, b.internal_notes);
    audit(c, 'client.create', 'client', id, null, { name: b.name });
    return c.db.get('SELECT * FROM clients WHERE id = ?', id);
  });
  r.get('/api/clients/:id', (c) => { need(c.user!, 'clients.manage');
    const cl = c.db.get('SELECT * FROM clients WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!cl) throw notFound('Cliente');
    return { client: cl, events: c.db.all('SELECT e.id, e.folio, e.name, e.status, e.event_date FROM client_event_memberships m JOIN events e ON e.id = m.event_id WHERE m.client_id = ?', cl.id) };
  });

  // ───── Panel de la planner ─────
  r.get('/api/dashboard', (c) => {
    needStaff(c.user!);
    const ids = accessibleEventIds(c); const org = c.user!.org_id;
    const scope = ids === 'all' ? '' : ids.length ? ` AND event_id IN (${ids.map(() => `'${ids.indexOf(ids[0]) >= 0 ? '' : ''}'`).join('')})` : ' AND 1=0';
    void scope;
    const idList = ids === 'all' ? null : ids;
    const inScope = (col: string) => (idList === null ? '1=1' : idList.length ? `${col} IN (${idList.map(() => '?').join(',')})` : '1=0');
    const sp = idList ?? [];
    const today = todayIn();
    const out: Record<string, unknown> = {
      today,
      upcoming_events: c.db.all(`SELECT id, folio, name, type, status, event_date FROM events WHERE org_id = ? AND ${inScope('id')} AND event_date >= ? AND status NOT IN ('cancelled','archived','closed') ORDER BY event_date LIMIT 8`, org, ...sp, today),
      pending_requests: c.db.all(`SELECT r.id, r.event_id, r.status, s.name AS service, e.folio FROM service_requests r JOIN service_catalog s ON s.id = r.service_id JOIN events e ON e.id = r.event_id WHERE r.org_id = ? AND ${inScope('r.event_id')} AND r.status IN ('requested','in_review','info_required') ORDER BY r.created_at LIMIT 20`, org, ...sp),
      vendors_unconfirmed: c.db.all(`SELECT a.id, a.event_id, a.public_title, a.service_date, v.business_name FROM service_assignments a JOIN vendors v ON v.id = a.vendor_id WHERE a.org_id = ? AND ${inScope('a.event_id')} AND a.status IN ('requested','accepted') ORDER BY a.service_date LIMIT 20`, org, ...sp),
      unassigned_services: c.db.all(`SELECT r.id, r.event_id, s.name AS service, e.folio FROM service_requests r JOIN service_catalog s ON s.id = r.service_id JOIN events e ON e.id = r.event_id WHERE r.org_id = ? AND ${inScope('r.event_id')} AND r.status = 'client_approved' AND NOT EXISTS (SELECT 1 FROM service_assignments a WHERE a.request_id = r.id AND a.status NOT IN ('rejected','cancelled')) LIMIT 20`, org, ...sp),
      overdue_tasks: c.db.all(`SELECT t.id, t.event_id, t.title, t.due_date, e.folio FROM tasks t JOIN events e ON e.id = t.event_id WHERE t.org_id = ? AND ${inScope('t.event_id')} AND t.status IN ('pending','in_progress','blocked') AND t.due_date < ? ORDER BY t.due_date LIMIT 20`, org, ...sp, today),
      open_incidents: c.db.all(`SELECT i.id, i.event_id, i.severity, i.description, e.folio FROM incidents i JOIN events e ON e.id = i.event_id WHERE i.org_id = ? AND ${inScope('i.event_id')} AND i.status <> 'resolved' ORDER BY i.created_at DESC LIMIT 20`, org, ...sp),
      agenda_today: c.db.all(`SELECT t.id, t.event_id, t.start_time, t.end_time, t.title, e.folio FROM timeline_items t JOIN events e ON e.id = t.event_id WHERE t.org_id = ? AND ${inScope('t.event_id')} AND t.item_date = ? AND t.status <> 'cancelled' ORDER BY t.start_time`, org, ...sp, today),
    };
    if (hasPerm(c.user!, 'finance.view')) {
      out.upcoming_payments = c.db.all(`SELECT p.id, p.event_id, p.amount_cents, p.paid_cents, p.due_date, p.status, e.folio FROM payments p JOIN events e ON e.id = p.event_id WHERE p.org_id = ? AND ${inScope('p.event_id')} AND p.direction = 'in' AND p.status IN ('pending','scheduled','overdue','partially_paid') AND p.due_date <= ? ORDER BY p.due_date LIMIT 20`, org, ...sp, addDays(today, 14));
      const active = c.db.all(`SELECT id FROM events WHERE org_id = ? AND ${inScope('id')} AND status NOT IN ('cancelled','archived','prospect')`, org, ...sp);
      let contracted = 0, collected = 0, balance = 0;
      for (const ev of active) { const f = loadFinancials(c.db, ev.id); contracted += f.contracted; collected += f.collectedRegistered; balance += Math.max(0, f.clientBalance); }
      out.finance = { contracted, collected, receivable: balance, note: 'Cobrado = pagos registrados (manuales o verificados); ver detalle por evento.' };
    }
    out.recent_activity = hasPerm(c.user!, 'audit.view') ? c.db.all('SELECT a.action, a.entity, a.created_at, u.display_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE a.org_id = ? ORDER BY a.created_at DESC LIMIT 10', org) : [];
    return out;
  });
}
