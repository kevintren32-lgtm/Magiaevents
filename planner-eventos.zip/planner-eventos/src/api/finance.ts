import type { Router, Ctx } from '../http.ts';
import { Reply } from '../http.ts';
import { HttpError, conflict, forbidden, invalid, notFound } from '../lib/errors.ts';
import { uid } from '../lib/db.ts';
import { parse, v } from '../lib/validate.ts';
import { config } from '../config.ts';
import { hmac, safeEqual, sha256 } from '../lib/crypto.ts';
import { audit, getEvent, hasPerm, isStaff, need, notifyPlanners } from '../services.ts';
import { accessibleEventIds, loadFinancials } from './events.ts';

const PAY_STATES = ['pending', 'scheduled', 'in_review', 'paid', 'partially_paid', 'overdue', 'refunded', 'cancelled'] as const;
const PAY_NEXT: Record<string, string[]> = {
  pending: ['scheduled', 'in_review', 'paid', 'partially_paid', 'overdue', 'cancelled'], scheduled: ['in_review', 'paid', 'partially_paid', 'overdue', 'cancelled'],
  in_review: ['paid', 'partially_paid', 'pending', 'cancelled'], partially_paid: ['paid', 'overdue', 'cancelled'], overdue: ['paid', 'partially_paid', 'cancelled'],
  paid: ['refunded'], refunded: [], cancelled: [],
};

const csvCell = (x: unknown) => { let s = String(x ?? ''); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };

export function register(r: Router) {
  r.get('/api/events/:id/payments', (c) => {
    const e = getEvent(c, c.params.id);
    if (isStaff(c.user!)) { need(c.user!, 'finance.view'); return { payments: c.db.all('SELECT p.*, cl.name AS client_name, v.business_name AS vendor_name FROM payments p LEFT JOIN clients cl ON cl.id = p.client_id LEFT JOIN vendors v ON v.id = p.vendor_id WHERE p.event_id = ? ORDER BY COALESCE(p.due_date, p.created_at)', e.id) }; }
    return { payments: c.db.all(`SELECT id, concept, amount_cents, paid_cents, due_date, paid_date, status FROM payments WHERE event_id = ? AND direction = 'in' AND status <> 'cancelled' ORDER BY COALESCE(due_date, created_at)`, e.id) };
  });

  r.post('/api/events/:id/payments', (c) => { need(c.user!, 'finance.manage');
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { direction: v.oneOf(['in', 'out']), client_id: v.id({ optional: true }), vendor_id: v.id({ optional: true }), amount_cents: v.int({ min: 1 }), concept: v.str({ max: 200, optional: true }), due_date: v.date({ optional: true }), method: v.str({ max: 40, optional: true }), reference: v.str({ max: 100, optional: true }), idempotency_key: v.str({ min: 8, max: 100 }), notes: v.str({ max: 500, optional: true }) });
    const dup = c.db.get('SELECT * FROM payments WHERE org_id = ? AND idempotency_key = ?', c.user!.org_id, b.idempotency_key);
    if (dup) return { ...dup, duplicate: true };           // idempotencia: repetir la operación no duplica el ingreso
    if (b.direction === 'in') { if (!b.client_id || !c.db.get('SELECT 1 x FROM client_event_memberships WHERE event_id = ? AND client_id = ?', e.id, b.client_id)) throw invalid('El cliente debe pertenecer al evento', { client_id: 'No válido' }); }
    else if (!b.vendor_id || !c.db.get('SELECT 1 x FROM service_assignments WHERE event_id = ? AND vendor_id = ?', e.id, b.vendor_id)) throw invalid('El proveedor debe tener una asignación en este evento', { vendor_id: 'No válido' });
    const id = uid();
    c.db.tx(() => {
      c.db.run('INSERT INTO payments (id, org_id, event_id, direction, client_id, vendor_id, concept, amount_cents, currency, due_date, method, reference, idempotency_key, recorded_by, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        id, e.org_id, e.id, b.direction, b.client_id, b.vendor_id, b.concept, b.amount_cents, e.currency, b.due_date, b.method, b.reference, b.idempotency_key, c.user!.id, b.notes);
      audit(c, 'payment.create', 'payment', id, null, { direction: b.direction, amount_cents: b.amount_cents, source: 'manual' });
    });
    return c.db.get('SELECT * FROM payments WHERE id = ?', id);
  });

  r.post('/api/payments/:id/status', (c) => { need(c.user!, 'finance.manage');
    const p = c.db.get('SELECT * FROM payments WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!p) throw notFound('Pago');
    getEvent(c, p.event_id);
    const b = parse(c.body, { to: v.oneOf(PAY_STATES), paid_cents: v.int({ min: 0, optional: true }), paid_date: v.date({ optional: true }), reason: v.str({ max: 300, optional: true }) });
    if (p.source === 'gateway' && p.verified) throw forbidden('Un pago verificado por la pasarela no se edita manualmente; registra un ajuste o reembolso');
    if (!(PAY_NEXT[p.status] ?? []).includes(b.to)) throw conflict(`Transición no permitida: ${p.status} → ${b.to}`);
    let paid = p.paid_cents;
    if (b.to === 'paid') paid = p.amount_cents;
    else if (b.to === 'partially_paid') { if (!b.paid_cents || b.paid_cents >= p.amount_cents) throw invalid('Indica un monto parcial menor al total', { paid_cents: 'Inválido' }); paid = b.paid_cents; }
    else if (['pending', 'cancelled'].includes(b.to) && p.paid_cents > 0 && b.to === 'cancelled') throw conflict('El pago ya tiene dinero registrado; usa un reembolso/ajuste');
    c.db.tx(() => {
      c.db.run('UPDATE payments SET status = ?, paid_cents = ?, paid_date = COALESCE(?, paid_date), updated_at = ? WHERE id = ?', b.to, paid, b.paid_date ?? (['paid', 'partially_paid'].includes(b.to) ? new Date().toISOString().slice(0, 10) : null), new Date().toISOString(), p.id);
      audit(c, 'payment.status', 'payment', p.id, { status: p.status, paid_cents: p.paid_cents }, { status: b.to, paid_cents: paid, verified: false }, b.reason);
    });
    return { ok: true, note: 'Registrado manualmente: no equivale a un pago verificado por pasarela' };
  });

  r.post('/api/events/:id/expenses', (c) => { need(c.user!, 'finance.manage');
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { description: v.str({ max: 200 }), amount_cents: v.int({ min: 1 }), expense_date: v.date(), category: v.str({ max: 60, optional: true }), vendor_id: v.id({ optional: true }) });
    const id = uid();
    c.db.run('INSERT INTO expenses (id, org_id, event_id, vendor_id, category, description, amount_cents, expense_date, recorded_by) VALUES (?,?,?,?,?,?,?,?,?)', id, e.org_id, e.id, b.vendor_id, b.category, b.description, b.amount_cents, b.expense_date, c.user!.id);
    audit(c, 'expense.create', 'expense', id, null, { amount_cents: b.amount_cents });
    return { id };
  });

  // Correcciones = movimientos compensatorios (la tabla es de solo anexado)
  r.post('/api/events/:id/adjustments', (c) => { need(c.user!, 'finance.manage');
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { kind: v.oneOf(['client_credit', 'client_charge', 'refund', 'vendor_adjustment', 'correction']), amount_cents: v.int(), reason: v.str({ min: 5, max: 300 }), related_payment_id: v.id({ optional: true }) });
    if (b.amount_cents === 0) throw invalid('El importe no puede ser cero');
    if (b.kind === 'refund' && b.amount_cents > 0) throw invalid('Un reembolso debe ser negativo');
    if (b.kind === 'client_credit' && b.amount_cents > 0) throw invalid('Un crédito al cliente debe ser negativo');
    if (b.kind === 'client_charge' && b.amount_cents < 0) throw invalid('Un cargo adicional debe ser positivo');
    const id = uid();
    c.db.tx(() => {
      c.db.run('INSERT INTO financial_adjustments (id, org_id, event_id, kind, amount_cents, reason, related_payment_id, created_by) VALUES (?,?,?,?,?,?,?,?)', id, e.org_id, e.id, b.kind, b.amount_cents, b.reason, b.related_payment_id, c.user!.id);
      audit(c, 'finance.adjustment', 'adjustment', id, null, { kind: b.kind, amount_cents: b.amount_cents }, b.reason);
    });
    return { id };
  });

  r.get('/api/events/:id/finance', (c) => { need(c.user!, 'finance.view');
    const e = getEvent(c, c.params.id);
    return { summary: loadFinancials(c.db, e.id), expenses: c.db.all('SELECT * FROM expenses WHERE event_id = ? ORDER BY expense_date', e.id), adjustments: c.db.all('SELECT * FROM financial_adjustments WHERE event_id = ? ORDER BY created_at', e.id),
      assignments: c.db.all('SELECT a.id, a.public_title, a.status, a.cost_cents, a.actual_cost_cents, v.business_name FROM service_assignments a JOIN vendors v ON v.id = a.vendor_id WHERE a.event_id = ?', e.id) };
  });
  // Vista del cliente: solo lo que debe ver (sin costos, márgenes ni comisiones)
  r.get('/api/events/:id/balance', (c) => {
    if (c.user!.role !== 'client') throw forbidden();
    const e = getEvent(c, c.params.id); const f = loadFinancials(c.db, e.id);
    const q = c.db.get(`SELECT qv.version, qv.total_cents, qv.advance_cents FROM quotes q JOIN quote_versions qv ON qv.quote_id = q.id WHERE q.event_id = ? AND qv.status = 'accepted' ORDER BY qv.version DESC LIMIT 1`, e.id);
    return { contracted_cents: f.contracted, paid_cents: f.collectedRegistered, balance_cents: f.clientBalance, accepted_version: q?.version ?? null, advance_cents: q?.advance_cents ?? null, currency: e.currency,
      note: 'Los importes estimados se distinguen de los aprobados: «contratado» solo cuenta propuestas que aceptaste.' };
  });

  // Webhook de pasarela: HMAC autenticado + deduplicación. Sin secreto configurado, está deshabilitado.
  r.open('POST', '/api/webhooks/gateway', (c) => {
    if (!config.gatewayWebhookSecret) throw new HttpError(503, 'not_configured', 'La pasarela de pagos no está configurada');
    const rawBody = (c.raw ?? Buffer.alloc(0)) as Buffer;
    const sig = String(c.req.headers['x-signature'] ?? '');
    const payloadHash = sha256(rawBody);
    if (!sig || !safeEqual(sig, hmac(config.gatewayWebhookSecret, rawBody.toString('utf8')))) {
      c.db.run(`INSERT INTO webhook_events (id, provider, external_id, event_type, signature_valid, payload_sha256, status) VALUES (?,?,?,?,?,?,?)`, uid(), 'gateway', `rejected:${uid()}`, null, 0, payloadHash, 'rejected');
      throw new HttpError(401, 'bad_signature', 'Firma inválida');
    }
    const b = c.body ?? {};
    if (typeof b.id !== 'string' || typeof b.payment_id !== 'string' || !Number.isInteger(b.amount_cents) || b.amount_cents <= 0) throw invalid('Evento de pasarela inválido');
    return c.db.tx(() => {
      if (c.db.get('SELECT 1 x FROM webhook_events WHERE provider = ? AND external_id = ?', 'gateway', b.id)) return { ok: true, duplicate: true };
      c.db.run(`INSERT INTO webhook_events (id, provider, external_id, event_type, signature_valid, payload_sha256, status) VALUES (?,?,?,?,?,?,?)`, uid(), 'gateway', b.id, String(b.type ?? ''), 1, payloadHash, 'processed');
      const p = c.db.get(`SELECT * FROM payments WHERE id = ? AND direction = 'in'`, b.payment_id);
      if (!p || b.type !== 'payment.succeeded') { c.db.run(`UPDATE webhook_events SET status = 'ignored' WHERE provider = 'gateway' AND external_id = ?`, b.id); return { ok: true, ignored: true }; }
      const paid = Math.min(p.amount_cents, p.paid_cents + b.amount_cents);
      c.db.run('UPDATE payments SET paid_cents = ?, status = ?, source = ?, verified = 1, paid_date = ?, updated_at = ? WHERE id = ?', paid, paid >= p.amount_cents ? 'paid' : 'partially_paid', 'gateway', new Date().toISOString().slice(0, 10), new Date().toISOString(), p.id);
      c.db.run('INSERT INTO payment_transactions (id, org_id, payment_id, provider, external_id, amount_cents, status) VALUES (?,?,?,?,?,?,?)', uid(), p.org_id, p.id, 'gateway', b.id, b.amount_cents, 'succeeded');
      audit({ db: c.db, user: null, ip: c.ip }, 'payment.gateway_verified', 'payment', p.id, { paid_cents: p.paid_cents }, { paid_cents: paid }, null, 'ok', p.org_id);
      return { ok: true };
    });
  });

  // ───── Reportes ─────
  r.get('/api/reports/summary', (c) => { need(c.user!, 'reports.view');
    const ids = accessibleEventIds(c); const org = c.user!.org_id;
    const evs = c.db.all('SELECT id, folio, name, type, status, event_date FROM events WHERE org_id = ? ORDER BY event_date', org).filter((e) => ids === 'all' || ids.includes(e.id));
    const byStatus: Record<string, number> = {}, byMonth: Record<string, number> = {};
    for (const e of evs) { byStatus[e.status] = (byStatus[e.status] ?? 0) + 1; if (e.event_date) byMonth[e.event_date.slice(0, 7)] = (byMonth[e.event_date.slice(0, 7)] ?? 0) + 1; }
    const out: Record<string, unknown> = { events_by_status: byStatus, events_by_month: byMonth };
    if (hasPerm(c.user!, 'finance.view')) {
      const rows = evs.filter((e) => !['cancelled', 'archived', 'prospect'].includes(e.status)).map((e) => ({ folio: e.folio, name: e.name, status: e.status, ...loadFinancials(c.db, e.id) }));
      out.finance_by_event = rows;
      out.totals = { contracted: rows.reduce((s, x) => s + x.contracted, 0), collected_registered: rows.reduce((s, x) => s + x.collectedRegistered, 0), collected_verified: rows.reduce((s, x) => s + x.collectedVerified, 0), receivable: rows.reduce((s, x) => s + Math.max(0, x.clientBalance), 0), final_profit: rows.reduce((s, x) => s + x.finalProfit, 0) };
    }
    return out;
  });
  r.get('/api/reports/events.csv', (c) => { need(c.user!, 'reports.view');
    const ids = accessibleEventIds(c); const fin = hasPerm(c.user!, 'finance.view');
    const evs = c.db.all('SELECT * FROM events WHERE org_id = ? ORDER BY event_date', c.user!.org_id).filter((e) => ids === 'all' || ids.includes(e.id));
    const head = ['folio', 'nombre', 'tipo', 'estado', 'fecha', ...(fin ? ['contratado_centavos', 'cobrado_registrado_centavos', 'cobrado_verificado_centavos', 'saldo_cliente_centavos', 'utilidad_final_centavos'] : [])];
    const lines = [head.join(',')];
    for (const e of evs) { const f = fin ? loadFinancials(c.db, e.id) : null; lines.push([e.folio, e.name, e.type, e.status, e.event_date, ...(f ? [f.contracted, f.collectedRegistered, f.collectedVerified, f.clientBalance, f.finalProfit] : [])].map(csvCell).join(',')); }
    return new Reply(200, lines.join('\n'), { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': 'attachment; filename="eventos.csv"' });
  });
  void ({} as Ctx);
}
