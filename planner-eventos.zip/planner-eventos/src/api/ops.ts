import type { Router, Ctx } from '../http.ts';
import { conflict, forbidden, invalid, notFound } from '../lib/errors.ts';
import { uid } from '../lib/db.ts';
import type { Row } from '../lib/db.ts';
import { parse, v } from '../lib/validate.ts';
import { detectConflicts } from '../domain/timeline.ts';
import { audit, getEvent, isStaff, need, notify, notifyClients, notifyPlanners } from '../services.ts';

function timelineItems(c: Ctx, eventId: string) {
  const rows = c.db.all('SELECT * FROM timeline_items WHERE event_id = ? ORDER BY item_date, start_time', eventId);
  const deps = c.db.all('SELECT item_id, depends_on_id FROM timeline_dependencies WHERE item_id IN (SELECT id FROM timeline_items WHERE event_id = ?)', eventId);
  return { rows, alerts: detectConflicts(rows.map((x) => ({ id: x.id, date: x.item_date, start: x.start_time, end: x.end_time, title: x.title, vendorId: x.vendor_id, status: x.status, deps: deps.filter((d) => d.item_id === x.id).map((d) => d.depends_on_id) }))) };
}
const seatsUsed = (c: Ctx, tableId: string) => c.db.get(`SELECT COALESCE(SUM(1 + companions), 0) n FROM guests WHERE table_id = ? AND status NOT IN ('declined','no_show','waitlist')`, tableId)!.n;

export function register(r: Router) {
  // ───── Tareas ─────
  r.get('/api/events/:id/tasks', (c) => {
    const e = getEvent(c, c.params.id);
    const rows = isStaff(c.user!) ? c.db.all('SELECT * FROM tasks WHERE event_id = ? ORDER BY due_date', e.id) : c.db.all(`SELECT id, title, description, due_date, priority, status, completed_at FROM tasks WHERE event_id = ? AND audience = 'client' ORDER BY due_date`, e.id);
    return { tasks: rows };
  });
  r.post('/api/events/:id/tasks', (c) => { need(c.user!, 'events.write');
    const e = getEvent(c, c.params.id);
    const b = parse(c.body, { title: v.str({ max: 200 }), description: v.str({ max: 2000, optional: true }), due_date: v.date({ optional: true }), priority: v.oneOf(['low', 'normal', 'high', 'urgent'], { optional: true }), audience: v.oneOf(['internal', 'client', 'vendor'], { optional: true }), assignee_user_id: v.id({ optional: true }), assignment_id: v.id({ optional: true }), depends_on: v.strArr({ optional: true }) });
    if (b.assignment_id && !c.db.get('SELECT 1 x FROM service_assignments WHERE id = ? AND event_id = ?', b.assignment_id, e.id)) throw invalid('Asignación no válida');
    if (b.audience === 'vendor' && !b.assignment_id) throw invalid('Una tarea para proveedor debe estar ligada a una asignación', { assignment_id: 'Obligatorio' });
    const id = uid();
    c.db.tx(() => {
      c.db.run('INSERT INTO tasks (id, org_id, event_id, assignment_id, title, description, assignee_user_id, audience, due_date, priority, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?)', id, e.org_id, e.id, b.assignment_id, b.title, b.description, b.assignee_user_id, b.audience ?? 'internal', b.due_date, b.priority ?? 'normal', c.user!.id);
      for (const d of b.depends_on ? JSON.parse(b.depends_on) : []) { if (!c.db.get('SELECT 1 x FROM tasks WHERE id = ? AND event_id = ?', d, e.id)) throw invalid('Dependencia no válida'); c.db.run('INSERT INTO task_dependencies (task_id, depends_on_id) VALUES (?,?)', id, d); }
    });
    if ((b.audience ?? 'internal') === 'client') notifyClients(c.db, e.org_id, e.id, { type: 'task_new', title: 'Tienes una tarea pendiente', body: b.title, link: '#/tasks', dedupe: `task:${id}` });
    return { id };
  });
  r.post('/api/tasks/:id/status', (c) => {
    const t = c.db.get('SELECT * FROM tasks WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!t) throw notFound('Tarea');
    getEvent(c, t.event_id);
    const b = parse(c.body, { to: v.oneOf(['pending', 'in_progress', 'blocked', 'completed', 'cancelled']) });
    if (!isStaff(c.user!)) { if (t.audience !== 'client' || !['in_progress', 'completed'].includes(b.to)) throw forbidden(); }
    if (b.to === 'completed' && c.db.get(`SELECT 1 x FROM task_dependencies d JOIN tasks p ON p.id = d.depends_on_id WHERE d.task_id = ? AND p.status <> 'completed'`, t.id)) throw conflict('Hay tareas previas sin completar');
    c.db.run('UPDATE tasks SET status = ?, completed_at = ? WHERE id = ?', b.to, b.to === 'completed' ? new Date().toISOString() : null, t.id);
    audit(c, 'task.status', 'task', t.id, { status: t.status }, { status: b.to });
    return { ok: true };
  });
  r.get('/api/task-templates', (c) => { need(c.user!, 'events.write'); return { templates: c.db.all('SELECT * FROM task_templates WHERE org_id = ? ORDER BY name', c.user!.org_id).map((t) => ({ ...t, items: JSON.parse(t.items) })) }; });
  r.post('/api/task-templates', (c) => { need(c.user!, 'events.write');
    const b = parse(c.body, { name: v.str({ max: 100 }), event_type: v.str({ max: 60 }), items: v.json() });
    const items = JSON.parse(b.items); if (!Array.isArray(items) || items.some((i) => typeof i.title !== 'string' || !Number.isInteger(i.offset_days ?? 0))) throw invalid('Elementos de plantilla inválidos');
    const id = uid(); c.db.run('INSERT INTO task_templates (id, org_id, name, event_type, items) VALUES (?,?,?,?,?)', id, c.user!.org_id, b.name, b.event_type, b.items);
    return { id };
  });

  // ───── Cronograma ─────
  r.get('/api/events/:id/timeline', (c) => {
    const e = getEvent(c, c.params.id);
    const { rows, alerts } = timelineItems(c, e.id);
    if (isStaff(c.user!)) return { items: rows, alerts };
    return { items: rows.filter((x) => x.show_to_client).map((x) => ({ id: x.id, item_date: x.item_date, start_time: x.start_time, end_time: x.end_time, title: x.title, location: x.location, status: x.status })) };
  });
  const TL = { item_date: v.date(), start_time: v.time(), end_time: v.time(), title: v.str({ max: 200 }), location: v.str({ max: 200, optional: true }), instructions: v.str({ max: 2000, optional: true }), priority: v.oneOf(['low', 'normal', 'high', 'urgent'], { optional: true }), vendor_id: v.id({ optional: true }), assignment_id: v.id({ optional: true }), show_to_client: v.bool({ optional: true }), depends_on: v.strArr({ optional: true }) };
  r.post('/api/events/:id/timeline', (c) => { need(c.user!, 'logistics.manage');
    const e = getEvent(c, c.params.id); const b = parse(c.body, TL);
    let locked = 0;
    if (b.assignment_id) { const a = c.db.get('SELECT * FROM service_assignments WHERE id = ? AND event_id = ?', b.assignment_id, e.id); if (!a) throw invalid('Asignación no válida'); b.vendor_id = a.vendor_id; locked = a.status === 'confirmed' ? 1 : 0; }
    if (b.vendor_id && !c.db.get('SELECT 1 x FROM vendors WHERE id = ? AND org_id = ?', b.vendor_id, e.org_id)) throw invalid('Proveedor no válido');
    const id = uid();
    c.db.tx(() => {
      c.db.run('INSERT INTO timeline_items (id, org_id, event_id, assignment_id, vendor_id, item_date, start_time, end_time, title, location, instructions, priority, locked, show_to_client) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)', id, e.org_id, e.id, b.assignment_id, b.vendor_id, b.item_date, b.start_time, b.end_time, b.title, b.location, b.instructions, b.priority ?? 'normal', locked, b.show_to_client ?? 1);
      for (const d of b.depends_on ? JSON.parse(b.depends_on) : []) { if (!c.db.get('SELECT 1 x FROM timeline_items WHERE id = ? AND event_id = ?', d, e.id)) throw invalid('Dependencia no válida'); c.db.run('INSERT INTO timeline_dependencies (item_id, depends_on_id) VALUES (?,?)', id, d); }
      audit(c, 'timeline.create', 'timeline_item', id, null, { title: b.title, date: b.item_date });
    });
    return { id, alerts: timelineItems(c, e.id).alerts.filter((a) => a.itemIds.includes(id)) };   // advierte, la planner decide
  });
  r.patch('/api/timeline/:id', (c) => { need(c.user!, 'logistics.manage');
    const t = c.db.get('SELECT * FROM timeline_items WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!t) throw notFound('Actividad');
    getEvent(c, t.event_id);
    const spec: any = { item_date: v.date({ optional: true }), start_time: v.time({ optional: true }), end_time: v.time({ optional: true }), title: v.str({ max: 200, optional: true }), location: v.str({ max: 200, optional: true }), instructions: v.str({ max: 2000, optional: true }), status: v.oneOf(['pending', 'in_progress', 'done', 'blocked', 'cancelled'], { optional: true }), reason: v.str({ max: 300, optional: true }) };
    const b = parse(c.body, spec); const { reason, ...f } = b; const keys = Object.keys(f); if (!keys.length) return t;
    const touchesSchedule = keys.some((k) => ['item_date', 'start_time', 'end_time', 'title', 'location'].includes(k));
    if (t.locked && touchesSchedule && !reason) throw conflict('Esta actividad está confirmada: indica el motivo del cambio (se notificará a los afectados y quedará registrado)', { locked: true });
    c.db.tx(() => {
      c.db.run(`UPDATE timeline_items SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = ? WHERE id = ?`, ...keys.map((k) => f[k]), new Date().toISOString(), t.id);
      audit(c, t.locked && touchesSchedule ? 'timeline.change_confirmed' : 'timeline.update', 'timeline_item', t.id, Object.fromEntries(keys.map((k) => [k, t[k]])), f, reason);
    });
    if (t.locked && touchesSchedule) {
      const vu = t.vendor_id ? c.db.get('SELECT user_id FROM vendors WHERE id = ?', t.vendor_id)?.user_id : null;
      if (vu) notify(c.db, { orgId: t.org_id, userId: vu, eventId: null, type: 'schedule_change', title: 'Cambio autorizado en tu cronograma', body: 'Revisa tu asignación', link: '#/assignments', priority: 'high' });
      if (t.show_to_client) notifyClients(c.db, t.org_id, t.event_id, { type: 'schedule_change', title: 'Se actualizó el cronograma', link: '#/timeline' });
    }
    return { ok: true, alerts: timelineItems(c, t.event_id).alerts.filter((a) => a.itemIds.includes(t.id)) };
  });

  // ───── Invitados y mesas ─────
  const GUEST = { name: v.str({ max: 160 }), email: v.email({ optional: true }), phone: v.str({ max: 40, optional: true }), group_name: v.str({ max: 80, optional: true }), status: v.oneOf(['pending', 'invited', 'confirmed', 'declined', 'no_response', 'waitlist', 'attended', 'no_show'], { optional: true }), companions: v.int({ min: 0, max: 20, optional: true }), dietary: v.str({ max: 200, optional: true }), accessibility: v.str({ max: 200, optional: true }), notes: v.str({ max: 500, optional: true }) };
  r.get('/api/events/:id/guests', (c) => { const e = getEvent(c, c.params.id);
    return { guests: c.db.all('SELECT g.*, t.name AS table_name FROM guests g LEFT JOIN tables_seating t ON t.id = g.table_id WHERE g.event_id = ? ORDER BY g.name', e.id), tables: c.db.all('SELECT * FROM tables_seating WHERE event_id = ? ORDER BY name', e.id).map((t) => ({ ...t, seats_used: seatsUsed(c, t.id) })) };
  });
  r.post('/api/events/:id/guests', (c) => {
    const e = getEvent(c, c.params.id); if (!isStaff(c.user!) && c.user!.role !== 'client') throw forbidden();
    const b = parse(c.body, GUEST); const id = uid();
    c.db.run('INSERT INTO guests (id, org_id, event_id, name, email, phone, group_name, status, companions, dietary, accessibility, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', id, e.org_id, e.id, b.name, b.email, b.phone, b.group_name, b.status ?? 'pending', b.companions ?? 0, b.dietary, b.accessibility, b.notes);
    return { id };
  });
  r.post('/api/events/:id/guests/import', (c) => {
    const e = getEvent(c, c.params.id); if (!isStaff(c.user!) && c.user!.role !== 'client') throw forbidden();
    const b = parse(c.body, { csv: v.str({ max: 400_000, min: 3 }) });
    const lines = String(b.csv).split(/\r?\n/).filter((l) => l.trim()); if (lines.length > 1001) throw invalid('Máximo 1000 invitados por importación');
    const head = lines[0].split(',').map((h) => h.trim().toLowerCase()); if (!head.includes('name') && !head.includes('nombre')) throw invalid('La primera fila debe incluir la columna «nombre»');
    const idx = (n: string[]) => head.findIndex((h) => n.includes(h));
    const [iN, iE, iP, iG, iC, iD] = [idx(['name', 'nombre']), idx(['email', 'correo']), idx(['phone', 'telefono', 'teléfono']), idx(['group', 'grupo']), idx(['companions', 'acompañantes', 'acompanantes']), idx(['dietary', 'alimentacion', 'alimentación'])];
    const errors: { line: number; message: string }[] = []; let created = 0;
    c.db.tx(() => lines.slice(1).forEach((l, i) => {
      const cells = l.split(',').map((x) => x.trim().replace(/^"|"$/g, '')); const name = cells[iN];
      const email = iE >= 0 ? cells[iE] : ''; const comp = iC >= 0 && cells[iC] ? Number(cells[iC]) : 0;
      if (!name || name.length > 160) return errors.push({ line: i + 2, message: 'Nombre vacío o demasiado largo' });
      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return errors.push({ line: i + 2, message: 'Correo inválido' });
      if (!Number.isInteger(comp) || comp < 0 || comp > 20) return errors.push({ line: i + 2, message: 'Acompañantes inválidos' });
      c.db.run('INSERT INTO guests (id, org_id, event_id, name, email, phone, group_name, companions, dietary) VALUES (?,?,?,?,?,?,?,?,?)', uid(), e.org_id, e.id, name, email || null, iP >= 0 ? cells[iP] || null : null, iG >= 0 ? cells[iG] || null : null, comp, iD >= 0 ? cells[iD] || null : null); created++;
    }));
    return { created, errors };
  });
  r.patch('/api/guests/:id', (c) => {
    const g = c.db.get('SELECT * FROM guests WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!g) throw notFound('Invitado');
    const e = getEvent(c, g.event_id); if (!isStaff(c.user!) && c.user!.role !== 'client') throw forbidden();
    const spec: any = {}; for (const k of Object.keys(GUEST)) spec[k] = (GUEST as any)[k]; spec.name = v.str({ max: 160, optional: true });
    const b = parse(c.body, spec); const keys = Object.keys(b); if (!keys.length) return g;
    c.db.run(`UPDATE guests SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`, ...keys.map((k) => b[k]), g.id);
    c.db.run(`UPDATE events SET guests_confirmed = (SELECT COALESCE(SUM(1 + companions),0) FROM guests WHERE event_id = ? AND status IN ('confirmed','attended')) WHERE id = ?`, e.id, e.id);
    return { ok: true };
  });
  r.post('/api/events/:id/tables', (c) => {
    const e = getEvent(c, c.params.id); if (!isStaff(c.user!) && c.user!.role !== 'client') throw forbidden();
    const b = parse(c.body, { name: v.str({ max: 60 }), capacity: v.int({ min: 1, max: 100 }) }); const id = uid();
    try { c.db.run('INSERT INTO tables_seating (id, event_id, name, capacity) VALUES (?,?,?,?)', id, e.id, b.name, b.capacity); } catch { throw conflict('Ya existe una mesa con ese nombre'); }
    return { id };
  });
  r.post('/api/guests/:id/seat', (c) => {
    const g = c.db.get('SELECT * FROM guests WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!g) throw notFound('Invitado');
    getEvent(c, g.event_id); if (!isStaff(c.user!) && c.user!.role !== 'client') throw forbidden();
    const b = parse(c.body, { table_id: v.id({ nullable: true }) });
    if (b.table_id) {
      const t = c.db.get('SELECT * FROM tables_seating WHERE id = ? AND event_id = ?', b.table_id, g.event_id); if (!t) throw notFound('Mesa');
      const used = seatsUsed(c, t.id) - (g.table_id === t.id ? 1 + g.companions : 0);
      if (used + 1 + g.companions > t.capacity) throw conflict(`Sobrecupo: la mesa «${t.name}» tiene ${used}/${t.capacity} lugares y este invitado necesita ${1 + g.companions}`, { overbooked: true });
    }
    c.db.run('UPDATE guests SET table_id = ? WHERE id = ?', b.table_id ?? null, g.id);
    return { ok: true };
  });

  // ───── Incidencias ─────
  r.get('/api/events/:id/incidents', (c) => { need(c.user!, 'logistics.manage'); const e = getEvent(c, c.params.id);
    return { incidents: c.db.all('SELECT i.*, v.business_name FROM incidents i LEFT JOIN vendors v ON v.id = i.vendor_id WHERE i.event_id = ? ORDER BY i.created_at DESC', e.id) }; });
  r.post('/api/events/:id/incidents', (c) => { need(c.user!, 'logistics.manage'); const e = getEvent(c, c.params.id);
    const b = parse(c.body, { description: v.str({ max: 2000 }), severity: v.oneOf(['low', 'medium', 'high', 'critical'], { optional: true }), assignment_id: v.id({ optional: true }) });
    const id = uid(); c.db.run('INSERT INTO incidents (id, org_id, event_id, assignment_id, reported_by, severity, description) VALUES (?,?,?,?,?,?,?)', id, e.org_id, e.id, b.assignment_id, c.user!.id, b.severity ?? 'medium', b.description);
    audit(c, 'incident.create', 'incident', id, null, { severity: b.severity ?? 'medium' }); return { id }; });
  r.post('/api/incidents/:id/status', (c) => { need(c.user!, 'logistics.manage');
    const i = c.db.get('SELECT * FROM incidents WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!i) throw notFound('Incidencia'); getEvent(c, i.event_id);
    const b = parse(c.body, { to: v.oneOf(['open', 'in_progress', 'resolved']), resolution: v.str({ max: 1000, optional: true }) });
    if (b.to === 'resolved' && !b.resolution) throw invalid('Describe la resolución', { resolution: 'Obligatorio' });
    c.db.run('UPDATE incidents SET status = ?, resolution = COALESCE(?, resolution), resolved_at = CASE WHEN ? = \'resolved\' THEN ? ELSE NULL END WHERE id = ?', b.to, b.resolution, b.to, new Date().toISOString(), i.id);
    audit(c, 'incident.status', 'incident', i.id, { status: i.status }, { status: b.to }); return { ok: true }; });

  // ───── Solicitudes de cambio ─────
  r.get('/api/events/:id/change-requests', (c) => { const e = getEvent(c, c.params.id);
    const rows = c.db.all('SELECT cr.*, u.display_name AS requester FROM change_requests cr JOIN users u ON u.id = cr.requested_by WHERE cr.event_id = ? ORDER BY cr.created_at DESC', e.id);
    return { change_requests: isStaff(c.user!) ? rows : rows.filter((x) => x.requested_by === c.user!.id).map(({ requester, ...x }) => { void requester; return x; }) }; });
  r.post('/api/events/:id/change-requests', (c) => {
    const e = getEvent(c, c.params.id); if (c.user!.role !== 'client' && !isStaff(c.user!)) throw forbidden();
    const b = parse(c.body, { reason: v.str({ max: 1000 }), target_type: v.oneOf(['event', 'service_request', 'timeline_item', 'other'], { optional: true }), target_id: v.id({ optional: true }), payload: v.json({ optional: true }) });
    const id = uid(); c.db.run('INSERT INTO change_requests (id, org_id, event_id, requested_by, target_type, target_id, payload, reason) VALUES (?,?,?,?,?,?,?,?)', id, e.org_id, e.id, c.user!.id, b.target_type ?? 'other', b.target_id, b.payload ?? '{}', b.reason);
    if (!isStaff(c.user!)) notifyPlanners(c.db, e.org_id, e.id, { type: 'change_request', title: 'Solicitud de cambio del cliente', body: e.folio, link: `#/events/${e.id}` });
    return { id };
  });
  r.post('/api/change-requests/:id/decide', (c) => { need(c.user!, 'events.write');
    const cr = c.db.get('SELECT * FROM change_requests WHERE id = ? AND org_id = ?', c.params.id, c.user!.org_id); if (!cr) throw notFound('Solicitud');
    getEvent(c, cr.event_id);
    const b = parse(c.body, { approve: v.bool(), note: v.str({ max: 500, optional: true }) });
    if (cr.status !== 'pending') throw conflict('Esta solicitud ya fue resuelta');
    c.db.tx(() => {
      if (b.approve) {   // los cambios autorizados sobre horarios se aplican con registro; el resto queda para ejecución manual de la planner
        const p = JSON.parse(cr.payload);
        if (cr.target_type === 'timeline_item' && cr.target_id) for (const k of ['item_date', 'start_time', 'end_time']) if (typeof p[k] === 'string') c.db.run(`UPDATE timeline_items SET ${k} = ?, updated_at = ? WHERE id = ? AND event_id = ?`, p[k], new Date().toISOString(), cr.target_id, cr.event_id);
        if (cr.target_type === 'assignment' && cr.target_id) for (const k of ['arrival_time', 'setup_time', 'start_time', 'end_time', 'teardown_time']) if (typeof p[k] === 'string' && /^\d\d:\d\d$/.test(p[k])) c.db.run(`UPDATE service_assignments SET ${k} = ?, updated_at = ? WHERE id = ? AND event_id = ?`, p[k], new Date().toISOString(), cr.target_id, cr.event_id);
      }
      c.db.run('UPDATE change_requests SET status = ?, decided_by = ?, decided_at = ?, decision_note = ? WHERE id = ?', b.approve ? 'approved' : 'rejected', c.user!.id, new Date().toISOString(), b.note, cr.id);
      audit(c, b.approve ? 'change.approve' : 'change.reject', 'change_request', cr.id, { status: 'pending' }, { status: b.approve ? 'approved' : 'rejected' }, b.note);
    });
    notify(c.db, { orgId: cr.org_id, userId: cr.requested_by, eventId: null, type: 'change_decision', title: b.approve ? 'Tu solicitud de cambio fue aprobada' : 'Tu solicitud de cambio no fue aprobada', body: b.note });
    return { ok: true };
  });
  void ({} as Row);
}
