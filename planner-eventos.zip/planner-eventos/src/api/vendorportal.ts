import type { Router, Ctx } from '../http.ts';
import { conflict, forbidden, invalid, notFound } from '../lib/errors.ts';
import { uid } from '../lib/db.ts';
import type { Row } from '../lib/db.ts';
import { parse, v } from '../lib/validate.ts';
import { audit, notifyPlanners } from '../services.ts';

function me(c: Ctx): string { if (c.user!.role !== 'vendor' || !c.user!.vendor_id) throw forbidden(); return c.user!.vendor_id; }
function own(c: Ctx, id: string): Row {
  const a = c.db.get('SELECT * FROM service_assignments WHERE id = ? AND vendor_id = ? AND org_id = ?', id, me(c), c.user!.org_id);
  if (!a) throw notFound('Asignación');     // 404 también para asignaciones de otros proveedores
  return a;
}
/** Proyección autorizada: sin costos, sin nombre del cliente ni del evento, sin otros proveedores. */
export function vendorView(a: Row, eventType: string, folio: string) {
  return { id: a.id, status: a.status, title: a.public_title, event_type: eventType, folio, service: a.service_description, qty_milli: a.qty_milli, date: a.service_date,
    arrival_time: a.arrival_time, setup_time: a.setup_time, start_time: a.start_time, end_time: a.end_time, teardown_time: a.teardown_time,
    location: a.location_visible ? a.location_detail : null, instructions: a.instructions, requirements: a.requirements, staff_needed: a.staff_needed,
    reject_reason: a.reject_reason, arrived_at: a.arrived_at, started_at: a.started_at, finished_at: a.finished_at };
}

export function register(r: Router) {
  r.get('/api/vendor/assignments', (c) => {
    const vid = me(c);
    const rows = c.db.all(`SELECT a.*, e.type AS ev_type, e.folio FROM service_assignments a JOIN events e ON e.id = a.event_id WHERE a.vendor_id = ? AND a.org_id = ? ORDER BY a.service_date, a.start_time`, vid, c.user!.org_id);
    return { assignments: rows.map((a) => vendorView(a, a.ev_type, a.folio)) };
  });
  r.get('/api/vendor/assignments/:id', (c) => {
    const a = own(c, c.params.id);
    const e = c.db.get('SELECT type, folio FROM events WHERE id = ?', a.event_id)!;
    return {
      assignment: vendorView(a, e.type, e.folio),
      checklist: c.db.all('SELECT id, phase, text, done FROM assignment_checklist WHERE assignment_id = ?', a.id),
      tasks: c.db.all(`SELECT id, title, description, due_date, status FROM tasks WHERE assignment_id = ? AND audience = 'vendor'`, a.id),
      timeline: c.db.all('SELECT id, item_date, start_time, end_time, title, instructions, status FROM timeline_items WHERE assignment_id = ? AND vendor_id = ? ORDER BY item_date, start_time', a.id, me(c)),
      documents: c.db.all(`SELECT d.id, d.name, d.kind, d.mime, d.size_bytes FROM documents d JOIN document_permissions p ON p.document_id = d.id WHERE p.vendor_id = ? AND d.event_id = ? AND d.status = 'active'`, me(c), a.event_id),
    };
  });
  r.post('/api/vendor/assignments/:id/respond', (c) => {
    const a = own(c, c.params.id);
    const b = parse(c.body, { accept: v.bool(), reason: v.str({ max: 300, optional: true }) });
    if (a.status !== 'requested') throw conflict('Esta solicitud ya fue respondida');
    if (!b.accept && !b.reason) throw invalid('Indica el motivo del rechazo', { reason: 'Obligatorio' });
    c.db.tx(() => {
      c.db.run('UPDATE service_assignments SET status = ?, reject_reason = ?, updated_at = ? WHERE id = ?', b.accept ? 'accepted' : 'rejected', b.accept ? null : b.reason, new Date().toISOString(), a.id);
      if (!b.accept && a.request_id) c.db.run(`UPDATE service_requests SET status = 'in_review', updated_at = ? WHERE id = ? AND status = 'pending_vendor'`, new Date().toISOString(), a.request_id);
      audit(c, b.accept ? 'assignment.vendor_accept' : 'assignment.vendor_reject', 'assignment', a.id, { status: a.status }, { status: b.accept ? 'accepted' : 'rejected' }, b.reason);
    });
    const ev = c.db.get('SELECT folio FROM events WHERE id = ?', a.event_id)!;
    notifyPlanners(c.db, a.org_id, a.event_id, { type: b.accept ? 'assignment_accepted' : 'assignment_rejected', title: b.accept ? 'Un proveedor aceptó la asignación' : 'Un proveedor rechazó la asignación', body: `${ev.folio} · ${a.service_description}`, link: `#/events/${a.event_id}`, priority: b.accept ? 'normal' : 'high' });
    return { ok: true };
  });
  for (const [path, col, label] of [['arrive', 'arrived_at', 'llegada'], ['start', 'started_at', 'inicio'], ['finish', 'finished_at', 'finalización']] as const) {
    r.post(`/api/vendor/assignments/:id/${path}`, (c) => {
      const a = own(c, c.params.id);
      if (a.status !== 'confirmed') throw conflict('Solo puedes registrar el servicio cuando la planner lo haya confirmado');
      if (a[col]) throw conflict(`La ${label} ya está registrada`);
      if (path === 'finish' && !a.started_at) throw conflict('Registra primero el inicio del servicio');
      c.db.tx(() => {
        c.db.run(`UPDATE service_assignments SET ${col} = ?, status = CASE WHEN ? = 'finish' THEN 'completed' ELSE status END, updated_at = ? WHERE id = ?`, new Date().toISOString(), path, new Date().toISOString(), a.id);
        if (path === 'finish' && a.request_id) c.db.run(`UPDATE service_requests SET status = 'completed', updated_at = ? WHERE id = ?`, new Date().toISOString(), a.request_id);
        audit(c, `assignment.${path}`, 'assignment', a.id, null, { [col]: true });
      });
      return { ok: true };
    });
  }
  r.post('/api/vendor/checklist/:id/toggle', (c) => {
    const it = c.db.get(`SELECT k.* FROM assignment_checklist k JOIN service_assignments a ON a.id = k.assignment_id WHERE k.id = ? AND a.vendor_id = ? AND a.org_id = ?`, c.params.id, me(c), c.user!.org_id);
    if (!it) throw notFound('Elemento');
    c.db.run('UPDATE assignment_checklist SET done = ?, done_at = ? WHERE id = ?', it.done ? 0 : 1, it.done ? null : new Date().toISOString(), it.id);
    return { ok: true, done: !it.done };
  });
  r.post('/api/vendor/assignments/:id/incidents', (c) => {
    const a = own(c, c.params.id);
    const b = parse(c.body, { description: v.str({ max: 2000 }), severity: v.oneOf(['low', 'medium', 'high', 'critical'], { optional: true }) });
    const id = uid();
    c.db.run('INSERT INTO incidents (id, org_id, event_id, assignment_id, vendor_id, reported_by, severity, description) VALUES (?,?,?,?,?,?,?,?)', id, a.org_id, a.event_id, a.id, a.vendor_id, c.user!.id, b.severity ?? 'medium', b.description);
    audit(c, 'incident.create', 'incident', id, null, { severity: b.severity ?? 'medium' });
    notifyPlanners(c.db, a.org_id, a.event_id, { type: 'incident', title: 'Incidencia reportada por un proveedor', body: a.public_title, link: `#/events/${a.event_id}`, priority: 'high' });
    return { id };
  });
  // El proveedor no modifica condiciones: envía una solicitud a la planner
  r.post('/api/vendor/assignments/:id/change-requests', (c) => {
    const a = own(c, c.params.id);
    const b = parse(c.body, { reason: v.str({ max: 1000 }), payload: v.json({ optional: true }) });
    const id = uid();
    c.db.run(`INSERT INTO change_requests (id, org_id, event_id, requested_by, target_type, target_id, payload, reason) VALUES (?,?,?,?,?,?,?,?)`, id, a.org_id, a.event_id, c.user!.id, 'assignment', a.id, b.payload ?? '{}', b.reason);
    notifyPlanners(c.db, a.org_id, a.event_id, { type: 'change_request', title: 'Un proveedor solicita un cambio', body: a.public_title, link: `#/events/${a.event_id}` });
    return { id };
  });
  r.post('/api/vendor/tasks/:id/complete', (c) => {
    const t = c.db.get(`SELECT t.* FROM tasks t JOIN service_assignments a ON a.id = t.assignment_id WHERE t.id = ? AND a.vendor_id = ? AND t.audience = 'vendor'`, c.params.id, me(c));
    if (!t) throw notFound('Tarea');
    c.db.run(`UPDATE tasks SET status = 'completed', completed_at = ? WHERE id = ?`, new Date().toISOString(), t.id);
    return { ok: true };
  });
  r.get('/api/vendor/profile', (c) => {
    const x = c.db.get('SELECT business_name, contact_name, phone, email, address, city, categories, description, coverage, setup_minutes, teardown_minutes, tech_requirements, payment_terms, cancellation_policy FROM vendors WHERE id = ?', me(c))!;
    return { profile: { ...x, categories: JSON.parse(x.categories) }, availability: c.db.all('SELECT date, status, capacity, note FROM vendor_availability WHERE vendor_id = ? ORDER BY date', me(c)), blackouts: c.db.all('SELECT id, start_date, end_date, reason FROM vendor_blackouts WHERE vendor_id = ?', me(c)) };
  });
}
