import { Db, migrate } from './lib/db.ts';
import { Router, createHandler } from './http.ts';
import { config } from './config.ts';
import path from 'node:path';
import * as auth from './api/auth.ts';
import * as admin from './api/admin.ts';
import * as events from './api/events.ts';
import * as commerce from './api/commerce.ts';
import * as vendorportal from './api/vendorportal.ts';
import * as finance from './api/finance.ts';
import * as ops from './api/ops.ts';
import * as collab from './api/collab.ts';
import * as automations from './api/automations.ts';

export function createApp(dbPath = config.dbPath) {
  const db = new Db(dbPath);
  migrate(db, path.join(config.root, 'migrations', 'sqlite'));
  const router = new Router();
  for (const m of [auth, admin, events, commerce, vendorportal, finance, ops, collab, automations]) m.register(router);
  return { db, handler: createHandler(db, router) };
}
