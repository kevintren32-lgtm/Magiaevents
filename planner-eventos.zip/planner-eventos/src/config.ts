import path from 'node:path';
import { randomBytes } from 'node:crypto';

const root = path.resolve(import.meta.dirname, '..');
const env = process.env.NODE_ENV ?? 'development';

// En producción APP_SECRET es obligatorio (enlaces firmados y webhooks). En desarrollo se genera uno efímero.
let secret: string = process.env.APP_SECRET ?? '';
if (!secret) {
  if (env === 'production') throw new Error('APP_SECRET es obligatorio en producción');
  secret = randomBytes(32).toString('hex');
}

export interface Config {
  root: string; env: string; port: number; dbPath: string; storageDir: string; publicDir: string;
  secret: string; secureCookies: boolean; sessionTtlHours: number; maxUploadBytes: number;
  gatewayWebhookSecret: string; trustProxy: boolean;
}

export const config: Config = {
  root,
  env,
  port: Number(process.env.PORT ?? 3000),
  dbPath: process.env.DB_PATH ?? path.join(root, 'data', 'app.db'),
  storageDir: process.env.STORAGE_DIR ?? path.join(root, 'data', 'storage'),
  publicDir: path.join(root, 'public'),
  secret,
  secureCookies: env === 'production',
  sessionTtlHours: 12,
  maxUploadBytes: 5 * 1024 * 1024,
  gatewayWebhookSecret: process.env.GATEWAY_WEBHOOK_SECRET ?? '',
  trustProxy: process.env.TRUST_PROXY === '1',
};
