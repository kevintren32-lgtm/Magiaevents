import { toMin } from '../lib/time.ts';

export interface Window { date: string; start: string; end: string }
export interface ExistingAssignment { id: string; status: string; date: string; start: string; end: string }
export interface AvailabilityInput {
  window: Window;
  blackouts: { start: string; end: string }[];
  dayRows: { date: string; status: 'available' | 'unavailable'; capacity: number }[];
  assignments: ExistingAssignment[];
  setupMin: number; teardownMin: number; ignoreAssignmentId?: string;
}
export interface AvailabilityResult { state: 'available' | 'unavailable' | 'unknown'; reasons: string[] }

/** "unknown" = no hay registro explícito de disponibilidad: NO se asume disponible. */
export function checkAvailability(i: AvailabilityInput): AvailabilityResult {
  const reasons: string[] = [];
  const d = i.window.date;
  if (i.blackouts.some((b) => b.start <= d && d <= b.end)) reasons.push('El proveedor tiene un bloqueo (vacaciones/no disponible) en esa fecha');
  const row = i.dayRows.find((r) => r.date === d);
  if (row?.status === 'unavailable') reasons.push('El proveedor marcó la fecha como no disponible');
  const active = i.assignments.filter((a) => a.id !== i.ignoreAssignmentId && a.date === d && ['requested', 'accepted', 'confirmed'].includes(a.status));
  const cap = row?.capacity ?? 1;
  const confirmedCount = active.filter((a) => a.status !== 'requested').length;
  if (confirmedCount >= cap) reasons.push(`Capacidad del día agotada (${confirmedCount}/${cap})`);
  const s = toMin(i.window.start) - i.setupMin, e = toMin(i.window.end) + i.teardownMin;
  for (const a of active) {
    if (s < toMin(a.end) && toMin(a.start) < e) reasons.push('Traslape con otra asignación (incluye montaje/desmontaje)');
  }
  if (reasons.length) return { state: 'unavailable', reasons };
  if (row?.status === 'available') return { state: 'available', reasons: [] };
  return { state: 'unknown', reasons: ['Sin disponibilidad confirmada: requiere confirmación manual del proveedor'] };
}
