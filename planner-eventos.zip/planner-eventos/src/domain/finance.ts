import { lineAmount, taxOf } from './money.ts';

export interface LineIn { description: string; qtyMilli: number; unitPriceCents: number; discountCents?: number; taxBps: number; requestId?: string | null }
export interface QuoteOpts { chargesCents?: number; chargesTaxBps?: number; advanceBps?: number }
export interface LineOut extends LineIn { grossCents: number; taxCents: number; totalCents: number }
export interface QuoteTotals { lines: LineOut[]; subtotalCents: number; discountCents: number; chargesCents: number; taxCents: number; totalCents: number; advanceCents: number }

/** Fórmula: bruto = round(precio×cant); base = bruto − descuento; IVA = round(base×tasa); total = Σ(base+IVA) + cargos + IVA(cargos). */
export function computeQuote(lines: LineIn[], o: QuoteOpts = {}): QuoteTotals {
  const out: LineOut[] = lines.map((l) => {
    const discount = l.discountCents ?? 0;
    if (l.qtyMilli <= 0 || l.unitPriceCents < 0 || discount < 0) throw new Error('Línea inválida');
    const gross = lineAmount(l.unitPriceCents, l.qtyMilli);
    if (discount > gross) throw new Error('El descuento no puede superar el importe de la línea');
    const base = gross - discount;
    const tax = taxOf(base, l.taxBps);
    return { ...l, discountCents: discount, grossCents: gross, taxCents: tax, totalCents: base + tax };
  });
  const charges = o.chargesCents ?? 0;
  const chargesTax = taxOf(charges, o.chargesTaxBps ?? 0);
  const subtotal = out.reduce((s, l) => s + l.grossCents, 0);
  const discount = out.reduce((s, l) => s + (l.discountCents ?? 0), 0);
  const tax = out.reduce((s, l) => s + l.taxCents, 0) + chargesTax;
  const total = out.reduce((s, l) => s + l.totalCents, 0) + charges + chargesTax;
  return { lines: out, subtotalCents: subtotal, discountCents: discount, chargesCents: charges, taxCents: tax, totalCents: total, advanceCents: taxOf(total, o.advanceBps ?? 0) };
}

export interface PayIn { direction: 'in' | 'out'; status: string; amountCents: number; paidCents: number; verified: boolean }
export interface AssignIn { status: string; costCents: number; actualCostCents: number | null }
export interface FinIn {
  contractedTotalCents: number; contractedTaxCents: number;
  payments: PayIn[]; assignments: AssignIn[]; expensesCents: number;
  adjustments: { kind: string; amountCents: number }[];
}
export interface FinOut {
  contracted: number; clientAdjustments: number; refunds: number;
  collectedRegistered: number; collectedVerified: number; clientBalance: number;
  vendorCostContracted: number; vendorPaid: number; vendorOwed: number;
  estimatedCost: number; realCost: number; revenueNet: number; estimatedProfit: number; finalProfit: number; marginPct: number | null;
}
const COUNTS = new Set(['paid', 'partially_paid']);
const ACTIVE_ASSIGN = new Set(['requested', 'accepted', 'confirmed', 'completed']);
const REAL_ASSIGN = new Set(['confirmed', 'completed']);

/**
 * Cobrado = Σ paid_cents de pagos 'in' en estado paid/partially_paid − reembolsos. Los cancelados/pendientes NO suman.
 * Saldo cliente = contratado + ajustes(cargo/crédito) − cobrado.
 * Ingreso neto = contratado − IVA (+ajustes). Costos reales usan costo real si existe, si no el contratado (solo asignaciones confirmadas/completadas) + gastos.
 * Los costos de proveedor se capturan sin IVA recuperable (supuesto documentado).
 */
export function computeEventFinancials(i: FinIn): FinOut {
  const sumAdj = (k: string[]) => i.adjustments.filter((a) => k.includes(a.kind)).reduce((s, a) => s + a.amountCents, 0);
  const refunds = Math.abs(sumAdj(['refund']));
  const clientAdjustments = sumAdj(['client_credit', 'client_charge', 'correction']);
  const inPays = i.payments.filter((p) => p.direction === 'in' && COUNTS.has(p.status));
  const collectedRegistered = inPays.reduce((s, p) => s + p.paidCents, 0) - refunds;
  const collectedVerified = inPays.filter((p) => p.verified).reduce((s, p) => s + p.paidCents, 0) - refunds;
  const outPays = i.payments.filter((p) => p.direction === 'out' && COUNTS.has(p.status));
  const vendorPaid = outPays.reduce((s, p) => s + p.paidCents, 0);
  const vendorCostContracted = i.assignments.filter((a) => ACTIVE_ASSIGN.has(a.status)).reduce((s, a) => s + a.costCents, 0);
  const realVendor = i.assignments.filter((a) => REAL_ASSIGN.has(a.status)).reduce((s, a) => s + (a.actualCostCents ?? a.costCents), 0);
  const vendorAdj = sumAdj(['vendor_adjustment']);
  const estimatedCost = vendorCostContracted + vendorAdj;
  const realCost = realVendor + i.expensesCents + vendorAdj;
  const revenueNet = i.contractedTotalCents - i.contractedTaxCents + clientAdjustments;
  const finalProfit = revenueNet - realCost;
  return {
    contracted: i.contractedTotalCents, clientAdjustments, refunds,
    collectedRegistered, collectedVerified,
    clientBalance: i.contractedTotalCents + clientAdjustments - collectedRegistered,
    vendorCostContracted, vendorPaid, vendorOwed: Math.max(0, vendorCostContracted - vendorPaid),
    estimatedCost, realCost, revenueNet,
    estimatedProfit: revenueNet - estimatedCost - i.expensesCents,
    finalProfit,
    marginPct: revenueNet > 0 ? Math.round((finalProfit / revenueNet) * 10000) / 100 : null,
  };
}
