// Dinero en centavos enteros. Redondeo "mitad hacia arriba (lejos de cero)" con BigInt: sin errores de punto flotante.
export function mulDivRound(a: number, b: number, d: number): number {
  if (!Number.isInteger(a) || !Number.isInteger(b) || !Number.isInteger(d) || d === 0) throw new Error('mulDivRound requiere enteros');
  if (a === 0 || b === 0) return 0;
  const sign = (a < 0 ? -1 : 1) * (b < 0 ? -1 : 1) * (d < 0 ? -1 : 1);
  const A = BigInt(Math.abs(a)), B = BigInt(Math.abs(b)), D = BigInt(Math.abs(d));
  return sign * Number((A * B * 2n + D) / (2n * D));
}
export const lineAmount = (unitCents: number, qtyMilli: number) => mulDivRound(unitCents, qtyMilli, 1000);
export const taxOf = (baseCents: number, bps: number) => mulDivRound(baseCents, bps, 10000);

export function parseMoney(input: string): number {
  const s = input.trim().replace(/[$\s]/g, '').replace(/,/g, '');
  if (!/^-?\d+(\.\d{1,2})?$/.test(s)) throw new Error('Importe inválido');
  const neg = s.startsWith('-');
  const [i, f = ''] = s.replace('-', '').split('.');
  const cents = Number(i) * 100 + Number((f + '00').slice(0, 2));
  return neg ? -cents : cents;
}
export function formatMoney(cents: number, currency = 'MXN', locale = 'es-MX'): string {
  return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(cents / 100);
}
