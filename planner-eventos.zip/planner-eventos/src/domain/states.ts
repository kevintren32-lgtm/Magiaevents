export type Transitions = Record<string, readonly string[]>;

export const EVENT_TRANSITIONS: Transitions = {
  prospect: ['initial_consult', 'cancelled', 'archived'],
  initial_consult: ['preparing', 'cancelled'],
  preparing: ['proposal_drafting', 'cancelled'],
  proposal_drafting: ['proposal_sent', 'cancelled'],
  proposal_sent: ['pending_approval', 'proposal_drafting', 'cancelled'],
  pending_approval: ['contracted', 'proposal_drafting', 'cancelled'],
  contracted: ['planning', 'cancelled'],
  planning: ['confirmed', 'cancelled'],
  confirmed: ['in_execution', 'planning', 'cancelled'],
  in_execution: ['finished'],
  finished: ['closed'],
  closed: ['archived'],
  cancelled: ['archived'],
  archived: [],
};

export const REQUEST_TRANSITIONS: Transitions = {
  draft: ['requested', 'cancelled'],
  requested: ['in_review', 'cancelled'],
  in_review: ['info_required', 'quote_preparing', 'rejected', 'cancelled'],
  info_required: ['in_review', 'cancelled'],
  quote_preparing: ['quote_sent', 'in_review', 'cancelled'],
  quote_sent: ['client_approved', 'quote_preparing', 'rejected', 'cancelled'],
  client_approved: ['pending_vendor', 'confirmed', 'quote_preparing', 'cancelled'],
  pending_vendor: ['confirmed', 'in_review', 'cancelled'],
  confirmed: ['contracted', 'completed', 'cancelled'],
  contracted: ['completed', 'cancelled'],
  rejected: [],
  cancelled: [],
  completed: [],
};
// Estados desde los que el cliente puede retirar su solicitud (antes de aprobar).
export const CLIENT_CANCELLABLE = new Set(['draft', 'requested', 'in_review', 'info_required', 'quote_preparing', 'quote_sent']);

export const ASSIGNMENT_TRANSITIONS: Transitions = {
  requested: ['accepted', 'rejected', 'cancelled'],
  accepted: ['confirmed', 'cancelled'],
  confirmed: ['completed', 'cancelled'],
  rejected: [],
  completed: [],
  cancelled: [],
};

export function canTransition(map: Transitions, from: string, to: string): boolean {
  return (map[from] ?? []).includes(to);
}
