import { toMin } from '../lib/time.ts';

export interface TItem { id: string; date: string; start: string; end: string; title: string; vendorId: string | null; status: string; deps: string[] }
export interface Alert { type: 'overlap_vendor' | 'invalid_range' | 'dependency_order' | 'dependency_incomplete' | 'insufficient_gap'; message: string; itemIds: string[] }

export function detectConflicts(items: TItem[], minGapMin = 0): Alert[] {
  const alerts: Alert[] = [];
  const live = items.filter((i) => i.status !== 'cancelled');
  const byId = new Map(live.map((i) => [i.id, i]));
  for (const i of live) if (toMin(i.end) <= toMin(i.start)) alerts.push({ type: 'invalid_range', message: `«${i.title}» termina antes de empezar`, itemIds: [i.id] });
  for (let a = 0; a < live.length; a++) for (let b = a + 1; b < live.length; b++) {
    const x = live[a], y = live[b];
    if (!x.vendorId || x.vendorId !== y.vendorId || x.date !== y.date) continue;
    const overlap = toMin(x.start) < toMin(y.end) && toMin(y.start) < toMin(x.end);
    if (overlap) alerts.push({ type: 'overlap_vendor', message: `«${x.title}» y «${y.title}» se traslapan para el mismo proveedor`, itemIds: [x.id, y.id] });
    else if (minGapMin > 0) {
      const gap = x.end <= y.start ? toMin(y.start) - toMin(x.end) : toMin(x.start) - toMin(y.end);
      if (gap < minGapMin) alerts.push({ type: 'insufficient_gap', message: `Menos de ${minGapMin} min entre «${x.title}» y «${y.title}»`, itemIds: [x.id, y.id] });
    }
  }
  for (const i of live) for (const d of i.deps) {
    const dep = byId.get(d); if (!dep) continue;
    const depEnd = `${dep.date}T${dep.end}`, iStart = `${i.date}T${i.start}`;
    if (depEnd > iStart) alerts.push({ type: 'dependency_order', message: `«${i.title}» empieza antes de que termine «${dep.title}»`, itemIds: [i.id, dep.id] });
    if (['in_progress', 'done'].includes(i.status) && dep.status !== 'done') alerts.push({ type: 'dependency_incomplete', message: `«${i.title}» avanzó sin completar «${dep.title}»`, itemIds: [i.id, dep.id] });
  }
  return alerts;
}
