import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { config } from './config.ts';
import { HttpError, forbidden, notFound, unauthorized } from './lib/errors.ts';
import type { Db, Row } from './lib/db.ts';
import { sha256 } from './lib/crypto.ts';
import { nowIso } from './lib/time.ts';

export interface User { id: string; org_id: string; role: 'owner' | 'staff' | 'client' | 'vendor'; email: string; display_name: string; permissions: string[]; client_id: string | null; vendor_id: string | null; prefs: Record<string, any> }
export interface Ctx { db: Db; user: User | null; params: Record<string, string>; query: URLSearchParams; body: any; ip: string; req: any; res: any; cookies: Record<string, string>; setCookie: (c: string) => void; raw?: Buffer }
export class Reply { status: number; body: unknown; headers: Record<string, string>; constructor(status: number, body: unknown, headers: Record<string, string> = {}) { this.status = status; this.body = body; this.headers = headers; } }
type Handler = (c: Ctx) => unknown | Promise<unknown>;
interface Route { method: string; re: RegExp; keys: string[]; auth: boolean; h: Handler }

export class Router {
  routes: Route[] = [];
  add(method: string, pattern: string, auth: boolean, h: Handler) {
    const keys: string[] = [];
    const re = new RegExp('^' + pattern.replace(/:([a-z]+)/g, (_m, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    this.routes.push({ method, re, keys, auth, h });
  }
  get = (p: string, h: Handler) => this.add('GET', p, true, h);
  post = (p: string, h: Handler) => this.add('POST', p, true, h);
  patch = (p: string, h: Handler) => this.add('PATCH', p, true, h);
  put = (p: string, h: Handler) => this.add('PUT', p, true, h);
  del = (p: string, h: Handler) => this.add('DELETE', p, true, h);
  open = (m: string, p: string, h: Handler) => this.add(m, p, false, h);
}

const MIME: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };
const SEC: Record<string, string> = {
  'content-security-policy': "default-src 'self'; img-src 'self' data: https:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer', 'x-frame-options': 'DENY', 'permissions-policy': 'camera=(), microphone=(), geolocation=()',
};

export function loadUser(db: Db, sid: string | undefined): User | null {
  if (!sid) return null;
  const r = db.get(`SELECT u.*, c.id AS client_id, v.id AS vendor_id FROM sessions s JOIN users u ON u.id = s.user_id
    LEFT JOIN clients c ON c.user_id = u.id LEFT JOIN vendors v ON v.user_id = u.id
    WHERE s.id = ? AND s.revoked_at IS NULL AND s.expires_at > ? AND u.status = 'active'`, sha256(sid), nowIso());
  if (!r) return null;
  return { id: r.id, org_id: r.org_id, role: r.role, email: r.email, display_name: r.display_name, permissions: JSON.parse(r.permissions), client_id: r.client_id, vendor_id: r.vendor_id, prefs: JSON.parse(r.prefs) };
}

function readBody(req: any, limit: number): Promise<Buffer> {
  // Si el cuerpo excede el límite se descarta (sin guardarlo en memoria) y se responde 413 con un mensaje claro.
  return new Promise((res, rej) => {
    const chunks: Buffer[] = []; let n = 0; let tooBig = false;
    req.on('data', (c: Buffer) => {
      n += c.length;
      if (n > limit) { tooBig = true; chunks.length = 0; if (n > limit * 8) req.destroy(); } else if (!tooBig) chunks.push(c);
    });
    req.on('end', () => (tooBig ? rej(new HttpError(413, 'too_large', 'El archivo supera el tamaño máximo permitido (5 MB)')) : res(Buffer.concat(chunks))));
    req.on('error', rej);
  });
}

export function createHandler(db: Db, router: Router) {
  return async (req: any, res: any) => {
    const rid = randomUUID().slice(0, 8);
    const send = (status: number, body: unknown, headers: Record<string, string> = {}) => {
      const payload = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
      res.writeHead(status, { ...SEC, 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers });
      res.end(payload);
    };
    try {
      const url = new URL(req.url ?? '/', 'http://localhost');
      if (!url.pathname.startsWith('/api/')) return serveStatic(url.pathname, res);
      const cookies: Record<string, string> = {};
      for (const p of String(req.headers.cookie ?? '').split(';')) { const i = p.indexOf('='); if (i > 0) cookies[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); }
      const fwd = config.trustProxy ? String(req.headers['x-forwarded-for'] ?? '').split(',')[0].trim() : '';
      const ip = fwd || req.socket.remoteAddress || 'unknown';
      const method = String(req.method);
      const route = router.routes.find((r) => r.method === method && r.re.test(url.pathname));
      if (!route) throw notFound('Ruta');
      if (method !== 'GET' && method !== 'HEAD') {   // CSRF: cabecera personalizada + Origin coincidente (cookie SameSite=Strict además)
        if (req.headers['x-requested-with'] !== 'fetch' && !url.pathname.startsWith('/api/webhooks/')) throw forbidden('Solicitud no permitida');
        const origin = req.headers.origin; if (origin && new URL(origin).host !== req.headers.host) throw forbidden('Origen no permitido');
      }
      const m = url.pathname.match(route.re)!;
      const params: Record<string, string> = {}; route.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
      let body: any = undefined; let raw: Buffer | undefined;
      if (method !== 'GET' && method !== 'HEAD') {
        raw = await readBody(req, url.pathname.endsWith('/documents') ? Math.ceil(config.maxUploadBytes * 1.4) : 1_000_000);
        if (raw.length) { try { body = JSON.parse(raw.toString('utf8')); } catch { if (!url.pathname.startsWith('/api/webhooks/')) throw new HttpError(400, 'bad_json', 'JSON inválido'); } }
        else body = {};
      }
      const user = loadUser(db, cookies.sid);
      if (route.auth && !user) throw unauthorized();
      const setCookies: string[] = [];
      const ctx: Ctx = { db, user, params, query: url.searchParams, body, ip, req, res, cookies, setCookie: (c) => setCookies.push(c), raw };
      const out = await route.h(ctx);
      const extra: Record<string, string> = {}; if (setCookies.length) (extra as any)['set-cookie'] = setCookies;
      if (out instanceof Reply) return send(out.status, out.body, { ...out.headers, ...extra });
      return send(200, out ?? { ok: true }, extra);
    } catch (e) {
      if (e instanceof HttpError) return send(e.status, { error: { code: e.code, message: e.message, details: e.details } });
      console.error(`[${rid}]`, e);                       // el detalle técnico solo va al log del servidor
      return send(500, { error: { code: 'internal', message: `Ocurrió un error inesperado. Referencia: ${rid}` } });
    }
  };
}

function serveStatic(p: string, res: any) {
  const clean = path.normalize(decodeURIComponent(p)).replace(/^(\.\.[/\\])+/, '');
  let file = path.join(config.publicDir, clean === '/' ? 'index.html' : clean);
  if (!file.startsWith(config.publicDir)) { res.writeHead(403); return res.end(); }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(config.publicDir, 'index.html');
  res.writeHead(200, { ...SEC, 'content-type': MIME[path.extname(file)] ?? 'application/octet-stream', 'cache-control': 'no-cache' });
  fs.createReadStream(file).pipe(res);
}
export type { Row };
