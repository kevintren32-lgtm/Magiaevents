import { createHash, createHmac, randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { config } from '../config.ts';

export const sha256 = (s: string | Buffer) => createHash('sha256').update(s).digest('hex');
export const token = (bytes = 32) => randomBytes(bytes).toString('base64url');
export const hmac = (key: string, data: string) => createHmac('sha256', key).update(data).digest('hex');
export const safeEqual = (a: string, b: string) => {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
};

const N = 16384, R = 8, P = 1, KEYLEN = 64;
const scryptAsync = (pw: string, salt: Buffer, n: number, r: number, p: number): Promise<Buffer> =>
  new Promise((res, rej) => scrypt(pw, salt, KEYLEN, { N: n, r, p, maxmem: 64 * 1024 * 1024 }, (e: Error | null, k: Buffer) => (e ? rej(e) : res(k))));

export async function hashPassword(pw: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await scryptAsync(pw, salt, N, R, P);
  return `scrypt$${N}$${R}$${P}$${salt.toString('base64')}$${key.toString('base64')}`;
}
const DUMMY = `scrypt$${N}$${R}$${P}$${Buffer.alloc(16).toString('base64')}$${Buffer.alloc(KEYLEN).toString('base64')}`;
export async function verifyPassword(pw: string, stored: string | null | undefined): Promise<boolean> {
  const h = stored ?? DUMMY; // tiempo constante aproximado aunque la cuenta no exista
  const [, n, r, p, salt, key] = h.split('$');
  const k = await scryptAsync(pw, Buffer.from(salt, 'base64'), Number(n), Number(r), Number(p));
  const ok = timingSafeEqual(k, Buffer.from(key, 'base64'));
  return stored ? ok : false;
}

const COMMON = new Set(['password1234', '1234567890', 'qwertyuiop', 'contraseña123', 'passw0rd123', 'administrador']);
export function passwordProblem(pw: unknown, email?: string): string | null {
  if (typeof pw !== 'string') return 'La contraseña es obligatoria';
  if (pw.length < 10) return 'La contraseña debe tener al menos 10 caracteres';
  if (pw.length > 128) return 'La contraseña es demasiado larga (máximo 128)';
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return 'Usa letras y números en la contraseña';
  if (COMMON.has(pw.toLowerCase())) return 'Esa contraseña es demasiado común';
  if (email && pw.toLowerCase().includes(email.split('@')[0].toLowerCase()) && email.split('@')[0].length > 3) return 'La contraseña no debe contener tu correo';
  return null;
}

// Enlaces temporales firmados para descargar documentos (HMAC + caducidad)
export function signDownload(docId: string, userId: string, ttlSec = 120, now = Date.now()): string {
  const exp = Math.floor(now / 1000) + ttlSec;
  const sig = hmac(config.secret, `${docId}.${userId}.${exp}`);
  return `exp=${exp}&sig=${sig}`;
}
export function verifyDownload(docId: string, userId: string, exp: string, sig: string, now = Date.now()): boolean {
  if (!/^\d+$/.test(exp) || Number(exp) < Math.floor(now / 1000)) return false;
  return safeEqual(hmac(config.secret, `${docId}.${userId}.${exp}`), sig);
}
