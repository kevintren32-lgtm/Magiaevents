import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

export type Row = Record<string, any>;
type Param = string | number | bigint | boolean | null | undefined;

const norm = (p: Param[]) => p.map((x) => (x === undefined ? null : typeof x === 'boolean' ? (x ? 1 : 0) : x));

export class Db {
  raw: any;
  depth = 0;
  constructor(file: string) {
    if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
    this.raw = new DatabaseSync(file);
    this.raw.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
    if (file !== ':memory:') this.raw.exec('PRAGMA journal_mode = WAL;');
  }
  all(sql: string, ...p: Param[]): Row[] {
    return this.raw.prepare(sql).all(...norm(p)).map((r: Row) => ({ ...r }));
  }
  get(sql: string, ...p: Param[]): Row | undefined {
    const r = this.raw.prepare(sql).get(...norm(p));
    return r ? { ...r } : undefined;
  }
  run(sql: string, ...p: Param[]): { changes: number } {
    const r = this.raw.prepare(sql).run(...norm(p));
    return { changes: Number(r.changes) };
  }
  tx<T>(fn: () => T): T {
    const top = this.depth === 0;
    const sp = `sp${this.depth}`;
    this.raw.exec(top ? 'BEGIN IMMEDIATE' : `SAVEPOINT ${sp}`);
    this.depth++;
    try {
      const out = fn();
      this.depth--;
      this.raw.exec(top ? 'COMMIT' : `RELEASE ${sp}`);
      return out;
    } catch (e) {
      this.depth--;
      this.raw.exec(top ? 'ROLLBACK' : `ROLLBACK TO ${sp}; RELEASE ${sp}`);
      throw e;
    }
  }
  close() { this.raw.close(); }
}

export const uid = () => randomUUID();

export function migrate(db: Db, dir: string): string[] {
  db.raw.exec('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
  const done = new Set(db.all('SELECT name FROM schema_migrations').map((r) => r.name));
  const applied: string[] = [];
  for (const f of fs.readdirSync(dir).filter((x: string) => x.endsWith('.sql')).sort()) {
    if (done.has(f)) continue;
    db.raw.exec('BEGIN');
    try {
      db.raw.exec(fs.readFileSync(path.join(dir, f), 'utf8'));
      db.raw.prepare('INSERT INTO schema_migrations (name, applied_at) VALUES (?, ?)').run(f, new Date().toISOString());
      db.raw.exec('COMMIT');
      applied.push(f);
    } catch (e) {
      db.raw.exec('ROLLBACK');
      throw new Error(`Migración ${f} falló: ${(e as Error).message}`);
    }
  }
  return applied;
}
