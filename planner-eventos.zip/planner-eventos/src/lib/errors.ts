export class HttpError extends Error {
  status: number;
  code: string;
  details: unknown;
  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}
export const badRequest = (msg = 'Solicitud inválida', details?: unknown) => new HttpError(400, 'bad_request', msg, details);
export const unauthorized = (msg = 'Inicia sesión para continuar') => new HttpError(401, 'unauthorized', msg);
export const forbidden = (msg = 'No tienes permiso para realizar esta acción') => new HttpError(403, 'forbidden', msg);
export const notFound = (what = 'Recurso') => new HttpError(404, 'not_found', `${what} no encontrado`);
export const conflict = (msg: string, details?: unknown) => new HttpError(409, 'conflict', msg, details);
export const invalid = (msg: string, details?: unknown) => new HttpError(422, 'validation', msg, details);
export const tooMany = (msg = 'Demasiados intentos. Espera unos minutos e inténtalo de nuevo') => new HttpError(429, 'rate_limited', msg);
