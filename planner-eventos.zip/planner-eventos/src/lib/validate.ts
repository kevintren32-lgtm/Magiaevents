import { invalid } from './errors.ts';
import { isDate, isTime } from './time.ts';

export type Rule = (v: unknown) => unknown;
export type Spec = Record<string, Rule>;
interface Opt { optional?: boolean; nullable?: boolean }

const wrap = (opt: Opt, f: (v: any) => unknown): Rule => (v) => {
  if (v === undefined) { if (opt.optional) return undefined; throw new Error('Campo obligatorio'); }
  if (v === null || v === '') { if (opt.nullable || opt.optional) return null; throw new Error('Campo obligatorio'); }
  return f(v);
};

export const v = {
  str: (o: Opt & { min?: number; max?: number } = {}): Rule => wrap(o, (x) => {
    if (typeof x !== 'string') throw new Error('Debe ser texto');
    const s = x.trim();
    if (s.length < (o.min ?? 1)) throw new Error(`Mínimo ${o.min ?? 1} caracteres`);
    if (s.length > (o.max ?? 500)) throw new Error(`Máximo ${o.max ?? 500} caracteres`);
    return s;
  }),
  int: (o: Opt & { min?: number; max?: number } = {}): Rule => wrap(o, (x) => {
    if (typeof x !== 'number' || !Number.isInteger(x)) throw new Error('Debe ser un entero');
    if (x < (o.min ?? -1e12) || x > (o.max ?? 1e12)) throw new Error('Fuera de rango');
    return x;
  }),
  bool: (o: Opt = {}): Rule => wrap(o, (x) => { if (typeof x !== 'boolean') throw new Error('Debe ser verdadero o falso'); return x ? 1 : 0; }),
  oneOf: (vals: readonly string[], o: Opt = {}): Rule => wrap(o, (x) => { if (typeof x !== 'string' || !vals.includes(x)) throw new Error(`Valor permitido: ${vals.join(', ')}`); return x; }),
  date: (o: Opt = {}): Rule => wrap(o, (x) => { if (!isDate(x)) throw new Error('Fecha inválida (AAAA-MM-DD)'); return x; }),
  time: (o: Opt = {}): Rule => wrap(o, (x) => { if (!isTime(x)) throw new Error('Hora inválida (HH:MM)'); return x; }),
  email: (o: Opt = {}): Rule => wrap(o, (x) => {
    if (typeof x !== 'string' || x.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x.trim())) throw new Error('Correo inválido');
    return x.trim().toLowerCase();
  }),
  json: (o: Opt = {}): Rule => wrap(o, (x) => {
    if (typeof x !== 'object') throw new Error('Debe ser un objeto');
    const s = JSON.stringify(x);
    if (s.length > 20000) throw new Error('Demasiado grande');
    return s;
  }),
  strArr: (o: Opt & { max?: number } = {}): Rule => wrap(o, (x) => {
    if (!Array.isArray(x) || x.length > (o.max ?? 50) || x.some((i) => typeof i !== 'string' || i.length > 80)) throw new Error('Lista inválida');
    return JSON.stringify(x);
  }),
  id: (o: Opt = {}): Rule => wrap(o, (x) => { if (typeof x !== 'string' || !/^[0-9a-f-]{36}$/.test(x)) throw new Error('Identificador inválido'); return x; }),
};

/** Copia SOLO los campos del spec (protege contra asignación masiva). */
export function parse(body: unknown, spec: Spec): Record<string, any> {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) throw invalid('Cuerpo de la solicitud inválido');
  const out: Record<string, any> = {};
  const errors: Record<string, string> = {};
  for (const [k, rule] of Object.entries(spec)) {
    try { const r = rule((body as any)[k]); if (r !== undefined) out[k] = r; }
    catch (e) { errors[k] = (e as Error).message; }
  }
  if (Object.keys(errors).length) throw invalid('Revisa los campos marcados', errors);
  return out;
}
