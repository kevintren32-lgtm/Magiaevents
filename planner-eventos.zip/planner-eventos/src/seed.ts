import { Db, uid } from './lib/db.ts';
import { hashPassword, token } from './lib/crypto.ts';
import { PERMS } from './services.ts';
import { AUTOMATION_KINDS } from './api/automations.ts';

const CATEGORIES = ['Recintos y salones', 'Banquetes', 'Fotografía', 'Video', 'DJ y música', 'Iluminación y audio', 'Decoración y flores', 'Mobiliario', 'Pasteles y postres', 'Transporte', 'Personal de servicio'];

export const strongPassword = () => `Pw-${token(9).replace(/[^A-Za-z0-9]/g, 'a')}7`;

/** Crea la organización, configuración editable, integraciones (sin configurar) y automatizaciones. Sin datos de demostración. */
export async function bootstrapOrg(db: Db, o: { orgName: string; ownerEmail: string; ownerName: string; ownerPassword: string }) {
  const orgId = uid(), ownerId = uid();
  const hash = await hashPassword(o.ownerPassword);
  db.tx(() => {
    db.run('INSERT INTO organizations (id, name) VALUES (?,?)', orgId, o.orgName);
    db.run('INSERT INTO users (id, org_id, email, password_hash, display_name, role, permissions) VALUES (?,?,?,?,?,?,?)', ownerId, orgId, o.ownerEmail.toLowerCase(), hash, o.ownerName, 'owner', JSON.stringify(PERMS));
    const set = (k: string, val: unknown) => db.run('INSERT INTO organization_settings (org_id, key, value) VALUES (?,?,?)', orgId, k, JSON.stringify(val));
    set('brand', { name: o.orgName, tagline: '', color_bg: '#FAF6EE', color_ink: '#22201C', color_accent: '#8C6B3A', font_heading: "Iowan Old Style, Palatino Linotype, Georgia, serif", font_body: "Avenir Next, Segoe UI, system-ui, sans-serif" });
    set('locale', { language: 'es', currency: 'MXN', timezone: 'America/Mexico_City', date_format: 'DD/MM/YYYY' });
    set('tax', { default_bps: 1600, label: 'IVA' });
    set('legal', { privacy_notice: 'Texto de aviso de privacidad pendiente de redactar y revisar con asesoría legal.', terms: 'Términos de uso pendientes de redactar y revisar con asesoría legal.', version: '0' });
    set('privacy_visibility', { hide_vendor_names_from_clients: true });
    CATEGORIES.forEach((n, i) => db.run('INSERT INTO service_categories (id, org_id, name, sort) VALUES (?,?,?,?)', uid(), orgId, n, i));
    for (const k of ['email', 'payments', 'whatsapp', 'calendar', 'maps', 'ai']) db.run('INSERT INTO integrations (id, org_id, kind, status, notes) VALUES (?,?,?,?,?)', uid(), orgId, k, 'not_configured', 'Sin configurar: requiere credenciales del proveedor');
    for (const k of AUTOMATION_KINDS) db.run('INSERT INTO automation_rules (id, org_id, kind, enabled, params) VALUES (?,?,?,?,?)', uid(), orgId, k, 1, '{}');
    const tpl = (name: string, type: string, items: [string, number, string][]) => db.run('INSERT INTO task_templates (id, org_id, name, event_type, items) VALUES (?,?,?,?,?)', uid(), orgId, name, type, JSON.stringify(items.map(([title, offset_days, audience]) => ({ title, offset_days, audience }))));
    tpl('Boda: ruta estándar', 'boda', [['Definir presupuesto y lista preliminar de invitados', -300, 'client'], ['Visitar y elegir recinto', -270, 'client'], ['Contratar banquete y fotografía', -240, 'internal'], ['Prueba de menú', -90, 'client'], ['Enviar invitaciones', -75, 'client'], ['Confirmar proveedores', -30, 'internal'], ['Entregar lista final de invitados y mesas', -14, 'client'], ['Reunión de cronograma con proveedores', -7, 'internal'], ['Pago del saldo', -7, 'client']]);
    tpl('XV años: ruta estándar', 'xv', [['Definir temática y presupuesto', -240, 'client'], ['Elegir recinto', -210, 'client'], ['Contratar proveedores principales', -180, 'internal'], ['Prueba de menú', -60, 'client'], ['Enviar invitaciones', -60, 'client'], ['Confirmar proveedores', -21, 'internal'], ['Pago del saldo', -7, 'client']]);
    tpl('Cumpleaños: ruta estándar', 'cumpleaños', [['Definir número de invitados', -45, 'client'], ['Elegir servicios', -40, 'client'], ['Confirmar proveedores', -10, 'internal']]);
    tpl('Evento corporativo: ruta estándar', 'corporativo', [['Brief del evento', -90, 'client'], ['Cotización y aprobación', -75, 'internal'], ['Logística de proveedores', -30, 'internal'], ['Confirmación de asistentes', -14, 'client'], ['Cierre administrativo', 7, 'internal']]);
  });
  return { orgId, ownerId };
}

/** Datos ficticios (is_demo = 1). NO usar en producción. Devuelve credenciales generadas al azar. */
export async function seedDemo(db: Db, orgId: string, ownerId: string) {
  const creds: { role: string; email: string; password: string }[] = [];
  const mkUser = async (role: string, email: string, name: string, perms: string[] = []) => {
    const id = uid(), pw = strongPassword();
    db.run('INSERT INTO users (id, org_id, email, password_hash, display_name, role, permissions, is_demo) VALUES (?,?,?,?,?,?,?,1)', id, orgId, email, await hashPassword(pw), name, role, JSON.stringify(perms));
    creds.push({ role, email, password: pw }); return id;
  };
  const cat = (n: string) => db.get('SELECT id FROM service_categories WHERE org_id = ? AND name = ?', orgId, n)!.id;
  const staffId = await mkUser('staff', 'colaboradora@demo.invalid', 'Colaboradora Demo', ['events.write', 'logistics.manage', 'documents.manage', 'clients.manage']);
  const c1u = await mkUser('client', 'cliente1@demo.invalid', 'Cliente Demo Uno'), c2u = await mkUser('client', 'cliente2@demo.invalid', 'Cliente Demo Dos');
  const v1u = await mkUser('vendor', 'proveedor1@demo.invalid', 'Banquetes Demo'), v2u = await mkUser('vendor', 'proveedor2@demo.invalid', 'Audio Demo');
  const cl1 = uid(), cl2 = uid(), vn1 = uid(), vn2 = uid(), vn3 = uid();
  db.tx(() => {
    db.run('INSERT INTO clients (id, org_id, user_id, name, email, is_demo) VALUES (?,?,?,?,?,1)', cl1, orgId, c1u, 'Cliente Demo Uno', 'cliente1@demo.invalid');
    db.run('INSERT INTO clients (id, org_id, user_id, name, email, is_demo) VALUES (?,?,?,?,?,1)', cl2, orgId, c2u, 'Cliente Demo Dos', 'cliente2@demo.invalid');
    db.run(`INSERT INTO vendors (id, org_id, user_id, business_name, city, categories, status, setup_minutes, teardown_minutes, is_demo) VALUES (?,?,?,?,?,?,?,?,?,1)`, vn1, orgId, v1u, 'Banquetes Demo', 'Guadalajara', '["Banquetes"]', 'active', 90, 60);
    db.run(`INSERT INTO vendors (id, org_id, user_id, business_name, city, categories, status, setup_minutes, teardown_minutes, is_demo) VALUES (?,?,?,?,?,?,?,?,?,1)`, vn2, orgId, v2u, 'Audio Demo', 'Guadalajara', '["DJ y música"]', 'active', 60, 30);
    db.run(`INSERT INTO vendors (id, org_id, business_name, city, categories, status, is_demo) VALUES (?,?,?,?,?,?,1)`, vn3, orgId, 'Flores Demo', 'Zapopan', '["Decoración y flores"]', 'evaluating');
    const svc = (c: string, name: string, type: string, price: number, vendor: string | null) => { const id = uid(); db.run(`INSERT INTO service_catalog (id, org_id, category_id, name, description, price_type, base_price_cents, unit_label, vendor_id, internal_notes) VALUES (?,?,?,?,?,?,?,?,?,?)`, id, orgId, cat(c), name, 'Servicio de demostración', type, price, type === 'per_person' ? 'persona' : type === 'per_hour' ? 'hora' : null, vendor, 'Nota interna de demostración'); return id; };
    const sBanq = svc('Banquetes', 'Banquete de tres tiempos', 'per_person', 65000, vn1), sDj = svc('DJ y música', 'DJ y sonido (por hora)', 'per_hour', 120000, vn2);
    svc('Decoración y flores', 'Centros de mesa florales', 'per_unit', 85000, vn3); svc('Fotografía', 'Cobertura fotográfica de 8 horas', 'fixed', 1800000, null);
    const evId = uid();
    db.run(`INSERT INTO events (id, org_id, folio, name, type, status, event_date, start_time, end_time, city, guests_estimated, budget_target_cents, planner_id, is_demo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,1)`, evId, orgId, 'EV-DEMO-0001', 'Boda de demostración', 'boda', 'planning', '2027-03-20', '17:00', '23:30', 'Guadalajara', 120, 25000000, ownerId);
    db.run('INSERT INTO client_event_memberships (event_id, client_id, kind) VALUES (?,?,?)', evId, cl1, 'primary'); db.run('INSERT INTO event_staff (event_id, user_id) VALUES (?,?)', evId, staffId);
    const ev2 = uid();
    db.run(`INSERT INTO events (id, org_id, folio, name, type, status, event_date, city, guests_estimated, planner_id, is_demo) VALUES (?,?,?,?,?,?,?,?,?,?,1)`, ev2, orgId, 'EV-DEMO-0002', 'XV años de demostración', 'xv', 'initial_consult', '2027-05-08', 'Zapopan', 150, ownerId);
    db.run('INSERT INTO client_event_memberships (event_id, client_id, kind) VALUES (?,?,?)', ev2, cl2, 'primary');
    db.run('INSERT INTO service_requests (id, org_id, event_id, service_id, qty_milli, status, created_by) VALUES (?,?,?,?,?,?,?)', uid(), orgId, evId, sBanq, 120_000, 'in_review', c1u);
    db.run('INSERT INTO service_requests (id, org_id, event_id, service_id, qty_milli, status, created_by) VALUES (?,?,?,?,?,?,?)', uid(), orgId, evId, sDj, 6_000, 'in_review', c1u);
    db.run(`INSERT INTO tasks (id, org_id, event_id, title, audience, due_date, created_by) VALUES (?,?,?,?,?,?,?)`, uid(), orgId, evId, 'Enviar lista preliminar de invitados', 'client', '2027-01-15', ownerId);
  });
  return creds;
}
