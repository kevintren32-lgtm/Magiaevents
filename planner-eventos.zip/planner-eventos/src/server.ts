import http from 'node:http';
import { createApp } from './app.ts';
import { config } from './config.ts';
import { runAutomations } from './api/automations.ts';

const { db, handler } = createApp();
const server = http.createServer(handler);
server.listen(config.port, () => console.log(`Plataforma de eventos en http://localhost:${config.port} (${config.env})`));

// Automatizaciones: cada hora, con registro en automation_runs. En producción conviene un planificador externo.
(setInterval(() => {
  for (const o of db.all('SELECT id FROM organizations')) { try { runAutomations(db, o.id); } catch (e) { console.error('automations', e); } }
}, 3600_000) as any).unref();

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { server.close(); db.close(); process.exit(0); });
