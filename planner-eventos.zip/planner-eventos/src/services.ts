import { uid } from './lib/db.ts';
import type { Db, Row } from './lib/db.ts';
import { forbidden, notFound } from './lib/errors.ts';
import type { Ctx, User } from './http.ts';

export const PERMS = ['events.read_all', 'events.write', 'clients.manage', 'vendors.manage', 'catalog.manage', 'finance.view', 'finance.manage', 'logistics.manage', 'documents.manage', 'reports.view', 'users.manage', 'settings.manage', 'audit.view'] as const;

export const isStaff = (u: User) => u.role === 'owner' || u.role === 'staff';
export const hasPerm = (u: User, p: string) => u.role === 'owner' || (u.role === 'staff' && u.permissions.includes(p));
export function need(u: User, p: string) { if (!hasPerm(u, p)) throw forbidden(); }
export function needStaff(u: User) { if (!isStaff(u)) throw forbidden(); }

/** Devuelve el evento solo si el usuario puede verlo; si no, 404 (no revela existencia). */
export function getEvent(c: Ctx, id: string): Row {
  const u = c.user!;
  const e = c.db.get('SELECT * FROM events WHERE id = ? AND org_id = ?', id, u.org_id);
  if (!e) throw notFound('Evento');
  if (u.role === 'owner') return e;
  if (u.role === 'staff') {
    if (u.permissions.includes('events.read_all') || c.db.get('SELECT 1 x FROM event_staff WHERE event_id = ? AND user_id = ?', id, u.id)) return e;
    throw notFound('Evento');
  }
  if (u.role === 'client') {
    if (u.client_id && c.db.get('SELECT 1 x FROM client_event_memberships WHERE event_id = ? AND client_id = ?', id, u.client_id)) return e;
    throw notFound('Evento');
  }
  throw notFound('Evento');   // los proveedores nunca acceden a eventos; solo a asignaciones
}

export function clientEventView(e: Row) {
  const { notes_internal, planner_id, budget_approved_cents, ...rest } = e;
  void notes_internal; void planner_id;
  return { ...rest, budget_approved_cents };
}

export function audit(c: Pick<Ctx, 'db' | 'user' | 'ip'>, action: string, entity: string, entityId: string | null, before: unknown, after: unknown, reason?: string | null, result = 'ok', orgId?: string) {
  const strip = (o: unknown) => (o == null ? null : JSON.stringify(o, (k, v) => (/password|token|secret|hash/i.test(k) ? undefined : v)));
  c.db.run('INSERT INTO audit_logs (id, org_id, user_id, action, entity, entity_id, before_json, after_json, reason, result, ip) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
    uid(), orgId ?? c.user?.org_id ?? null, c.user?.id ?? null, action, entity, entityId, strip(before), strip(after), reason ?? null, result, c.ip);
}

const CRITICAL = new Set(['payment_overdue', 'assignment_rejected', 'incident', 'quote_sent', 'assignment_request', 'security']);
export function notify(db: Db, n: { orgId: string; userId: string; eventId?: string | null; type: string; title: string; body?: string; link?: string; priority?: 'normal' | 'high'; dedupe?: string }) {
  const u = db.get('SELECT prefs FROM users WHERE id = ? AND status = ?', n.userId, 'active');
  if (!u) return;
  const prefs = JSON.parse(u.prefs);
  if (!CRITICAL.has(n.type) && prefs.mute_noncritical) return;
  db.run('INSERT OR IGNORE INTO notifications (id, org_id, user_id, event_id, type, title, body, link, priority, dedupe_key) VALUES (?,?,?,?,?,?,?,?,?,?)',
    uid(), n.orgId, n.userId, n.eventId ?? null, n.type, n.title, n.body ?? null, n.link ?? null, n.priority ?? 'normal', n.dedupe ?? null);
}
export function notifyPlanners(db: Db, orgId: string, eventId: string | null, n: { type: string; title: string; body?: string; link?: string; priority?: 'normal' | 'high'; dedupe?: string }) {
  const users = db.all(`SELECT id, role, permissions FROM users WHERE org_id = ? AND status = 'active' AND role IN ('owner','staff')`, orgId);
  for (const u of users) {
    const ok = u.role === 'owner' || !eventId || JSON.parse(u.permissions).includes('events.read_all') || db.get('SELECT 1 x FROM event_staff WHERE event_id = ? AND user_id = ?', eventId, u.id);
    if (ok) notify(db, { orgId, userId: u.id, eventId, ...n, dedupe: n.dedupe ? `${n.dedupe}:${u.id}` : undefined });
  }
}
export function notifyClients(db: Db, orgId: string, eventId: string, n: { type: string; title: string; body?: string; link?: string; dedupe?: string }) {
  for (const r of db.all(`SELECT c.user_id FROM client_event_memberships m JOIN clients c ON c.id = m.client_id WHERE m.event_id = ? AND c.user_id IS NOT NULL`, eventId))
    notify(db, { orgId, userId: r.user_id, eventId, ...n, dedupe: n.dedupe ? `${n.dedupe}:${r.user_id}` : undefined });
}

export function nextFolio(db: Db, orgId: string, year: number): string {
  db.run('INSERT OR IGNORE INTO counters (org_id, name, value) VALUES (?, ?, 0)', orgId, `folio:${year}`);
  db.run('UPDATE counters SET value = value + 1 WHERE org_id = ? AND name = ?', orgId, `folio:${year}`);
  const v = db.get('SELECT value FROM counters WHERE org_id = ? AND name = ?', orgId, `folio:${year}`)!.value;
  return `EV-${year}-${String(v).padStart(4, '0')}`;
}

export function rateLimit(db: Db, key: string, max: number, windowSec: number): boolean {
  const now = Math.floor(Date.now() / 1000);
  const r = db.get('SELECT window_start, count FROM rate_limits WHERE key = ?', key);
  if (!r || now - r.window_start >= windowSec) { db.run('INSERT OR REPLACE INTO rate_limits (key, window_start, count) VALUES (?,?,1)', key, now); return true; }
  if (r.count >= max) return false;
  db.run('UPDATE rate_limits SET count = count + 1 WHERE key = ?', key);
  return true;
}
