-- 0001_schema.sql — GENERADO por scripts/gen-pg.ts desde migrations/sqlite. NO EDITAR A MANO: regenera con `npm run gen:pg`.
-- Estado: sin probar contra PostgreSQL.
create extension if not exists pgcrypto;

create table organizations (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

create table organization_settings (
  org_id uuid NOT NULL,
  key text NOT NULL,
  value jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (org_id, key)
);

create table counters (
  org_id uuid NOT NULL,
  name text NOT NULL,
  value jsonb NOT NULL DEFAULT 0::jsonb,
  PRIMARY KEY (org_id, name)
);

create table users (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  email text NOT NULL,
  password_hash text,
  display_name text NOT NULL,
  phone text,
  role text NOT NULL,
  permissions jsonb NOT NULL DEFAULT '[]'::jsonb,
  prefs jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'active',
  failed_attempts integer NOT NULL DEFAULT 0,
  locked_until timestamptz,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (role IN ('owner','staff','client','vendor')),
  CHECK (status IN ('invited','active','disabled'))
);

create table sessions (
  id text NOT NULL,
  user_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  user_agent text,
  PRIMARY KEY (id)
);

create table password_resets (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

create table clients (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  user_id uuid UNIQUE,
  name text NOT NULL,
  email text,
  phone text,
  internal_notes text,
  archived_at timestamptz,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

create table vendors (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  user_id uuid UNIQUE,
  business_name text NOT NULL,
  legal_name text,
  contact_name text,
  phone text,
  email text,
  address text,
  city text,
  categories jsonb NOT NULL DEFAULT '[]'::jsonb,
  description text,
  capacity_note text,
  coverage text,
  setup_minutes integer NOT NULL DEFAULT 0,
  teardown_minutes integer NOT NULL DEFAULT 0,
  tech_requirements text,
  payment_terms text,
  cancellation_policy text,
  tax_data text,
  status text NOT NULL DEFAULT 'prospect',
  internal_notes text,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (status IN ('prospect','evaluating','docs_pending','approved','active','suspended','inactive','temporarily_unavailable'))
);

create table invitations (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  email text NOT NULL,
  role text NOT NULL,
  display_name text,
  permissions jsonb NOT NULL DEFAULT '[]'::jsonb,
  client_id uuid,
  vendor_id uuid,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  accepted_at timestamptz,
  revoked_at timestamptz,
  invited_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (role IN ('staff','client','vendor'))
);

create table email_outbox (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid,
  to_email text NOT NULL,
  template text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  status text NOT NULL DEFAULT 'queued_not_sent',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (status IN ('queued_not_sent','sent','failed'))
);

create table rate_limits (
  key text NOT NULL,
  window_start integer NOT NULL,
  count integer NOT NULL,
  PRIMARY KEY (key)
);

create table events (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  folio text NOT NULL,
  name text NOT NULL,
  type text NOT NULL,
  status text NOT NULL DEFAULT 'prospect',
  event_date date,
  start_time time,
  end_time time,
  timezone text NOT NULL DEFAULT 'America/Mexico_City',
  venue_name text,
  address text,
  city text,
  latitude double precision,
  longitude double precision,
  guests_estimated integer,
  guests_confirmed integer NOT NULL DEFAULT 0,
  budget_target_cents bigint,
  budget_approved_cents bigint,
  currency text NOT NULL DEFAULT 'MXN',
  planner_id uuid,
  notes_internal text,
  notes_client text,
  brief jsonb NOT NULL DEFAULT '{}'::jsonb,
  brief_step integer NOT NULL DEFAULT 0,
  brief_submitted_at timestamptz,
  cancel_reason text,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  PRIMARY KEY (id),
  UNIQUE (org_id, folio),
  CHECK (status IN ('prospect','initial_consult','preparing','proposal_drafting','proposal_sent','pending_approval','contracted','planning','confirmed','in_execution','finished','closed','cancelled','archived'))
);

create table event_staff (
  event_id uuid NOT NULL,
  user_id uuid NOT NULL,
  role text NOT NULL DEFAULT 'coordinator',
  PRIMARY KEY (event_id, user_id)
);

create table client_event_memberships (
  event_id uuid NOT NULL,
  client_id uuid NOT NULL,
  kind text NOT NULL DEFAULT 'primary',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (event_id, client_id),
  CHECK (kind IN ('primary','participant'))
);

create table service_categories (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  name text NOT NULL,
  sort integer NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE (org_id, name)
);

create table service_catalog (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  category_id uuid NOT NULL,
  name text NOT NULL,
  description text,
  price_type text NOT NULL DEFAULT 'fixed',
  base_price_cents bigint,
  unit_label text,
  min_qty_milli integer NOT NULL DEFAULT 1000,
  max_qty_milli integer,
  tax_bps integer NOT NULL DEFAULT 1600,
  advance_bps integer NOT NULL DEFAULT 5000,
  visible_to_client boolean NOT NULL DEFAULT true,
  active boolean NOT NULL DEFAULT true,
  vendor_id uuid,
  internal_notes text,
  price_version integer NOT NULL DEFAULT 1,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (price_type IN ('fixed','per_person','per_hour','per_day','per_unit','per_meter','per_package','custom','quote'))
);

create table service_packages (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  service_id uuid NOT NULL,
  name text NOT NULL,
  description text,
  price_cents bigint NOT NULL,
  active boolean NOT NULL DEFAULT true,
  PRIMARY KEY (id)
);

create table service_requests (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL,
  service_id uuid NOT NULL,
  package_id uuid,
  qty_milli integer NOT NULL DEFAULT 1000,
  status text NOT NULL DEFAULT 'draft',
  client_notes text,
  planner_notes text,
  unit_price_cents bigint,
  discount_cents bigint NOT NULL DEFAULT 0,
  tax_bps integer,
  price_version integer NOT NULL DEFAULT 0,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  planner_message text,
  PRIMARY KEY (id),
  CHECK (status IN ('draft','requested','in_review','info_required','quote_preparing','quote_sent','client_approved','pending_vendor','confirmed','contracted','rejected','cancelled','completed'))
);

create table quotes (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL UNIQUE,
  current_version integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

create table quote_versions (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  quote_id uuid NOT NULL,
  version integer NOT NULL,
  status text NOT NULL DEFAULT 'sent',
  subtotal_cents bigint NOT NULL,
  discount_cents bigint NOT NULL,
  charges_cents bigint NOT NULL DEFAULT 0,
  charges_note text,
  tax_cents bigint NOT NULL,
  total_cents bigint NOT NULL,
  advance_cents bigint NOT NULL,
  note text,
  sent_at timestamptz,
  accepted_at timestamptz,
  accepted_by text,
  rejected_reason text,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  UNIQUE (quote_id, version),
  CHECK (status IN ('draft','sent','accepted','rejected','superseded'))
);

create table quote_items (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  version_id uuid NOT NULL,
  request_id uuid,
  description text NOT NULL,
  qty_milli integer NOT NULL,
  unit_price_cents bigint NOT NULL,
  discount_cents bigint NOT NULL DEFAULT 0,
  tax_bps integer NOT NULL,
  line_gross_cents bigint NOT NULL,
  line_tax_cents bigint NOT NULL,
  line_total_cents bigint NOT NULL,
  PRIMARY KEY (id)
);

create table service_assignments (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL,
  request_id uuid,
  vendor_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'requested',
  public_title text NOT NULL,
  service_description text,
  qty_milli integer NOT NULL DEFAULT 1000,
  cost_cents bigint NOT NULL DEFAULT 0,
  actual_cost_cents bigint,
  service_date date NOT NULL,
  arrival_time time,
  setup_time time,
  start_time time,
  end_time time,
  teardown_time time,
  location_visible boolean NOT NULL DEFAULT false,
  location_detail text,
  instructions text,
  requirements text,
  staff_needed integer,
  reject_reason text,
  arrived_at timestamptz,
  started_at timestamptz,
  finished_at timestamptz,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (status IN ('requested','accepted','rejected','confirmed','completed','cancelled'))
);

create table assignment_checklist (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  assignment_id uuid NOT NULL,
  phase text NOT NULL,
  text text NOT NULL,
  done boolean NOT NULL DEFAULT false,
  done_at timestamptz,
  PRIMARY KEY (id),
  CHECK (phase IN ('prep','exec','teardown'))
);

create table vendor_availability (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  vendor_id uuid NOT NULL,
  date date NOT NULL,
  status text NOT NULL,
  capacity integer NOT NULL DEFAULT 1,
  note text,
  PRIMARY KEY (id),
  UNIQUE (vendor_id, date),
  CHECK (status IN ('available','unavailable'))
);

create table vendor_blackouts (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  vendor_id uuid NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  reason text,
  PRIMARY KEY (id)
);

create table vendor_evaluations (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  vendor_id uuid NOT NULL,
  event_id uuid,
  punctuality integer,
  quality integer,
  compliance integer,
  professionalism integer,
  notes text,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (punctuality BETWEEN 1 AND 5),
  CHECK (quality BETWEEN 1 AND 5),
  CHECK (compliance BETWEEN 1 AND 5),
  CHECK (professionalism BETWEEN 1 AND 5)
);

create table payments (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL,
  direction text NOT NULL,
  client_id uuid,
  vendor_id uuid,
  concept text,
  amount_cents bigint NOT NULL,
  paid_cents bigint NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'MXN',
  due_date date,
  paid_date date,
  method text,
  reference text,
  status text NOT NULL DEFAULT 'pending',
  source text NOT NULL DEFAULT 'manual',
  verified boolean NOT NULL DEFAULT false,
  idempotency_key text,
  receipt_document_id uuid,
  recorded_by text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (direction IN ('in','out')),
  CHECK (amount_cents > 0),
  CHECK (status IN ('pending','scheduled','in_review','paid','partially_paid','overdue','refunded','cancelled')),
  CHECK (source IN ('manual','gateway')),
  CHECK (paid_cents >= 0 AND paid_cents <= amount_cents),
  CHECK ((direction = 'in' AND client_id IS NOT NULL) OR (direction = 'out' AND vendor_id IS NOT NULL))
);

create table payment_transactions (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  payment_id uuid,
  provider text NOT NULL,
  external_id text NOT NULL,
  amount_cents bigint NOT NULL,
  status text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  UNIQUE (provider, external_id)
);

create table webhook_events (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  external_id text NOT NULL,
  event_type text,
  signature_valid boolean NOT NULL,
  payload_sha256 text NOT NULL,
  status text NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  UNIQUE (provider, external_id),
  CHECK (status IN ('processed','ignored','rejected'))
);

create table expenses (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL,
  vendor_id uuid,
  category text,
  description text NOT NULL,
  amount_cents bigint NOT NULL,
  expense_date date NOT NULL,
  recorded_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (amount_cents > 0)
);

create table financial_adjustments (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL,
  kind text NOT NULL,
  amount_cents bigint NOT NULL,
  reason text NOT NULL,
  related_payment_id uuid,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (kind IN ('client_credit','client_charge','refund','vendor_adjustment','correction'))
);

create table tables_seating (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL,
  name text NOT NULL,
  capacity integer NOT NULL,
  pos_x integer,
  pos_y integer,
  PRIMARY KEY (id),
  UNIQUE (event_id, name),
  CHECK (capacity > 0)
);

create table guests (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL,
  name text NOT NULL,
  email text,
  phone text,
  group_name text,
  status text NOT NULL DEFAULT 'pending',
  companions integer NOT NULL DEFAULT 0,
  dietary text,
  accessibility text,
  notes text,
  table_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (status IN ('pending','invited','confirmed','declined','no_response','waitlist','attended','no_show'))
);

create table tasks (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL,
  assignment_id uuid,
  title text NOT NULL,
  description text,
  assignee_user_id uuid,
  audience text NOT NULL DEFAULT 'internal',
  due_date date,
  priority text NOT NULL DEFAULT 'normal',
  status text NOT NULL DEFAULT 'pending',
  completed_at timestamptz,
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (audience IN ('internal','client','vendor')),
  CHECK (priority IN ('low','normal','high','urgent')),
  CHECK (status IN ('pending','in_progress','blocked','completed','cancelled'))
);

create table task_dependencies (
  task_id uuid NOT NULL,
  depends_on_id uuid NOT NULL,
  PRIMARY KEY (task_id, depends_on_id),
  CHECK (task_id <> depends_on_id)
);

create table task_templates (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  name text NOT NULL,
  event_type text NOT NULL,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_demo boolean NOT NULL DEFAULT false,
  PRIMARY KEY (id),
  UNIQUE (org_id, name)
);

create table timeline_items (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL,
  assignment_id uuid,
  vendor_id uuid,
  item_date date NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  title text NOT NULL,
  location text,
  instructions text,
  status text NOT NULL DEFAULT 'pending',
  priority text NOT NULL DEFAULT 'normal',
  locked boolean NOT NULL DEFAULT false,
  show_to_client boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (status IN ('pending','in_progress','done','blocked','cancelled')),
  CHECK (priority IN ('low','normal','high','urgent'))
);

create table timeline_dependencies (
  item_id uuid NOT NULL,
  depends_on_id uuid NOT NULL,
  PRIMARY KEY (item_id, depends_on_id),
  CHECK (item_id <> depends_on_id)
);

create table documents (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid,
  vendor_id uuid,
  kind text NOT NULL DEFAULT 'other',
  name text NOT NULL,
  storage_key text NOT NULL UNIQUE,
  mime text NOT NULL,
  size_bytes integer NOT NULL,
  sha256 text NOT NULL,
  version integer NOT NULL DEFAULT 1,
  supersedes_id uuid,
  status text NOT NULL DEFAULT 'active',
  visibility text NOT NULL DEFAULT 'internal',
  expires_on date,
  uploaded_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (status IN ('active','archived')),
  CHECK (visibility IN ('internal','client','vendor'))
);

create table document_permissions (
  document_id uuid NOT NULL,
  vendor_id uuid NOT NULL,
  PRIMARY KEY (document_id, vendor_id)
);

create table conversations (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid,
  kind text NOT NULL,
  participant_user_id uuid NOT NULL,
  subject text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (kind IN ('client','vendor'))
);

create table messages (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL,
  author_id uuid NOT NULL,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

create table message_attachments (
  message_id uuid NOT NULL,
  document_id uuid NOT NULL,
  PRIMARY KEY (message_id, document_id)
);

create table notifications (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  user_id uuid NOT NULL,
  event_id uuid,
  type text NOT NULL,
  title text NOT NULL,
  body text,
  link text,
  priority text NOT NULL DEFAULT 'normal',
  dedupe_key text,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (priority IN ('normal','high'))
);

create table incidents (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL,
  assignment_id uuid,
  vendor_id uuid,
  reported_by text NOT NULL,
  severity text NOT NULL DEFAULT 'medium',
  description text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  resolution text,
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  PRIMARY KEY (id),
  CHECK (severity IN ('low','medium','high','critical')),
  CHECK (status IN ('open','in_progress','resolved'))
);

create table change_requests (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  event_id uuid NOT NULL,
  requested_by text NOT NULL,
  target_type text NOT NULL,
  target_id uuid,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  reason text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  decided_by text,
  decided_at timestamptz,
  decision_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (target_type IN ('timeline_item','assignment','event','service_request','other')),
  CHECK (status IN ('pending','approved','rejected'))
);

create table audit_logs (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid,
  user_id uuid,
  action text NOT NULL,
  entity text NOT NULL,
  entity_id text,
  before_json jsonb,
  after_json jsonb,
  reason text,
  result text NOT NULL DEFAULT 'ok',
  ip text,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

create table integrations (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  kind text NOT NULL,
  status text NOT NULL DEFAULT 'not_configured',
  notes text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  UNIQUE (org_id, kind),
  CHECK (kind IN ('email','payments','whatsapp','calendar','maps','ai')),
  CHECK (status IN ('not_configured','configured'))
);

create table automation_rules (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  kind text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  params jsonb NOT NULL DEFAULT '{}'::jsonb,
  PRIMARY KEY (id),
  UNIQUE (org_id, kind),
  CHECK (kind IN ('payment_reminders','document_expiry','pending_guest_confirmations','overdue_tasks','services_without_vendor','vendors_unconfirmed','upcoming_events','mark_overdue_payments'))
);

create table automation_runs (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  rule_id uuid NOT NULL,
  started_at timestamptz NOT NULL,
  finished_at timestamptz,
  status text NOT NULL,
  created_count integer NOT NULL DEFAULT 0,
  error text,
  PRIMARY KEY (id),
  CHECK (status IN ('ok','error'))
);

create table consents (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  kind text NOT NULL,
  version text NOT NULL,
  accepted_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

create table data_requests (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  user_id uuid NOT NULL,
  kind text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id),
  CHECK (kind IN ('access','rectification','deletion')),
  CHECK (status IN ('open','in_progress','done','rejected'))
);

CREATE INDEX idx_users_org ON users(org_id);
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_clients_org ON clients(org_id);
CREATE INDEX idx_vendors_org ON vendors(org_id);
CREATE INDEX idx_invitations_org ON invitations(org_id);
CREATE INDEX idx_events_org_date ON events(org_id, event_date);
CREATE INDEX idx_events_status ON events(org_id, status);
CREATE INDEX idx_cem_client ON client_event_memberships(client_id);
CREATE INDEX idx_catalog_org ON service_catalog(org_id, category_id);
CREATE INDEX idx_requests_event ON service_requests(event_id);
CREATE INDEX idx_quote_items_version ON quote_items(version_id);
CREATE INDEX idx_assign_vendor ON service_assignments(vendor_id, service_date);
CREATE INDEX idx_assign_event ON service_assignments(event_id);
CREATE UNIQUE INDEX uq_payments_idem ON payments(org_id, idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE INDEX idx_payments_event ON payments(event_id);
CREATE INDEX idx_guests_event ON guests(event_id);
CREATE INDEX idx_tasks_event ON tasks(event_id);
CREATE INDEX idx_tasks_assignee ON tasks(assignee_user_id, status);
CREATE INDEX idx_timeline_event ON timeline_items(event_id, item_date, start_time);
CREATE INDEX idx_documents_event ON documents(event_id);
CREATE INDEX idx_conv_participant ON conversations(participant_user_id);
CREATE INDEX idx_messages_conv ON messages(conversation_id, created_at);
CREATE UNIQUE INDEX uq_notif_dedupe ON notifications(user_id, dedupe_key) WHERE dedupe_key IS NOT NULL;
CREATE INDEX idx_notif_user ON notifications(user_id, read_at, created_at);
CREATE INDEX idx_audit_org ON audit_logs(org_id, created_at);
CREATE INDEX idx_audit_entity ON audit_logs(entity, entity_id);

-- Claves foráneas
alter table organization_settings add constraint fk_organization_settings_org_id foreign key (org_id) references organizations(id) on delete cascade;
alter table counters add constraint fk_counters_org_id foreign key (org_id) references organizations(id) on delete cascade;
alter table users add constraint fk_users_org_id foreign key (org_id) references organizations(id);
alter table sessions add constraint fk_sessions_user_id foreign key (user_id) references users(id) on delete cascade;
alter table password_resets add constraint fk_password_resets_user_id foreign key (user_id) references users(id) on delete cascade;
alter table clients add constraint fk_clients_user_id foreign key (user_id) references users(id);
alter table clients add constraint fk_clients_org_id foreign key (org_id) references organizations(id);
alter table vendors add constraint fk_vendors_user_id foreign key (user_id) references users(id);
alter table vendors add constraint fk_vendors_org_id foreign key (org_id) references organizations(id);
alter table invitations add constraint fk_invitations_invited_by foreign key (invited_by) references users(id);
alter table invitations add constraint fk_invitations_vendor_id foreign key (vendor_id) references vendors(id);
alter table invitations add constraint fk_invitations_client_id foreign key (client_id) references clients(id);
alter table invitations add constraint fk_invitations_org_id foreign key (org_id) references organizations(id);
alter table email_outbox add constraint fk_email_outbox_org_id foreign key (org_id) references organizations(id);
alter table events add constraint fk_events_planner_id foreign key (planner_id) references users(id);
alter table events add constraint fk_events_org_id foreign key (org_id) references organizations(id);
alter table event_staff add constraint fk_event_staff_user_id foreign key (user_id) references users(id);
alter table event_staff add constraint fk_event_staff_event_id foreign key (event_id) references events(id) on delete cascade;
alter table client_event_memberships add constraint fk_client_event_memberships_client_id foreign key (client_id) references clients(id);
alter table client_event_memberships add constraint fk_client_event_memberships_event_id foreign key (event_id) references events(id) on delete cascade;
alter table service_categories add constraint fk_service_categories_org_id foreign key (org_id) references organizations(id);
alter table service_catalog add constraint fk_service_catalog_vendor_id foreign key (vendor_id) references vendors(id);
alter table service_catalog add constraint fk_service_catalog_category_id foreign key (category_id) references service_categories(id);
alter table service_catalog add constraint fk_service_catalog_org_id foreign key (org_id) references organizations(id);
alter table service_packages add constraint fk_service_packages_service_id foreign key (service_id) references service_catalog(id) on delete cascade;
alter table service_requests add constraint fk_service_requests_created_by foreign key (created_by) references users(id);
alter table service_requests add constraint fk_service_requests_package_id foreign key (package_id) references service_packages(id);
alter table service_requests add constraint fk_service_requests_service_id foreign key (service_id) references service_catalog(id);
alter table service_requests add constraint fk_service_requests_event_id foreign key (event_id) references events(id) on delete cascade;
alter table service_requests add constraint fk_service_requests_org_id foreign key (org_id) references organizations(id);
alter table quotes add constraint fk_quotes_event_id foreign key (event_id) references events(id) on delete cascade;
alter table quotes add constraint fk_quotes_org_id foreign key (org_id) references organizations(id);
alter table quote_versions add constraint fk_quote_versions_created_by foreign key (created_by) references users(id);
alter table quote_versions add constraint fk_quote_versions_accepted_by foreign key (accepted_by) references users(id);
alter table quote_versions add constraint fk_quote_versions_quote_id foreign key (quote_id) references quotes(id) on delete cascade;
alter table quote_items add constraint fk_quote_items_request_id foreign key (request_id) references service_requests(id);
alter table quote_items add constraint fk_quote_items_version_id foreign key (version_id) references quote_versions(id) on delete cascade;
alter table service_assignments add constraint fk_service_assignments_created_by foreign key (created_by) references users(id);
alter table service_assignments add constraint fk_service_assignments_vendor_id foreign key (vendor_id) references vendors(id);
alter table service_assignments add constraint fk_service_assignments_request_id foreign key (request_id) references service_requests(id);
alter table service_assignments add constraint fk_service_assignments_event_id foreign key (event_id) references events(id) on delete cascade;
alter table service_assignments add constraint fk_service_assignments_org_id foreign key (org_id) references organizations(id);
alter table assignment_checklist add constraint fk_assignment_checklist_assignment_id foreign key (assignment_id) references service_assignments(id) on delete cascade;
alter table vendor_availability add constraint fk_vendor_availability_vendor_id foreign key (vendor_id) references vendors(id) on delete cascade;
alter table vendor_blackouts add constraint fk_vendor_blackouts_vendor_id foreign key (vendor_id) references vendors(id) on delete cascade;
alter table vendor_evaluations add constraint fk_vendor_evaluations_created_by foreign key (created_by) references users(id);
alter table vendor_evaluations add constraint fk_vendor_evaluations_event_id foreign key (event_id) references events(id);
alter table vendor_evaluations add constraint fk_vendor_evaluations_vendor_id foreign key (vendor_id) references vendors(id) on delete cascade;
alter table vendor_evaluations add constraint fk_vendor_evaluations_org_id foreign key (org_id) references organizations(id);
alter table payments add constraint fk_payments_recorded_by foreign key (recorded_by) references users(id);
alter table payments add constraint fk_payments_vendor_id foreign key (vendor_id) references vendors(id);
alter table payments add constraint fk_payments_client_id foreign key (client_id) references clients(id);
alter table payments add constraint fk_payments_event_id foreign key (event_id) references events(id);
alter table payments add constraint fk_payments_org_id foreign key (org_id) references organizations(id);
alter table payment_transactions add constraint fk_payment_transactions_payment_id foreign key (payment_id) references payments(id);
alter table payment_transactions add constraint fk_payment_transactions_org_id foreign key (org_id) references organizations(id);
alter table expenses add constraint fk_expenses_recorded_by foreign key (recorded_by) references users(id);
alter table expenses add constraint fk_expenses_vendor_id foreign key (vendor_id) references vendors(id);
alter table expenses add constraint fk_expenses_event_id foreign key (event_id) references events(id);
alter table expenses add constraint fk_expenses_org_id foreign key (org_id) references organizations(id);
alter table financial_adjustments add constraint fk_financial_adjustments_created_by foreign key (created_by) references users(id);
alter table financial_adjustments add constraint fk_financial_adjustments_related_payment_id foreign key (related_payment_id) references payments(id);
alter table financial_adjustments add constraint fk_financial_adjustments_event_id foreign key (event_id) references events(id);
alter table financial_adjustments add constraint fk_financial_adjustments_org_id foreign key (org_id) references organizations(id);
alter table tables_seating add constraint fk_tables_seating_event_id foreign key (event_id) references events(id) on delete cascade;
alter table guests add constraint fk_guests_table_id foreign key (table_id) references tables_seating(id) on delete set null;
alter table guests add constraint fk_guests_event_id foreign key (event_id) references events(id) on delete cascade;
alter table guests add constraint fk_guests_org_id foreign key (org_id) references organizations(id);
alter table tasks add constraint fk_tasks_created_by foreign key (created_by) references users(id);
alter table tasks add constraint fk_tasks_assignee_user_id foreign key (assignee_user_id) references users(id);
alter table tasks add constraint fk_tasks_assignment_id foreign key (assignment_id) references service_assignments(id) on delete cascade;
alter table tasks add constraint fk_tasks_event_id foreign key (event_id) references events(id) on delete cascade;
alter table tasks add constraint fk_tasks_org_id foreign key (org_id) references organizations(id);
alter table task_dependencies add constraint fk_task_dependencies_depends_on_id foreign key (depends_on_id) references tasks(id) on delete cascade;
alter table task_dependencies add constraint fk_task_dependencies_task_id foreign key (task_id) references tasks(id) on delete cascade;
alter table task_templates add constraint fk_task_templates_org_id foreign key (org_id) references organizations(id);
alter table timeline_items add constraint fk_timeline_items_vendor_id foreign key (vendor_id) references vendors(id);
alter table timeline_items add constraint fk_timeline_items_assignment_id foreign key (assignment_id) references service_assignments(id) on delete set null;
alter table timeline_items add constraint fk_timeline_items_event_id foreign key (event_id) references events(id) on delete cascade;
alter table timeline_items add constraint fk_timeline_items_org_id foreign key (org_id) references organizations(id);
alter table timeline_dependencies add constraint fk_timeline_dependencies_depends_on_id foreign key (depends_on_id) references timeline_items(id) on delete cascade;
alter table timeline_dependencies add constraint fk_timeline_dependencies_item_id foreign key (item_id) references timeline_items(id) on delete cascade;
alter table documents add constraint fk_documents_uploaded_by foreign key (uploaded_by) references users(id);
alter table documents add constraint fk_documents_supersedes_id foreign key (supersedes_id) references documents(id);
alter table documents add constraint fk_documents_vendor_id foreign key (vendor_id) references vendors(id);
alter table documents add constraint fk_documents_event_id foreign key (event_id) references events(id);
alter table documents add constraint fk_documents_org_id foreign key (org_id) references organizations(id);
alter table document_permissions add constraint fk_document_permissions_vendor_id foreign key (vendor_id) references vendors(id);
alter table document_permissions add constraint fk_document_permissions_document_id foreign key (document_id) references documents(id) on delete cascade;
alter table conversations add constraint fk_conversations_participant_user_id foreign key (participant_user_id) references users(id);
alter table conversations add constraint fk_conversations_event_id foreign key (event_id) references events(id);
alter table conversations add constraint fk_conversations_org_id foreign key (org_id) references organizations(id);
alter table messages add constraint fk_messages_author_id foreign key (author_id) references users(id);
alter table messages add constraint fk_messages_conversation_id foreign key (conversation_id) references conversations(id) on delete cascade;
alter table message_attachments add constraint fk_message_attachments_document_id foreign key (document_id) references documents(id);
alter table message_attachments add constraint fk_message_attachments_message_id foreign key (message_id) references messages(id) on delete cascade;
alter table notifications add constraint fk_notifications_event_id foreign key (event_id) references events(id);
alter table notifications add constraint fk_notifications_user_id foreign key (user_id) references users(id) on delete cascade;
alter table notifications add constraint fk_notifications_org_id foreign key (org_id) references organizations(id);
alter table incidents add constraint fk_incidents_reported_by foreign key (reported_by) references users(id);
alter table incidents add constraint fk_incidents_vendor_id foreign key (vendor_id) references vendors(id);
alter table incidents add constraint fk_incidents_assignment_id foreign key (assignment_id) references service_assignments(id);
alter table incidents add constraint fk_incidents_event_id foreign key (event_id) references events(id);
alter table incidents add constraint fk_incidents_org_id foreign key (org_id) references organizations(id);
alter table change_requests add constraint fk_change_requests_decided_by foreign key (decided_by) references users(id);
alter table change_requests add constraint fk_change_requests_requested_by foreign key (requested_by) references users(id);
alter table change_requests add constraint fk_change_requests_event_id foreign key (event_id) references events(id);
alter table change_requests add constraint fk_change_requests_org_id foreign key (org_id) references organizations(id);
alter table audit_logs add constraint fk_audit_logs_user_id foreign key (user_id) references users(id);
alter table audit_logs add constraint fk_audit_logs_org_id foreign key (org_id) references organizations(id);
alter table integrations add constraint fk_integrations_org_id foreign key (org_id) references organizations(id);
alter table automation_rules add constraint fk_automation_rules_org_id foreign key (org_id) references organizations(id);
alter table automation_runs add constraint fk_automation_runs_rule_id foreign key (rule_id) references automation_rules(id) on delete cascade;
alter table automation_runs add constraint fk_automation_runs_org_id foreign key (org_id) references organizations(id);
alter table consents add constraint fk_consents_user_id foreign key (user_id) references users(id) on delete cascade;
alter table data_requests add constraint fk_data_requests_user_id foreign key (user_id) references users(id);
alter table data_requests add constraint fk_data_requests_org_id foreign key (org_id) references organizations(id);

-- Unicidad de correo sin distinguir mayúsculas
create unique index uq_users_email_lower on users (lower(email));
create unique index uq_invitations_email_lower on invitations (lower(email));

-- Tablas de solo anexado
create function app_forbid_mutation() returns trigger language plpgsql as $$ begin raise exception '% es de solo anexado: registra un movimiento compensatorio', tg_table_name; end $$;
create trigger audit_logs_append_only before update or delete on audit_logs for each row execute function app_forbid_mutation();
create trigger financial_adjustments_append_only before update or delete on financial_adjustments for each row execute function app_forbid_mutation();
