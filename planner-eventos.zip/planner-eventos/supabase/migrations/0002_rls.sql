-- 0002_rls.sql — GENERADO por scripts/gen-rls.ts. NO EDITAR A MANO. SIN PROBAR contra PostgreSQL.
-- Modelo: (1) RLS activo en TODAS las tablas; (2) sin políticas de escritura: toda escritura la hace el servidor
-- con la clave service_role, que valida reglas de negocio; (3) el personal lee tablas base según permisos;
-- (4) clientes y proveedores leen SOLO mediante vistas de portal con columnas autorizadas.

create schema if not exists app;
alter table users add constraint users_auth_fk foreign key (id) references auth.users(id) on delete cascade;

create or replace function app.me_org() returns uuid language sql stable security definer set search_path = public, pg_temp
as $$ select org_id from users where id = auth.uid() and status = 'active' $$;
create or replace function app.me_role() returns text language sql stable security definer set search_path = public, pg_temp
as $$ select role from users where id = auth.uid() and status = 'active' $$;
create or replace function app.is_staff() returns boolean language sql stable security definer set search_path = public, pg_temp
as $$ select coalesce(app.me_role() in ('owner','staff'), false) $$;
create or replace function app.has_perm(p text) returns boolean language sql stable security definer set search_path = public, pg_temp
as $$ select exists (select 1 from users where id = auth.uid() and status = 'active' and (role = 'owner' or (role = 'staff' and permissions ? p))) $$;
create or replace function app.me_client() returns uuid language sql stable security definer set search_path = public, pg_temp
as $$ select c.id from clients c join users u on u.id = c.user_id where u.id = auth.uid() and u.status = 'active' $$;
create or replace function app.me_vendor() returns uuid language sql stable security definer set search_path = public, pg_temp
as $$ select v.id from vendors v join users u on u.id = v.user_id where u.id = auth.uid() and u.status = 'active' $$;
create or replace function app.can_event(e uuid) returns boolean language sql stable security definer set search_path = public, pg_temp
as $$ select exists (
  select 1 from events ev join users u on u.id = auth.uid() and u.status = 'active' and u.org_id = ev.org_id
  where ev.id = e and (
    u.role = 'owner'
    or (u.role = 'staff' and (u.permissions ? 'events.read_all' or exists (select 1 from event_staff s where s.event_id = ev.id and s.user_id = u.id)))
    or (u.role = 'client' and exists (select 1 from client_event_memberships m join clients c on c.id = m.client_id where m.event_id = ev.id and c.user_id = u.id))
  )) $$;
revoke all on function app.me_org(), app.me_role(), app.is_staff(), app.has_perm(text), app.me_client(), app.me_vendor(), app.can_event(uuid) from public, anon;
grant execute on function app.me_org(), app.me_role(), app.is_staff(), app.has_perm(text), app.me_client(), app.me_vendor(), app.can_event(uuid) to authenticated;
grant usage on schema app to authenticated;

-- Base: nada por defecto

alter table organizations enable row level security;
alter table organization_settings enable row level security;
alter table counters enable row level security;
alter table users enable row level security;
alter table sessions enable row level security;
alter table password_resets enable row level security;
alter table clients enable row level security;
alter table vendors enable row level security;
alter table invitations enable row level security;
alter table email_outbox enable row level security;
alter table rate_limits enable row level security;
alter table events enable row level security;
alter table event_staff enable row level security;
alter table client_event_memberships enable row level security;
alter table service_categories enable row level security;
alter table service_catalog enable row level security;
alter table service_packages enable row level security;
alter table service_requests enable row level security;
alter table quotes enable row level security;
alter table quote_versions enable row level security;
alter table quote_items enable row level security;
alter table service_assignments enable row level security;
alter table assignment_checklist enable row level security;
alter table vendor_availability enable row level security;
alter table vendor_blackouts enable row level security;
alter table vendor_evaluations enable row level security;
alter table payments enable row level security;
alter table payment_transactions enable row level security;
alter table webhook_events enable row level security;
alter table expenses enable row level security;
alter table financial_adjustments enable row level security;
alter table tables_seating enable row level security;
alter table guests enable row level security;
alter table tasks enable row level security;
alter table task_dependencies enable row level security;
alter table task_templates enable row level security;
alter table timeline_items enable row level security;
alter table timeline_dependencies enable row level security;
alter table documents enable row level security;
alter table document_permissions enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table message_attachments enable row level security;
alter table notifications enable row level security;
alter table incidents enable row level security;
alter table change_requests enable row level security;
alter table audit_logs enable row level security;
alter table integrations enable row level security;
alter table automation_rules enable row level security;
alter table automation_runs enable row level security;
alter table consents enable row level security;
alter table data_requests enable row level security;
revoke all on all tables in schema public from anon, authenticated;

grant select on organizations to authenticated;
create policy organizations_select on organizations for select to authenticated using ((id = app.me_org()));
grant select on organization_settings to authenticated;
create policy organization_settings_select on organization_settings for select to authenticated using (app.is_staff() and (org_id = app.me_org()) and app.has_perm('settings.manage'));
grant select (id, org_id, email, display_name, phone, role, permissions, prefs, status, is_demo, created_at, updated_at) on users to authenticated;
create policy users_select on users for select to authenticated using ((id = auth.uid() or (org_id = app.me_org() and app.has_perm('users.manage'))));
grant select on invitations to authenticated;
create policy invitations_select on invitations for select to authenticated using (app.is_staff() and (org_id = app.me_org()) and app.has_perm('users.manage'));
grant select on email_outbox to authenticated;
create policy email_outbox_select on email_outbox for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.me_role() = 'owner'));
grant select on clients to authenticated;
create policy clients_select on clients for select to authenticated using (app.is_staff() and (org_id = app.me_org()) and app.has_perm('clients.manage'));
grant select (id, org_id, user_id, business_name, legal_name, contact_name, phone, email, address, city, categories, description, capacity_note, coverage, setup_minutes, teardown_minutes, tech_requirements, payment_terms, cancellation_policy, status, internal_notes, is_demo, created_at, updated_at) on vendors to authenticated;
create policy vendors_select on vendors for select to authenticated using (app.is_staff() and (org_id = app.me_org()) and app.has_perm('vendors.manage'));
grant select on vendor_availability to authenticated;
create policy vendor_availability_select on vendor_availability for select to authenticated using (app.is_staff() and (exists (select 1 from vendors v where v.id = vendor_availability.vendor_id and v.org_id = app.me_org())) and app.has_perm('vendors.manage'));
grant select on vendor_blackouts to authenticated;
create policy vendor_blackouts_select on vendor_blackouts for select to authenticated using (app.is_staff() and (exists (select 1 from vendors v where v.id = vendor_blackouts.vendor_id and v.org_id = app.me_org())) and app.has_perm('vendors.manage'));
grant select on vendor_evaluations to authenticated;
create policy vendor_evaluations_select on vendor_evaluations for select to authenticated using (app.is_staff() and (org_id = app.me_org()) and app.has_perm('vendors.manage'));
grant select on events to authenticated;
create policy events_select on events for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(id)));
grant select on event_staff to authenticated;
create policy event_staff_select on event_staff for select to authenticated using (app.is_staff() and (app.can_event(event_id)));
grant select on client_event_memberships to authenticated;
create policy client_event_memberships_select on client_event_memberships for select to authenticated using (app.is_staff() and (app.can_event(event_id)));
grant select on service_categories to authenticated;
create policy service_categories_select on service_categories for select to authenticated using (app.is_staff() and (org_id = app.me_org()));
grant select on service_catalog to authenticated;
create policy service_catalog_select on service_catalog for select to authenticated using (app.is_staff() and (org_id = app.me_org()));
grant select on service_packages to authenticated;
create policy service_packages_select on service_packages for select to authenticated using (app.is_staff() and (exists (select 1 from service_catalog s where s.id = service_packages.service_id and s.org_id = app.me_org())));
grant select on service_requests to authenticated;
create policy service_requests_select on service_requests for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(event_id)));
grant select on quotes to authenticated;
create policy quotes_select on quotes for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(event_id)));
grant select on quote_versions to authenticated;
create policy quote_versions_select on quote_versions for select to authenticated using (app.is_staff() and (exists (select 1 from quotes q where q.id = quote_versions.quote_id and q.org_id = app.me_org() and app.can_event(q.event_id))));
grant select on quote_items to authenticated;
create policy quote_items_select on quote_items for select to authenticated using (app.is_staff() and (exists (select 1 from quote_versions qv join quotes q on q.id = qv.quote_id where qv.id = quote_items.version_id and q.org_id = app.me_org() and app.can_event(q.event_id))));
grant select (id, org_id, event_id, request_id, vendor_id, status, public_title, service_description, qty_milli, service_date, arrival_time, setup_time, start_time, end_time, teardown_time, location_visible, location_detail, instructions, requirements, staff_needed, reject_reason, arrived_at, started_at, finished_at, created_by, created_at, updated_at) on service_assignments to authenticated;
create policy service_assignments_select on service_assignments for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(event_id)) and app.has_perm('logistics.manage'));
grant select on assignment_checklist to authenticated;
create policy assignment_checklist_select on assignment_checklist for select to authenticated using (app.is_staff() and (exists (select 1 from service_assignments a where a.id = assignment_checklist.assignment_id and a.org_id = app.me_org() and app.can_event(a.event_id))) and app.has_perm('logistics.manage'));
grant select on payments to authenticated;
create policy payments_select on payments for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(event_id)) and app.has_perm('finance.view'));
grant select on payment_transactions to authenticated;
create policy payment_transactions_select on payment_transactions for select to authenticated using (app.is_staff() and (org_id = app.me_org()) and app.has_perm('finance.view'));
grant select on expenses to authenticated;
create policy expenses_select on expenses for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(event_id)) and app.has_perm('finance.view'));
grant select on financial_adjustments to authenticated;
create policy financial_adjustments_select on financial_adjustments for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(event_id)) and app.has_perm('finance.view'));
grant select on tables_seating to authenticated;
create policy tables_seating_select on tables_seating for select to authenticated using (app.is_staff() and (app.can_event(event_id)));
grant select on guests to authenticated;
create policy guests_select on guests for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(event_id)));
grant select on tasks to authenticated;
create policy tasks_select on tasks for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(event_id)));
grant select on task_dependencies to authenticated;
create policy task_dependencies_select on task_dependencies for select to authenticated using (app.is_staff() and (exists (select 1 from tasks t where t.id = task_dependencies.task_id and t.org_id = app.me_org() and app.can_event(t.event_id))));
grant select on task_templates to authenticated;
create policy task_templates_select on task_templates for select to authenticated using (app.is_staff() and (org_id = app.me_org()));
grant select on timeline_items to authenticated;
create policy timeline_items_select on timeline_items for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(event_id)));
grant select on timeline_dependencies to authenticated;
create policy timeline_dependencies_select on timeline_dependencies for select to authenticated using (app.is_staff() and (exists (select 1 from timeline_items i where i.id = timeline_dependencies.item_id and i.org_id = app.me_org() and app.can_event(i.event_id))));
grant select on documents to authenticated;
create policy documents_select on documents for select to authenticated using (app.is_staff() and (org_id = app.me_org() and (uploaded_by = auth.uid() or (app.has_perm('documents.manage') and ((event_id is null and app.has_perm('vendors.manage')) or (event_id is not null and app.can_event(event_id)))))));
grant select on document_permissions to authenticated;
create policy document_permissions_select on document_permissions for select to authenticated using (app.is_staff() and (exists (select 1 from documents d where d.id = document_permissions.document_id and d.org_id = app.me_org())) and app.has_perm('documents.manage'));
grant select on incidents to authenticated;
create policy incidents_select on incidents for select to authenticated using (app.is_staff() and (org_id = app.me_org() and app.can_event(event_id)) and app.has_perm('logistics.manage'));
grant select on change_requests to authenticated;
create policy change_requests_select on change_requests for select to authenticated using ((org_id = app.me_org() and (requested_by = auth.uid() or (app.is_staff() and app.can_event(event_id)))));
grant select on audit_logs to authenticated;
create policy audit_logs_select on audit_logs for select to authenticated using (app.is_staff() and (org_id = app.me_org()) and app.has_perm('audit.view'));
grant select on integrations to authenticated;
create policy integrations_select on integrations for select to authenticated using (app.is_staff() and (org_id = app.me_org()) and app.has_perm('settings.manage'));
grant select on automation_rules to authenticated;
create policy automation_rules_select on automation_rules for select to authenticated using (app.is_staff() and (org_id = app.me_org()) and app.has_perm('settings.manage'));
grant select on automation_runs to authenticated;
create policy automation_runs_select on automation_runs for select to authenticated using (app.is_staff() and (org_id = app.me_org()) and app.has_perm('settings.manage'));
grant select on data_requests to authenticated;
create policy data_requests_select on data_requests for select to authenticated using ((user_id = auth.uid() or (org_id = app.me_org() and app.has_perm('users.manage'))));
grant select on consents to authenticated;
create policy consents_select on consents for select to authenticated using ((user_id = auth.uid()));
grant select on notifications to authenticated;
create policy notifications_select on notifications for select to authenticated using ((user_id = auth.uid()));
grant select on conversations, messages, message_attachments to authenticated;
create policy conversations_select on conversations for select to authenticated using (
  participant_user_id = auth.uid()
  or (app.is_staff() and org_id = app.me_org() and ((event_id is not null and app.can_event(event_id)) or (event_id is null and app.has_perm(case kind when 'client' then 'clients.manage' else 'vendors.manage' end)))));
create policy messages_select on messages for select to authenticated using (exists (select 1 from conversations c where c.id = messages.conversation_id));
create policy message_attachments_select on message_attachments for select to authenticated using (exists (select 1 from messages m where m.id = message_attachments.message_id));
-- (las políticas de messages/attachments heredan la visibilidad de conversations, que también tiene RLS)

-- Sin políticas (solo servidor con service_role): counters, sessions, password_resets, rate_limits, webhook_events.
-- Sin políticas de INSERT/UPDATE/DELETE en ninguna tabla: las escrituras pasan por el servidor.

-- Costos de proveedor: solo con permiso de finanzas (las columnas se excluyeron del grant de service_assignments)
create view staff_assignment_costs as
  select a.id, a.event_id, a.vendor_id, a.cost_cents, a.actual_cost_cents from service_assignments a
  where app.is_staff() and app.has_perm('finance.view') and a.org_id = app.me_org() and app.can_event(a.event_id);
create view staff_vendor_tax_data as
  select v.id, v.tax_data from vendors v where app.has_perm('finance.view') and v.org_id = app.me_org();

-- ───── Portal del cliente (vistas con permisos del propietario; filtran por membresía) ─────
create view portal_events as select e.id, e.folio, e.name, e.type, e.status, e.event_date, e.start_time, e.end_time, e.timezone, e.venue_name, e.address, e.city, e.latitude, e.longitude, e.guests_estimated, e.guests_confirmed, e.budget_target_cents, e.budget_approved_cents, e.currency, e.notes_client, e.brief, e.brief_step, e.brief_submitted_at, e.is_demo, e.created_at, e.updated_at, e.closed_at from events e where app.me_role() = 'client' and app.can_event(e.id);
create view portal_requests as select r.id, r.event_id, r.service_id, r.package_id, r.qty_milli, r.status, r.client_notes, r.unit_price_cents, r.discount_cents, r.tax_bps, r.price_version, r.created_by, r.created_at, r.updated_at, r.planner_message, s.name as service_name, s.unit_label from service_requests r join service_catalog s on s.id = r.service_id where app.me_role() = 'client' and app.can_event(r.event_id);
create view portal_quote_versions as select qv.*, q.event_id from quote_versions qv join quotes q on q.id = qv.quote_id where app.me_role() = 'client' and qv.status <> 'draft' and app.can_event(q.event_id);
create view portal_quote_items as select i.*, q.event_id from quote_items i join quote_versions qv on qv.id = i.version_id join quotes q on q.id = qv.quote_id where app.me_role() = 'client' and qv.status <> 'draft' and app.can_event(q.event_id);
create view portal_payments as select id, event_id, concept, amount_cents, paid_cents, due_date, paid_date, status from payments where app.me_role() = 'client' and direction = 'in' and status <> 'cancelled' and app.can_event(event_id);
create view portal_tasks as select id, event_id, title, description, due_date, priority, status, completed_at from tasks where app.me_role() = 'client' and audience = 'client' and app.can_event(event_id);
create view portal_timeline as select id, event_id, item_date, start_time, end_time, title, location, status from timeline_items where app.me_role() = 'client' and show_to_client and app.can_event(event_id);
create view portal_documents as select id, event_id, kind, name, mime, size_bytes, version, status, visibility, uploaded_by, created_at from documents where app.me_role() = 'client' and event_id is not null and app.can_event(event_id) and (visibility = 'client' or uploaded_by = auth.uid());
create view portal_guests as select * from guests where app.me_role() = 'client' and app.can_event(event_id);
create view portal_tables as select * from tables_seating where app.me_role() = 'client' and app.can_event(event_id);
create view portal_catalog as select id, category_id, name, description, price_type, base_price_cents, unit_label, min_qty_milli, max_qty_milli, tax_bps, advance_bps, details from service_catalog where app.me_role() = 'client' and active and visible_to_client and org_id = app.me_org();
create view portal_catalog_packages as select p.id, p.service_id, p.name, p.description, p.price_cents from service_packages p join service_catalog s on s.id = p.service_id where app.me_role() = 'client' and p.active and s.active and s.visible_to_client and s.org_id = app.me_org();

-- ───── Portal del proveedor: sin costos, sin cliente, sin nombre del evento, sin otros proveedores ─────
create view vendor_assignments as
  select a.id, a.status, a.public_title, e.type as event_type, e.folio, a.service_description, a.qty_milli, a.service_date,
         a.arrival_time, a.setup_time, a.start_time, a.end_time, a.teardown_time,
         case when a.location_visible then a.location_detail end as location,
         a.instructions, a.requirements, a.staff_needed, a.reject_reason, a.arrived_at, a.started_at, a.finished_at
  from service_assignments a join events e on e.id = a.event_id
  where app.me_role() = 'vendor' and a.vendor_id = app.me_vendor();
create view vendor_checklist as select k.id, k.assignment_id, k.phase, k.text, k.done from assignment_checklist k join service_assignments a on a.id = k.assignment_id where app.me_role() = 'vendor' and a.vendor_id = app.me_vendor();
create view vendor_tasks as select t.id, t.assignment_id, t.title, t.description, t.due_date, t.status from tasks t join service_assignments a on a.id = t.assignment_id where app.me_role() = 'vendor' and t.audience = 'vendor' and a.vendor_id = app.me_vendor();
create view vendor_timeline as select i.id, i.assignment_id, i.item_date, i.start_time, i.end_time, i.title, i.instructions, i.status from timeline_items i where app.me_role() = 'vendor' and i.vendor_id = app.me_vendor();
create view vendor_documents as select d.id, d.event_id, d.kind, d.name, d.mime, d.size_bytes from documents d where app.me_role() = 'vendor' and d.status = 'active' and (d.uploaded_by = auth.uid() or d.vendor_id = app.me_vendor() or exists (select 1 from document_permissions p where p.document_id = d.id and p.vendor_id = app.me_vendor()));
create view vendor_profile as select id, business_name, legal_name, contact_name, phone, email, address, city, categories, description, capacity_note, coverage, setup_minutes, teardown_minutes, tech_requirements, payment_terms, cancellation_policy, created_at, updated_at from vendors where app.me_role() = 'vendor' and id = app.me_vendor();
create view vendor_availability_own as select date, status, capacity, note from vendor_availability where app.me_role() = 'vendor' and vendor_id = app.me_vendor();

grant select on staff_assignment_costs, staff_vendor_tax_data, portal_events, portal_requests, portal_quote_versions, portal_quote_items, portal_payments, portal_tasks, portal_timeline, portal_documents, portal_guests, portal_tables, portal_catalog, portal_catalog_packages, vendor_assignments, vendor_checklist, vendor_tasks, vendor_timeline, vendor_documents, vendor_profile, vendor_availability_own to authenticated;