-- Prueba de aislamiento RLS. SIN EJECUTAR (no había PostgreSQL). Córrela en un proyecto LOCAL tras aplicar 0001 y 0002:
--   supabase db reset && psql "$DATABASE_URL" -f supabase/tests/rls_isolation.sql
-- Cada bloque lanza EXCEPTION si el aislamiento falla. Crea y borra sus propios datos dentro de una transacción (ROLLBACK).
begin;
insert into auth.users (id, instance_id, aud, role, email) values
 ('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-000000000000','authenticated','authenticated','owner@t.invalid'),
 ('00000000-0000-0000-0000-0000000000c1','00000000-0000-0000-0000-000000000000','authenticated','authenticated','c1@t.invalid'),
 ('00000000-0000-0000-0000-0000000000c2','00000000-0000-0000-0000-000000000000','authenticated','authenticated','c2@t.invalid'),
 ('00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-000000000000','authenticated','authenticated','v1@t.invalid'),
 ('00000000-0000-0000-0000-0000000000b2','00000000-0000-0000-0000-000000000000','authenticated','authenticated','v2@t.invalid');
insert into organizations (id, name) values ('00000000-0000-0000-0000-0000000000f1', 'Org A');
insert into users (id, org_id, email, display_name, role, permissions) values
 ('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000f1','owner@t.invalid','Dueña','owner','[]'),
 ('00000000-0000-0000-0000-0000000000c1','00000000-0000-0000-0000-0000000000f1','c1@t.invalid','C1','client','[]'),
 ('00000000-0000-0000-0000-0000000000c2','00000000-0000-0000-0000-0000000000f1','c2@t.invalid','C2','client','[]'),
 ('00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-0000000000f1','v1@t.invalid','V1','vendor','[]'),
 ('00000000-0000-0000-0000-0000000000b2','00000000-0000-0000-0000-0000000000f1','v2@t.invalid','V2','vendor','[]');
insert into clients (id, org_id, user_id, name) values ('00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-0000000000f1','00000000-0000-0000-0000-0000000000c1','Cliente Uno'),('00000000-0000-0000-0000-0000000000d2','00000000-0000-0000-0000-0000000000f1','00000000-0000-0000-0000-0000000000c2','Cliente Dos');
insert into vendors (id, org_id, user_id, business_name, tax_data) values ('00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-0000000000f1','00000000-0000-0000-0000-0000000000b1','Prov Uno','RFC-SECRETO'),('00000000-0000-0000-0000-0000000000e2','00000000-0000-0000-0000-0000000000f1','00000000-0000-0000-0000-0000000000b2','Prov Dos',null);
insert into events (id, org_id, folio, name, type, notes_internal, event_date) values
 ('00000000-0000-0000-0000-000000000a01','00000000-0000-0000-0000-0000000000f1','EV-1','Evento A','boda','NOTA INTERNA','2027-06-12'),
 ('00000000-0000-0000-0000-000000000a02','00000000-0000-0000-0000-0000000000f1','EV-2','Evento B','boda',null,'2027-07-10');
insert into client_event_memberships (event_id, client_id) values ('00000000-0000-0000-0000-000000000a01','00000000-0000-0000-0000-0000000000d1'),('00000000-0000-0000-0000-000000000a02','00000000-0000-0000-0000-0000000000d2');
insert into service_assignments (id, org_id, event_id, vendor_id, public_title, service_date, cost_cents, created_by) values
 ('00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-0000000000f1','00000000-0000-0000-0000-000000000a01','00000000-0000-0000-0000-0000000000e1','boda · EV-1','2027-06-12', 100000,'00000000-0000-0000-0000-0000000000a1');

create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true); end $$;
create or replace function pg_temp.must(ok boolean, msg text) returns void language plpgsql as $$ begin if not ok then raise exception 'FALLÓ: %', msg; end if; end $$;

select pg_temp.as_user('00000000-0000-0000-0000-0000000000c1');
select pg_temp.must((select count(*) from portal_events) = 1, 'el cliente 1 solo ve su evento');
select pg_temp.must((select count(*) from portal_events where id = '00000000-0000-0000-0000-000000000a02') = 0, 'el cliente 1 no ve el evento B');
select pg_temp.must((select count(*) from events) = 0, 'el cliente no lee la tabla base events');
select pg_temp.must((select count(*) from payments) = 0 and (select count(*) from service_assignments) = 0, 'el cliente no lee pagos ni asignaciones');
select pg_temp.must(not exists (select 1 from information_schema.columns where table_name = 'portal_events' and column_name in ('notes_internal','planner_id')), 'portal_events oculta notas internas');
reset role;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000b1');
select pg_temp.must((select count(*) from vendor_assignments) = 1, 'el proveedor 1 ve su asignación');
select pg_temp.must(not exists (select 1 from information_schema.columns where table_name = 'vendor_assignments' and column_name in ('cost_cents','event_id','vendor_id')), 'vendor_assignments no expone costo ni ids de evento');
select pg_temp.must((select count(*) from events) = 0 and (select count(*) from clients) = 0 and (select count(*) from vendors) = 0, 'el proveedor no lee eventos, clientes ni proveedores');
reset role;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000b2');
select pg_temp.must((select count(*) from vendor_assignments) = 0, 'el proveedor 2 no ve asignaciones ajenas');
reset role;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
select pg_temp.must((select count(*) from events) = 2, 'la propietaria ve todos los eventos de su organización');
do $$ begin begin update audit_logs set action = 'x'; exception when others then return; end; raise exception 'FALLÓ: audit_logs debía ser de solo anexado'; end $$;
reset role;
rollback;
select 'RLS: todas las comprobaciones pasaron' as resultado;
