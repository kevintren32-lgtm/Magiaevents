import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import { createApp } from '../../src/app.ts';
import { config } from '../../src/config.ts';
import { bootstrapOrg, seedDemo } from '../../src/seed.ts';

const PW: string = process.env.PLAYWRIGHT_MODULE ?? '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
const { chromium } = await import(PW);
let server: any, base = '', browser: any; const creds: Record<string, string> = {}; const errors: string[] = []; let db: any;

before(async () => {
  config.storageDir = fs.mkdtempSync('/tmp/planner-sweep-');
  const app = createApp(':memory:'); db = app.db;
  const { orgId, ownerId } = await bootstrapOrg(db, { orgName: 'Atelier Demo', ownerEmail: 'owner@sweep.invalid', ownerName: 'Marina Ríos', ownerPassword: 'Contrasena-Sweep-2026' });
  for (const c of await seedDemo(db, orgId, ownerId)) creds[c.email] = c.password; creds['owner@sweep.invalid'] = 'Contrasena-Sweep-2026';
  server = http.createServer(app.handler); await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r())); base = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({ args: ['--no-sandbox'] });
});
after(async () => { await browser?.close(); server?.close(); });

async function open(viewport = { width: 1280, height: 860 }) {
  const ctx = await browser.newContext({ viewport, locale: 'es-MX', acceptDownloads: true }); const page = await ctx.newPage();
  page.on('pageerror', (e: Error) => errors.push(`pageerror: ${e.message}`));
  page.on('console', (m: any) => { if (m.type() === 'error' && !/Failed to load resource: the server responded with a status of 4\d\d/.test(m.text())) errors.push(`console: ${m.text()}`); });   // los 4xx son las validaciones que las pruebas provocan a propósito
  return { ctx, page };
}
async function login(page: any, email: string, pw = creds[email]) {
  await page.goto(base + '/'); await page.getByLabel('Correo electrónico').fill(email); await page.getByLabel('Contraseña').fill(pw); await page.getByRole('button', { name: 'Entrar' }).click();
  try { await page.locator('#main.main h1').waitFor({ timeout: 8000 }); } catch { throw new Error(`login ${email}: sin h1 → ${(await page.locator('#app').innerText().catch(() => '')).slice(0, 300)} :: ${page.url()}`); }
}
const toast = (page: any, re: RegExp) => page.locator('.toast').filter({ hasText: re }).first().waitFor();
async function visit(page: any, route: string) {
  await page.goto(`${base}/#${route}`);
  try { await page.locator('#main.main h1').first().waitFor({ timeout: 8000 }); await page.waitForFunction(() => !document.querySelector('.skeleton'), null, { timeout: 8000 }); } catch (e) { throw new Error(`${route}: no se renderizó (${(e as Error).message.split('\n')[0]}) → ${(await page.locator('#app').innerText().catch(() => '')).slice(0, 200)}`); }
  const text: string = await page.locator('#main').innerText();
  assert.ok(!(await page.locator('#main .empty[role=alert]').count()), `${route}: error de carga → ${text.slice(0, 160)}`);
  for (const bad of ['undefined', '[object Object]', 'NaN', 'null']) assert.ok(!new RegExp(`\\b${bad.replace(/[[\]]/g, '\\$&')}\\b`).test(text), `${route}: aparece «${bad}»`);
  const unlabeled = await page.evaluate(() => [...document.querySelectorAll('#main input:not([type=hidden]),#main select,#main textarea')].filter((e: any) => !(e.labels?.length || e.getAttribute('aria-label'))).map((e: any) => e.name));
  assert.deepEqual(unlabeled, [], `${route}: campos sin etiqueta`);
  assert.ok((await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)) <= 1, `${route}: desbordamiento horizontal`);
}
const idOfFirstEvent = (page: any) => page.evaluate(async () => (await (await fetch('/api/events')).json()).events[0].id);

test('recorrido de TODAS las pantallas de la planner sin errores', async () => {
  const { ctx, page } = await open(); await login(page, 'owner@sweep.invalid'); const id = await idOfFirstEvent(page);
  for (const r of ['/', '/events', '/events?view=cal&m=2027-03', '/events?status=planning&q=Boda', '/clients', '/vendors', '/catalog', '/reports', '/messages', '/audit', '/users', '/settings', '/notifications', '/account'])
    await visit(page, r);
  for (const t of ['summary', 'services', 'quote', 'payments', 'vendors', 'timeline', 'tasks', 'guests', 'documents', 'changes', 'incidents', 'history']) await visit(page, `/events/${id}/${t}`);
  await visit(page, '/ruta-que-no-existe').catch(() => {}); await ctx.close();
});
test('recorrido de TODAS las pantallas del cliente y del proveedor', async () => {
  const c = await open(); await login(c.page, 'cliente1@demo.invalid'); const id = await idOfFirstEvent(c.page);
  for (const r of ['/', '/messages', '/notifications', '/account', '/quote', '/requests', '/payments', '/tasks', '/guests', '/timeline', '/documents']) await visit(c.page, r);
  for (const t of ['overview', 'wizard', 'catalog', 'requests', 'quote', 'payments', 'documents', 'timeline', 'guests', 'tasks', 'changes']) await visit(c.page, `/events/${id}/${t}`);
  await c.ctx.close();
  const v = await open(); await login(v.page, 'proveedor1@demo.invalid');
  for (const r of ['/', '/agenda', '/agenda?m=2027-03', '/assignments', '/assignments?f=done', '/assignments?f=all', '/availability', '/profile', '/messages', '/notifications', '/account']) await visit(v.page, r);
  await v.ctx.close();
});

test('planner crea cliente → invita → el cliente activa su cuenta → completa el asistente de 10 pasos', async () => {
  const o = await open(); await login(o.page, 'owner@sweep.invalid'); const p = o.page;
  await p.locator('.side nav a', { hasText: 'Clientes' }).click(); await p.getByRole('button', { name: 'Nuevo cliente' }).click();
  await p.getByLabel('Nombre').fill('Sofía Vargas'); await p.getByLabel('Correo').fill('sofia@sweep.invalid'); await p.getByRole('button', { name: 'Guardar' }).click(); await toast(p, /Cliente creado/);
  await p.getByRole('row', { name: /Sofía Vargas/ }).getByRole('button', { name: 'Invitar' }).click();
  const link = await p.locator('#lnk').inputValue(); assert.match(link, /#\/invite\?token=/); await p.getByRole('button', { name: 'Cancelar' }).click();
  const n = await open(); const q = n.page; await q.goto(link);
  await q.getByLabel('Tu nombre').fill('Sofía Vargas'); await q.getByLabel('Crea una contraseña').fill('Segura-Clave-Boda-2026');
  await q.getByRole('button', { name: 'Activar cuenta' }).click(); await q.getByText('Debes aceptar el aviso de privacidad').waitFor();   // validación real
  await q.getByLabel('He leído y acepto el aviso de privacidad').check(); await q.getByRole('button', { name: 'Activar cuenta' }).click(); await toast(q, /Cuenta activada/);
  await login(q, 'sofia@sweep.invalid', 'Segura-Clave-Boda-2026');
  await q.getByText('Vamos a construir tu evento').waitFor();
  await q.getByLabel('Ponle nombre a tu evento').fill('Boda de Sofía'); await q.getByLabel('Tipo de evento').selectOption('boda'); await q.getByRole('button', { name: 'Comenzar' }).click();
  await q.getByText('Paso 1 de 10').waitFor();
  for (let step = 1; step <= 9; step++) {
    await q.getByText(`Paso ${step} de 10`).waitFor();
    if (step === 3) await q.getByLabel('Ciudad').fill('Guadalajara');
    if (step === 7) await q.getByLabel('Banquetes').check();
    await q.getByRole('button', { name: 'Guardar y continuar' }).click();
  }
  await q.getByText('Paso 10 de 10').waitFor(); await q.getByText('Guadalajara').waitFor(); await q.getByText('Banquetes').first().waitFor();
  await q.getByRole('button', { name: 'Enviar a mi planner' }).click(); await toast(q, /Información enviada/);
  // La planner la ve y el cliente aparece como evento prospecto
  await p.reload(); await p.locator('.side nav a', { hasText: 'Eventos' }).click(); await p.getByRole('link', { name: 'Boda de Sofía' }).click();
  await p.getByText('Información enviada por el cliente').waitFor(); await p.getByText('Guadalajara').first().waitFor();
  assert.ok((await p.evaluate(async () => (await (await fetch('/api/notifications')).json()).notifications.some((x: any) => x.type === 'brief_submitted'))));
  for (const x of [o, n]) await x.ctx.close();
});

test('planner: catálogo, usuarios, marca y automatizaciones desde la interfaz', async () => {
  const o = await open(); await login(o.page, 'owner@sweep.invalid'); const p = o.page;
  await p.locator('.side nav a', { hasText: 'Catálogo' }).click(); await p.getByRole('button', { name: 'Nueva categoría' }).click(); await p.getByLabel('Nombre').fill('Magia y shows'); await p.getByRole('button', { name: 'Guardar' }).click(); await p.locator('#main h1').waitFor();
  await p.getByRole('button', { name: 'Nuevo servicio' }).click(); await p.getByLabel('Nombre').fill('Mago de cercanía'); await p.locator('#f-category_id').selectOption({ label: 'Magia y shows' }); await p.getByLabel('Precio base (MXN)').fill('3,500.50'); await p.getByRole('button', { name: 'Guardar' }).click(); await toast(p, /Servicio creado/);
  await p.getByRole('row', { name: /Mago de cercanía/ }).getByText('$3,500.50').waitFor();
  await p.getByRole('row', { name: /Mago de cercanía/ }).getByRole('button', { name: 'Editar' }).click(); await p.getByLabel('Visible para el cliente').uncheck(); await p.getByRole('button', { name: 'Guardar' }).click(); await toast(p, /Servicio actualizado/);
  await p.locator('.side nav a', { hasText: 'Usuarios' }).click(); await p.getByRole('button', { name: 'Invitar colaborador' }).click();
  await p.getByLabel('Correo').fill('equipo@sweep.invalid'); await p.getByLabel('Ver todos los eventos').check(); await p.getByLabel('Crear y editar eventos').check(); await p.getByRole('button', { name: 'Crear invitación' }).click(); await p.locator('#lnk').waitFor(); await p.getByRole('button', { name: 'Cancelar' }).click();
  await p.getByRole('row', { name: /Colaboradora Demo/ }).getByRole('button', { name: 'Permisos' }).click(); await p.getByLabel('Ver finanzas').check(); await p.getByRole('button', { name: 'Guardar' }).click(); await toast(p, /Permisos actualizados/);
  await p.getByRole('row', { name: /Colaboradora Demo/ }).getByRole('button', { name: 'Desactivar' }).click(); await p.locator('dialog').getByRole('button', { name: 'Confirmar' }).click();
  await p.getByRole('row', { name: /Colaboradora Demo/ }).getByText('Desactivado').waitFor();
  const dead = await open(); await dead.page.goto(base + '/'); await dead.page.getByLabel('Correo electrónico').fill('colaboradora@demo.invalid'); await dead.page.getByLabel('Contraseña').fill(creds['colaboradora@demo.invalid']); await dead.page.getByRole('button', { name: 'Entrar' }).click();
  await dead.page.getByText('Credenciales inválidas').waitFor(); await dead.ctx.close();                         // cuenta desactivada no entra
  await p.locator('.side nav a', { hasText: 'Configuración' }).click(); await p.getByLabel('Eslogan').fill('Eventos con alma'); await p.getByLabel('Color de acento (#RRGGBB)').fill('#5A3E1B'); await p.getByRole('button', { name: 'Guardar marca' }).click(); await toast(p, /Marca actualizada/);
  await p.getByLabel('Color de acento (#RRGGBB)').fill('rojo'); await p.getByRole('button', { name: 'Guardar marca' }).click(); await p.getByText(/Color inválido/).waitFor();   // validación visible
  await p.reload(); await p.getByText('Eventos con alma').first().waitFor(); assert.equal(await p.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()), '#5A3E1B');
  await p.getByRole('button', { name: 'Ejecutar ahora' }).click(); await toast(p, /Ejecutadas 8 reglas/); await p.reload(); await p.getByText('Últimas ejecuciones').waitFor();
  const c = await open(); await login(c.page, 'cliente2@demo.invalid'); await c.page.getByRole('link', { name: 'XV años de demostración' }).click(); await c.page.getByRole('link', { name: 'Catálogo' }).click();
  await c.page.getByText('Centros de mesa florales').waitFor(); assert.equal(await c.page.getByText('Mago de cercanía').count(), 0);          // oculto al cliente
  for (const x of [o, c]) await x.ctx.close();
});

test('cliente: documentos, invitados/mesas, mensajes y contraseña desde la interfaz', async () => {
  const c = await open(); await login(c.page, 'cliente1@demo.invalid'); const p = c.page;
  await p.getByRole('link', { name: 'Boda de demostración' }).click(); await p.getByRole('link', { name: 'Documentos' }).click();
  await p.locator('#f-file').setInputFiles({ name: 'referencias.pdf', mimeType: 'application/pdf', buffer: Buffer.from('%PDF-1.4\nreferencias') }); await p.getByRole('button', { name: 'Subir', exact: true }).click(); await toast(p, /Documento subido/);
  const [dl] = await Promise.all([p.waitForEvent('download'), p.getByRole('row', { name: /referencias\.pdf/ }).getByRole('button', { name: 'Descargar' }).click()]);
  assert.equal(dl.suggestedFilename(), 'referencias.pdf'); assert.ok(fs.readFileSync(await dl.path(), 'utf8').startsWith('%PDF-'));
  await p.getByRole('link', { name: 'Invitados y mesas' }).click();
  await p.getByRole('button', { name: 'Importar CSV' }).click(); await p.getByLabel('Pega el contenido del CSV').fill('nombre,correo,acompañantes\nLaura Gómez,laura@x.invalid,1\nPedro Ruiz,pedro@x.invalid,0\n,roto@x.invalid,0'); await p.getByRole('button', { name: 'Importar', exact: true }).click(); await toast(p, /2 importados, 1 con error/);
  await p.getByRole('button', { name: 'Nueva mesa' }).click(); await p.getByLabel('Nombre').fill('Mesa 1'); await p.getByLabel('Capacidad').fill('2'); await p.getByRole('button', { name: 'Guardar' }).click(); await p.getByText('Mesa 1').first().waitFor();
  await p.getByRole('row', { name: /Laura Gómez/ }).getByRole('button', { name: /Editar/ }).click(); await p.locator('#f-table_id').selectOption({ index: 1 }); await p.getByRole('button', { name: 'Guardar' }).click(); await toast(p, /Invitado actualizado/);
  await p.getByRole('row', { name: /Pedro Ruiz/ }).getByRole('button', { name: /Editar/ }).click(); await p.locator('#f-table_id').selectOption({ index: 1 }); await p.getByRole('button', { name: 'Guardar' }).click();
  await p.getByText(/Sobrecupo: la mesa «Mesa 1»/).waitFor();                                                   // el sobrecupo se explica en pantalla
  await p.getByRole('button', { name: 'Cancelar' }).click();
  await p.locator('.side nav a', { hasText: 'Mensajes' }).click(); await p.getByRole('button', { name: 'Nuevo mensaje' }).click(); await p.getByLabel('Asunto').fill('Duda sobre el menú'); await p.locator('#f-body').fill('¿Podemos incluir opciones veganas?'); await p.getByRole('button', { name: 'Enviar' }).last().click();
  await p.getByText('¿Podemos incluir opciones veganas?').waitFor();
  const o = await open(); await login(o.page, 'owner@sweep.invalid'); await o.page.locator('.side nav a', { hasText: 'Mensajes' }).click(); await o.page.getByRole('link', { name: 'Duda sobre el menú' }).click();
  await o.page.getByLabel('Escribe tu mensaje').fill('Claro, lo agregamos al menú.'); await o.page.getByRole('button', { name: 'Enviar' }).click(); await o.page.getByText('Claro, lo agregamos al menú.').waitFor();
  await p.reload(); await p.getByText('Claro, lo agregamos al menú.').waitFor();
  await p.locator('.side nav a', { hasText: 'Mi cuenta' }).click(); await p.getByLabel('Contraseña actual').fill('incorrecta-123'); await p.getByLabel('Nueva contraseña').fill('Nueva-Segura-2026'); await p.getByRole('button', { name: 'Cambiar contraseña' }).click(); await p.getByText('La contraseña actual no es correcta').waitFor();
  await p.getByLabel('Contraseña actual').fill(creds['cliente1@demo.invalid']); await p.getByLabel('Nueva contraseña').fill('corta'); await p.getByRole('button', { name: 'Cambiar contraseña' }).click(); await p.getByText(/al menos 10 caracteres/).first().waitFor();
  await p.getByLabel('Nueva contraseña').fill('Nueva-Segura-2026'); await p.getByRole('button', { name: 'Cambiar contraseña' }).click(); await toast(p, /Contraseña actualizada/);
  await p.getByRole('button', { name: 'Cerrar sesión' }).click(); await p.getByLabel('Correo electrónico').waitFor(); await login(p, 'cliente1@demo.invalid', 'Nueva-Segura-2026');
  await p.goto(base + '/#/login'); await p.locator('#main.main h1').waitFor();                                      // con sesión, /login redirige al inicio
  for (const x of [c, o]) await x.ctx.close();
});

test('recuperación de contraseña desde la interfaz y proveedor: disponibilidad', async () => {
  const a = await open(); await a.page.goto(base + '/#/forgot'); await a.page.getByLabel('Correo electrónico').fill('nadie@x.invalid'); await a.page.getByRole('button', { name: 'Enviar instrucciones' }).click(); await toast(a.page, /Si el correo existe/);
  const t = db.get(`SELECT 1 x`); void t; await a.ctx.close();
  const v = await open(); await login(v.page, 'proveedor1@demo.invalid'); await v.page.locator('.tabbar, .side nav').first().waitFor();
  await v.page.locator('.side nav a', { hasText: 'Disponibilidad' }).click(); await v.page.getByLabel('Fecha').first().fill('2027-05-01'); await v.page.getByRole('button', { name: 'Guardar' }).click(); await toast(v.page, /Disponibilidad guardada/);
  await v.page.getByLabel('Desde').fill('2027-07-01'); await v.page.getByLabel('Hasta').fill('2027-07-15'); await v.page.getByRole('button', { name: 'Bloquear' }).click(); await toast(v.page, /Periodo bloqueado/);
  await v.page.getByText('Vacaciones').count(); await v.page.getByText('Bloqueos').waitFor(); await v.ctx.close();
});

test('móvil (390 px): todas las pantallas sin desbordamiento horizontal ni errores', async () => {
  const mob = { width: 390, height: 844 };
  const o = await open(mob); await login(o.page, 'owner@sweep.invalid'); const id = await idOfFirstEvent(o.page);
  for (const r of ['/', '/events', '/events?view=cal&m=2027-03', '/clients', '/vendors', '/catalog', '/reports', '/audit', '/users', '/settings', '/messages']) await visit(o.page, r);
  for (const t of ['summary', 'services', 'quote', 'payments', 'vendors', 'timeline', 'tasks', 'guests', 'documents', 'changes', 'incidents', 'history']) await visit(o.page, `/events/${id}/${t}`);
  await o.ctx.close();
  const c = await open(mob); await login(c.page, 'cliente2@demo.invalid'); const cid = await idOfFirstEvent(c.page);
  for (const t of ['overview', 'wizard', 'catalog', 'requests', 'quote', 'payments', 'documents', 'timeline', 'guests', 'tasks', 'changes']) await visit(c.page, `/events/${cid}/${t}`);
  await c.ctx.close();
  const v = await open(mob); await login(v.page, 'proveedor1@demo.invalid');
  for (const r of ['/', '/agenda?m=2027-03', '/assignments', '/availability', '/profile', '/messages']) await visit(v.page, r);
  await v.ctx.close();
});

test('la interfaz completa no produjo errores de consola ni violaciones de CSP', () => { assert.deepEqual(errors, []); });
