import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
// Playwright se resuelve desde la instalación global (cámbialo por 'playwright' si lo instalas localmente)
const PW: string = process.env.PLAYWRIGHT_MODULE ?? '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
const { chromium } = await import(PW);
import { createApp } from '../../src/app.ts';
import { config } from '../../src/config.ts';
import { bootstrapOrg, seedDemo } from '../../src/seed.ts';

let server: any, base = '', browser: any, creds: Record<string, string> = {};
const errors: string[] = [];
const SHOTS = '/tmp/shots';

before(async () => {
  config.storageDir = fs.mkdtempSync('/tmp/planner-e2e-');
  const { db, handler } = createApp(':memory:');
  const { orgId, ownerId } = await bootstrapOrg(db, { orgName: 'Atelier Demo', ownerEmail: 'owner@e2e.invalid', ownerName: 'Marina Ríos', ownerPassword: 'Contrasena-E2E-2026' });
  for (const c of await seedDemo(db, orgId, ownerId)) creds[c.email] = c.password;
  creds['owner@e2e.invalid'] = 'Contrasena-E2E-2026';
  server = http.createServer(handler); await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r())); base = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({ args: ['--no-sandbox'] });
});
after(async () => { await browser?.close(); server?.close(); });

async function session(email: string, viewport = { width: 1280, height: 860 }) {
  const ctx = await browser.newContext({ viewport, locale: 'es-MX' }); const page = await ctx.newPage();
  page.on('pageerror', (e: Error) => errors.push(`pageerror ${email}: ${e.message}`));
  page.on('console', (m: any) => { if (m.type() === 'error') errors.push(`console ${email}: ${m.text()}`); });
  await page.goto(base + '/');
  await page.getByLabel('Correo electrónico').fill(email); await page.getByLabel('Contraseña').fill(creds[email]); await page.getByRole('button', { name: 'Entrar' }).click();
  await page.locator('#main.main h1').waitFor(); return { ctx, page };
}
const toastText = (page: any) => page.locator('.toast').last();
async function a11yBasics(page: any, where: string) {
  await page.locator('#main h1').first().waitFor(); await page.waitForTimeout(250);
  const bad = await page.evaluate(() => [...document.querySelectorAll('input:not([type=hidden]),select,textarea')].filter((el: any) => !(el.labels?.length || el.getAttribute('aria-label'))).map((el: any) => el.name || el.id));
  assert.deepEqual(bad, [], `${where}: campos sin etiqueta`);
  assert.equal(await page.locator('h1').count() >= 1, true, `${where}: sin h1`);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  assert.ok(overflow <= 1, `${where}: desbordamiento horizontal de ${overflow}px`);
}

test('planner → cliente → proveedor: el flujo operativo completo desde la interfaz', async () => {
  const o = await session('owner@e2e.invalid'); const p = o.page;
  assert.match(await p.locator('h1').innerText(), /Buenos días, Marina/);
  await a11yBasics(p, 'panel');
  await p.screenshot({ path: `${SHOTS}/01-panel.png`, fullPage: true });
  await p.locator('.side nav a', { hasText: 'Eventos' }).click();
  await p.getByRole('link', { name: 'Boda de demostración' }).click();
  await p.getByRole('link', { name: 'Servicios' }).click();
  await p.getByRole('button', { name: 'Generar propuesta para el cliente' }).click();
  await p.getByRole('button', { name: 'Enviar propuesta' }).click();
  await toastText(p).waitFor(); assert.match(await toastText(p).innerText(), /Versión 1 enviada/);

  // Cliente: ve la propuesta y la aprueba
  const c = await session('cliente1@demo.invalid'); const cp = c.page;
  await cp.getByRole('link', { name: 'Boda de demostración' }).click();
  await cp.locator('#main h1', { hasText: 'Boda de demostración' }).waitFor();
  await a11yBasics(cp, 'cliente-resumen');
  await cp.getByRole('link', { name: 'Presupuesto' }).click();
  await cp.getByText('Propuesta 1').waitFor();
  assert.equal(await cp.getByText('Banquetes Demo').count(), 0);                               // no se revela el proveedor
  await cp.getByRole('button', { name: 'Aprobar propuesta' }).click();
  await cp.locator('dialog').getByRole('button', { name: 'Aprobar propuesta' }).click();
  await cp.getByText('Aprobada por ti').first().waitFor();
  await cp.getByRole('link', { name: 'Mis solicitudes' }).click();
  await cp.getByText('Aprobado por el cliente').first().waitFor();                               // aprobado ≠ confirmado
  assert.equal(await cp.getByText(/^Confirmado$/).count(), 0);
  // El asistente guarda el progreso
  await cp.getByRole('link', { name: 'Tu información' }).click();
  await cp.getByLabel('Tipo de evento').selectOption('boda'); await cp.getByRole('button', { name: 'Guardar y continuar' }).click();
  await cp.getByText('Paso 2 de 10').waitFor();
  await cp.screenshot({ path: `${SHOTS}/02-cliente-asistente.png`, fullPage: true });

  // Planner: disponibilidad + asignación
  await p.locator('.side nav a', { hasText: 'Proveedores' }).click();
  await p.getByRole('row', { name: /Banquetes Demo/ }).getByRole('button', { name: 'Disponibilidad' }).click();
  await p.getByLabel('Fecha').fill('2027-03-20'); await p.getByRole('button', { name: 'Guardar' }).click();
  await toastText(p).waitFor();
  await p.locator('.side nav a', { hasText: 'Eventos' }).click(); await p.getByRole('link', { name: 'Boda de demostración' }).click();
  await p.locator('.tabs').getByRole('link', { name: 'Proveedores' }).click();
  await p.locator('li').filter({ hasText: 'Banquete de tres tiempos' }).getByRole('button', { name: 'Asignar proveedor' }).click();
  await p.locator('#f-vendor_id').selectOption({ label: 'Banquetes Demo (Activo)' });
  await p.getByLabel('Instrucciones de montaje').fill('Acceso por puerta de servicio');
  await p.getByLabel('Checklist de preparación').fill('Verificar menú\nConfirmar personal');
  await p.getByRole('button', { name: 'Enviar solicitud al proveedor' }).click();
  await p.getByText('Banquetes Demo').first().waitFor();

  // Proveedor: solo ve lo autorizado, acepta
  const v = await session('proveedor1@demo.invalid'); const vp = v.page;
  await a11yBasics(vp, 'proveedor-inicio');
  const body = await vp.locator('body').innerText();
  for (const secret of ['Boda de demostración', 'Cliente Demo Uno', 'Audio Demo']) assert.ok(!body.includes(secret), `el proveedor ve «${secret}»`);
  await vp.getByRole('link', { name: /boda · EV-DEMO-0001/ }).first().click();
  const ficha = await vp.locator('body').innerText(); assert.ok(!ficha.includes('Boda de demostración') && !/costo/i.test(ficha));
  await vp.getByRole('button', { name: 'Aceptar' }).click(); await vp.getByText('Aceptaste esta solicitud').waitFor();
  await vp.screenshot({ path: `${SHOTS}/03-proveedor-asignacion.png`, fullPage: true });

  // Planner confirma → el proveedor puede registrar el servicio
  await p.reload(); await p.getByRole('button', { name: 'Confirmar' }).click(); await toastText(p).waitFor();
  await vp.reload(); await vp.getByRole('button', { name: 'Confirmar llegada' }).waitFor();
  await vp.getByRole('button', { name: 'Marcar como hecho' }).first().click(); await vp.getByText('✓ Hecho').waitFor();
  await p.screenshot({ path: `${SHOTS}/04-planner-proveedores.png`, fullPage: true });
  for (const x of [o, c, v]) await x.ctx.close();
});

test('móvil: navegación inferior, tablas como tarjetas y sin desbordamiento', async () => {
  const m = await session('cliente1@demo.invalid', { width: 390, height: 844 }); const p = m.page;
  await a11yBasics(p, 'móvil-inicio');
  assert.equal(await p.locator('.tabbar').isVisible(), true); assert.equal(await p.locator('.side').isVisible(), false);
  await p.screenshot({ path: `${SHOTS}/05-movil-cliente.png` });
  await p.getByRole('link', { name: 'Boda de demostración' }).click(); await p.getByRole('link', { name: 'Catálogo' }).click();
  await a11yBasics(p, 'móvil-catálogo'); await p.screenshot({ path: `${SHOTS}/06-movil-catalogo.png`, fullPage: true });
  await m.ctx.close();
  const o = await session('owner@e2e.invalid', { width: 390, height: 844 });
  await o.page.getByRole('button', { name: 'Más' }).click(); assert.equal(await o.page.locator('.side').isVisible(), true);
  await o.page.locator('.side nav a', { hasText: 'Eventos' }).click(); await a11yBasics(o.page, 'móvil-eventos'); await o.page.screenshot({ path: `${SHOTS}/07-movil-eventos.png`, fullPage: true });
  await o.ctx.close();
});

test('la interfaz no produjo errores de consola ni violaciones de CSP', () => { assert.deepEqual(errors, []); });
