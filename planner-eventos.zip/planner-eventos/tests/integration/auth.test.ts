import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { Api, PW, startWorld } from './helpers.ts';
import type { World } from './helpers.ts';

let w: World;
before(async () => { w = await startWorld(); });
after(() => w.close());

test('login: mismo mensaje para cuenta inexistente, contraseña errónea y cuenta bloqueada; bloqueo tras 5 intentos', async () => {
  const a = new Api(w.base);
  const unknown = await a.post('/api/auth/login', { email: 'nadie@test.invalid', password: 'Cualquiera-123456' });
  const wrong = await a.post('/api/auth/login', { email: 'c2@test.invalid', password: 'Incorrecta-123456' });
  assert.equal(unknown.status, 401); assert.equal(wrong.status, 401);
  assert.deepEqual(unknown.body, wrong.body);
  for (let i = 0; i < 5; i++) await a.post('/api/auth/login', { email: 'c2@test.invalid', password: 'Incorrecta-123456' });
  const locked = await a.post('/api/auth/login', { email: 'c2@test.invalid', password: PW });   // contraseña correcta, pero bloqueada
  assert.equal(locked.status, 401); assert.deepEqual(locked.body, wrong.body);
});
test('la cookie de sesión es HttpOnly y SameSite=Strict, y el token no se guarda en claro', async () => {
  const r = await fetch(w.base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json', 'x-requested-with': 'fetch' }, body: JSON.stringify({ email: 'v1@test.invalid', password: PW }) });
  const sc = r.headers.getSetCookie()[0]; assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Strict/);
  const tok = sc.match(/sid=([^;]+)/)![1];
  assert.equal(w.db.get('SELECT 1 x FROM sessions WHERE id = ?', tok), undefined);
});
test('recuperación de contraseña: respuesta idéntica exista o no el correo; el enlace es de un solo uso y cierra sesiones', async () => {
  const a = new Api(w.base);
  const r1 = await a.post('/api/auth/forgot', { email: 'v1@test.invalid' }), r2 = await a.post('/api/auth/forgot', { email: 'fantasma@test.invalid' });
  assert.deepEqual(r1.body, r2.body); assert.equal(r1.status, 200);
  const mail = w.row(`SELECT body FROM email_outbox WHERE to_email = 'v1@test.invalid' AND template = 'password_reset'`);
  assert.equal(w.db.get(`SELECT 1 x FROM email_outbox WHERE to_email = 'fantasma@test.invalid'`), undefined);
  const tok = mail.body.split('token=')[1];
  const live = await w.login('v1@test.invalid');
  assert.equal((await a.post('/api/auth/reset', { token: tok, password: 'corta' })).status, 422);
  assert.equal((await a.post('/api/auth/reset', { token: tok, password: 'Nueva-Contrasena-9876' })).status, 200);
  assert.equal((await a.post('/api/auth/reset', { token: tok, password: 'Otra-Contrasena-9876' })).status, 400);
  assert.equal((await live.get('/api/me')).body.user, null);                  // sesiones anteriores revocadas
  await new Api(w.base).login('v1@test.invalid', 'Nueva-Contrasena-9876');
});
test('limitación de solicitudes en el login por correo', async () => {
  const a = new Api(w.base); let last = 0;
  for (let i = 0; i < 12; i++) last = (await a.post('/api/auth/login', { email: 'logi@test.invalid', password: 'Mala-Contrasena-123' })).status;
  assert.equal(last, 429);
});
