import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Api, PW, startWorld } from './helpers.ts';
import type { World } from './helpers.ts';
import { config } from '../../src/config.ts';
import { runAutomations } from '../../src/api/automations.ts';

let w: World; let o: Api; let c1: Api; let v1: Api; let ev: string; let svc: string; let rq: string; let asg: string;
const ok = (r: { status: number; body: any }, code = 200) => { assert.equal(r.status, code, JSON.stringify(r.body)); return r.body; };
const PDF = Buffer.from('%PDF-1.4\nx').toString('base64');

before(async () => {
  config.storageDir = fs.mkdtempSync('/tmp/planner-cov-'); w = await startWorld(); o = w.owner;
  ev = ok(await o.post('/api/events', { name: 'Evento Cobertura', type: 'boda', event_date: '2027-08-14', client_id: w.clients.c1, guests_estimated: 40 })).id;
  [c1, v1] = await Promise.all([w.login('c1@test.invalid'), w.login('v1@test.invalid')]);
  const cat = (await o.get('/api/catalog')).body.categories[0].id;
  svc = ok(await o.post('/api/catalog/services', { category_id: cat, name: 'Servicio X', price_type: 'fixed', base_price_cents: 100000, vendor_id: w.vendors.v1 })).id;
  rq = ok(await c1.post(`/api/events/${ev}/requests`, { service_id: svc })).id;
  ok(await o.post(`/api/requests/${rq}/status`, { to: 'in_review' }));
  ok(await o.put(`/api/vendors/${w.vendors.v1}/availability`, { date: '2027-08-14', status: 'available' }));
  asg = ok(await o.post(`/api/requests/${rq}/assign`, { vendor_id: w.vendors.v1, cost_cents: 50000, start_time: '18:00', end_time: '22:00' })).id;
});
after(() => w.close());

test('invitados: alta, importación CSV validada, mesas y sobrecupo', async () => {
  const csv = 'nombre,correo,teléfono,grupo,acompañantes,alimentación\nAna Pérez,ana@x.invalid,333,Familia,1,Vegetariana\n,sin-nombre@x.invalid,,,,\nLuis,correo-malo,,,,\nMaría,maria@x.invalid,,Amigos,99,\n"=HYPERLINK(""x"")",,,,,';
  const r = ok(await c1.post(`/api/events/${ev}/guests/import`, { csv }));
  assert.equal(r.created, 2); assert.deepEqual(r.errors.map((e: any) => e.line).sort(), [3, 4, 5]);
  const list = ok(await c1.get(`/api/events/${ev}/guests`)); assert.equal(list.guests.length, 2);
  const mesa = ok(await c1.post(`/api/events/${ev}/tables`, { name: 'Mesa 1', capacity: 3 }));
  assert.equal((await c1.post(`/api/events/${ev}/tables`, { name: 'Mesa 1', capacity: 3 })).status, 409);   // nombre repetido
  const ana = list.guests.find((g: any) => g.name === 'Ana Pérez'); const form = list.guests.find((g: any) => g.name !== 'Ana Pérez');
  ok(await c1.patch(`/api/guests/${form.id}`, { companions: 1 }));                                        // este invitado necesita 2 lugares
  ok(await c1.post(`/api/guests/${ana.id}/seat`, { table_id: mesa.id }));                                 // Ana ocupa 2 lugares
  const over = await c1.post(`/api/guests/${form.id}/seat`, { table_id: mesa.id });                       // 2+2 > 3
  assert.equal(over.status, 409); assert.equal(over.body.error.details.overbooked, true);
  ok(await c1.patch(`/api/guests/${ana.id}`, { status: 'confirmed' }));
  assert.equal(w.row('SELECT guests_confirmed g FROM events WHERE id = ?', ev).g, 2);                    // confirmados cuentan acompañantes
  ok(await c1.post(`/api/guests/${ana.id}/seat`, { table_id: null }));
  assert.equal(ok(await c1.get(`/api/events/${ev}/guests`)).tables[0].seats_used, 0);
  // otro cliente no puede tocar estos invitados
  const c2 = await w.login('c2@test.invalid');
  assert.equal((await c2.patch(`/api/guests/${ana.id}`, { status: 'declined' })).status, 404);
  assert.equal((await c2.post(`/api/guests/${ana.id}/seat`, { table_id: null })).status, 404);
});

test('tareas con dependencias y plantillas; el cliente solo gestiona las suyas', async () => {
  const t1 = ok(await o.post(`/api/events/${ev}/tasks`, { title: 'Primero', audience: 'client', due_date: '2020-01-01' }));
  const t2 = ok(await o.post(`/api/events/${ev}/tasks`, { title: 'Después', audience: 'client', depends_on: [t1.id] }));
  const tInt = ok(await o.post(`/api/events/${ev}/tasks`, { title: 'Interna', audience: 'internal' }));
  assert.equal((await c1.post(`/api/tasks/${t2.id}/status`, { to: 'completed' })).status, 409);          // dependencia pendiente
  assert.equal((await c1.post(`/api/tasks/${tInt.id}/status`, { to: 'completed' })).status, 403);        // no es suya
  assert.deepEqual(ok(await c1.get(`/api/events/${ev}/tasks`)).tasks.map((t: any) => t.title).sort(), ['Después', 'Primero']);
  ok(await c1.post(`/api/tasks/${t1.id}/status`, { to: 'completed' })); ok(await c1.post(`/api/tasks/${t2.id}/status`, { to: 'completed' }));
  assert.equal((await c1.post(`/api/tasks/${t2.id}/status`, { to: 'cancelled' })).status, 403);
  assert.equal(ok(await c1.get(`/api/events/${ev}`)).progress.percent, 100);
  assert.equal((await o.post(`/api/events/${ev}/tasks`, { title: 'Prov', audience: 'vendor' })).status, 422);   // exige asignación
  const tv = ok(await o.post(`/api/events/${ev}/tasks`, { title: 'Llevar menús', audience: 'vendor', assignment_id: asg }));
  assert.equal((await w.login('v2@test.invalid').then((x) => x.post(`/api/vendor/tasks/${tv.id}/complete`))).status, 404);
  ok(await v1.post(`/api/vendor/tasks/${tv.id}/complete`));
  const tpl = ok(await o.post('/api/task-templates', { name: 'Mi plantilla', event_type: 'boda', items: [{ title: 'A', offset_days: -10 }, { title: 'B', offset_days: 3, audience: 'client' }] }));
  assert.equal((await o.post('/api/task-templates', { name: 'mala', event_type: 'boda', items: [{ offset_days: 1 }] })).status, 422);
  const e2 = ok(await o.post('/api/events', { name: 'Con plantilla', type: 'boda', event_date: '2027-09-01', template_id: tpl.id }));
  assert.deepEqual(ok(await o.get(`/api/events/${e2.id}/tasks`)).tasks.map((t: any) => t.due_date), ['2027-08-22', '2027-09-04']);
  assert.equal((await o.post('/api/events', { name: 'Sin fecha', type: 'boda', template_id: tpl.id })).status, 422);
});

test('automatizaciones: idempotentes, registran ejecuciones y marcan pagos vencidos', async () => {
  const p = ok(await o.post(`/api/events/${ev}/payments`, { direction: 'in', client_id: w.clients.c1, amount_cents: 200000, due_date: '2020-02-02', idempotency_key: 'vencido-0001' }));
  ok(await o.post(`/api/events/${ev}/tasks`, { title: 'Atrasada interna', due_date: '2020-01-01' }));
  ok(await o.post(`/api/events/${ev}/tasks`, { title: 'Atrasada del cliente', audience: 'client', due_date: '2020-01-01' }));
  const first = ok(await o.post('/api/automations/run')).results; assert.ok(first.every((r: any) => r.status === 'ok'), JSON.stringify(first));
  assert.equal(w.row('SELECT status FROM payments WHERE id = ?', p.id).status, 'overdue');
  const count = () => w.row('SELECT COUNT(*) n FROM notifications').n; const n1 = count();
  runAutomations(w.db, w.orgId); runAutomations(w.db, w.orgId);
  assert.equal(count(), n1, 'repetir las automatizaciones no debe duplicar avisos');
  assert.ok(w.row('SELECT COUNT(*) n FROM automation_runs').n >= 16);
  assert.ok((await o.get('/api/notifications')).body.notifications.some((n: any) => n.type === 'payment_overdue' && n.priority === 'high'));
  assert.ok((await c1.get('/api/notifications')).body.notifications.some((n: any) => n.type === 'task_overdue'));
  // preferencias: silenciar avisos no esenciales
  ok(await c1.patch('/api/me', { prefs: { mute_noncritical: true } }));
  ok(await o.post(`/api/events/${ev}/tasks`, { title: 'Nueva para cliente', audience: 'client' }));
  assert.ok(!(await c1.get('/api/notifications')).body.notifications.some((n: any) => n.title === 'Tienes una tarea pendiente' && n.body === 'Nueva para cliente'));
  ok(await c1.patch('/api/me', { prefs: { mute_noncritical: false } }));
  assert.equal((await c1.post('/api/automations/run')).status, 403);
});

test('reportes: cifras, CSV con protección contra fórmulas y permisos', async () => {
  const evx = ok(await o.post('/api/events', { name: '=CMD|calc', type: 'boda', event_date: '2027-10-10' }));
  const csv = await o.get('/api/reports/events.csv'); assert.equal(csv.status, 200); assert.match(csv.headers.get('content-type') ?? '', /text\/csv/);
  assert.ok(csv.body.includes("'=CMD|calc"), 'el CSV debe neutralizar fórmulas'); assert.ok(csv.body.split('\n')[0].includes('contratado_centavos'));
  const rep = ok(await o.get('/api/reports/summary')); assert.ok(rep.events_by_status.prospect >= 1); assert.ok(rep.totals);
  const all = await w.login('all@test.invalid'); assert.equal((await all.get('/api/reports/summary')).status, 403);   // sin reports.view
  assert.equal((await c1.get('/api/reports/events.csv')).status, 403);
  void evx;
});

test('solicitudes de cambio: aprobación aplica horarios con registro; el cliente retira y rechaza propuestas', async () => {
  const it = ok(await o.post(`/api/events/${ev}/timeline`, { item_date: '2027-08-14', start_time: '17:00', end_time: '18:00', title: 'Ceremonia' }));
  const cr = ok(await o.post(`/api/events/${ev}/change-requests`, { reason: 'Adelantar ceremonia', target_type: 'timeline_item', target_id: it.id, payload: { start_time: '16:30' } }));
  assert.equal((await c1.post(`/api/change-requests/${cr.id}/decide`, { approve: true })).status, 403);
  ok(await o.post(`/api/change-requests/${cr.id}/decide`, { approve: true, note: 'Ok' }));
  assert.equal(w.row('SELECT start_time s FROM timeline_items WHERE id = ?', it.id).s, '16:30');
  assert.equal((await o.post(`/api/change-requests/${cr.id}/decide`, { approve: false })).status, 409);
  const mine = ok(await c1.post(`/api/events/${ev}/change-requests`, { reason: 'Quiero más mesas' }));
  assert.deepEqual(ok(await c1.get(`/api/events/${ev}/change-requests`)).change_requests.map((x: any) => x.id), [mine.id]);   // solo las suyas
  ok(await o.post(`/api/change-requests/${mine.id}/decide`, { approve: false, note: 'No hay espacio' }));
  assert.ok((await c1.get('/api/notifications')).body.notifications.some((n: any) => n.type === 'change_decision'));
  // cliente retira solicitud en revisión; no puede retirar una confirmada
  const r2 = ok(await c1.post(`/api/events/${ev}/requests`, { service_id: svc }));
  ok(await c1.post(`/api/requests/${r2.id}/status`, { to: 'cancelled' }));
  assert.equal((await c1.post(`/api/requests/${r2.id}/status`, { to: 'requested' })).status, 409);
  // proveedor: solicitud de cambio e incidencia
  ok(await v1.post(`/api/vendor/assignments/${asg}/change-requests`, { reason: 'Necesito llegar una hora antes' }));
  assert.ok((await o.get('/api/notifications')).body.notifications.some((n: any) => n.type === 'change_request'));
});

test('propuesta: rechazo del cliente, versión vigente y precios solo de la planner', async () => {
  const rq2 = ok(await c1.post(`/api/events/${ev}/requests`, { service_id: svc })); ok(await o.post(`/api/requests/${rq2.id}/status`, { to: 'in_review' }));
  const v = ok(await o.post(`/api/events/${ev}/quote/versions`, { charges_cents: 10000, charges_note: 'Traslado' }));
  assert.ok(v.total_cents > 0);
  assert.equal((await c1.post(`/api/events/${ev}/quote/respond`, { version: v.version, accept: false })).status, 200);
  assert.equal(w.row('SELECT status FROM service_requests WHERE id = ?', rq2.id).status, 'quote_preparing');   // vuelve a preparación
  assert.equal((await c1.post(`/api/events/${ev}/quote/respond`, { version: v.version, accept: true })).status, 409);   // ya no vigente
  assert.equal((await o.get(`/api/events/${ev}/quote`)).body.versions[0].status, 'rejected');
  assert.equal((await o.post(`/api/events/${ev}/quote/versions`, {}).then((r) => r.status)), 200);
});

test('documentos: versionado, archivado y descarga real del contenido', async () => {
  const d1 = ok(await o.post(`/api/events/${ev}/documents`, { name: 'Contrato.pdf', kind: 'contrato', mime: 'application/pdf', data_base64: PDF, visibility: 'client' }));
  const d2 = ok(await o.post(`/api/events/${ev}/documents`, { name: 'Contrato v2.pdf', kind: 'contrato', mime: 'application/pdf', data_base64: PDF, visibility: 'client', supersedes_id: d1.id }));
  assert.equal(d2.version, 2); assert.equal(w.row('SELECT status FROM documents WHERE id = ?', d1.id).status, 'archived');
  const link = ok(await c1.post(`/api/documents/${d2.id}/link`));
  const dl = await fetch(w.base + link.url, { headers: { cookie: c1.cookie } }); assert.equal(dl.status, 200); assert.equal(dl.headers.get('x-content-type-options'), 'nosniff');
  assert.ok(Buffer.from(await dl.arrayBuffer()).toString().startsWith('%PDF-'));
  const up = ok(await c1.post(`/api/events/${ev}/documents`, { name: 'inspiracion.png', kind: 'referencia', mime: 'image/png', data_base64: Buffer.from('89504e470d0a1a0a0000', 'hex').toString('base64'), visibility: 'vendor' }));
  assert.equal(w.row('SELECT visibility v FROM documents WHERE id = ?', up.id).v, 'internal');           // lo del cliente nunca se comparte
  assert.equal((await v1.post(`/api/documents/${up.id}/link`)).status, 404);
  const big = await o.post(`/api/events/${ev}/documents`, { name: 'grande.pdf', mime: 'application/pdf', data_base64: Buffer.alloc(6 * 1024 * 1024, 65).toString('base64') });
  assert.equal(big.status, 413); assert.match(big.body.error.message, /5 MB/);
  assert.equal((await o.get('/api/me')).status, 200);                                                     // el servidor sigue sano
  ok(await v1.post('/api/vendor/documents', { name: 'seguro.pdf', kind: 'seguro', mime: 'application/pdf', data_base64: PDF }));
});

test('usuarios, catálogo y configuración', async () => {
  const sv = ok(await o.patch(`/api/catalog/services/${svc}`, { base_price_cents: 120000 })); assert.equal(sv.price_version, 2);
  assert.ok(w.row(`SELECT 1 x FROM audit_logs WHERE action = 'catalog.price_change'`));
  ok(await o.patch(`/api/catalog/services/${svc}`, { visible_to_client: false }));
  assert.ok(!(await c1.get('/api/catalog')).body.services.some((s: any) => s.id === svc));                // oculto para el cliente
  assert.equal((await c1.post(`/api/events/${ev}/requests`, { service_id: svc })).status, 404);
  const bad = await o.put('/api/settings/brand', { value: { color_accent: 'rojo' } }); assert.equal(bad.status, 422);
  assert.equal((await o.put('/api/settings/brand', { value: { logo_url: 'http://x.invalid/a.png' } })).status, 422);
  ok(await o.put('/api/settings/brand', { value: { name: 'Mi Marca', color_accent: '#112233', tagline: 'Eventos' } }));
  assert.equal((await new Api(w.base).get('/api/brand')).body.brand.name, 'Mi Marca');
  assert.equal((await o.put('/api/settings/inexistente', { value: {} })).status, 404);
  // permisos de colaboradores
  assert.equal((await o.patch(`/api/users/${w.ids.staffAll}`, { permissions: ['no.existe'] })).status, 422);
  ok(await o.patch(`/api/users/${w.ids.staffAll}`, { permissions: ['events.read_all', 'reports.view'] }));
  assert.equal((await (await w.login('all@test.invalid')).get('/api/reports/summary')).status, 200);
  assert.equal((await o.patch(`/api/users/${w.ids.c1}`, { permissions: ['events.write'] })).status, 422);   // clientes no tienen permisos
  assert.equal((await o.get('/api/audit?entity=user')).status, 200);
  assert.equal(ok(await o.get('/api/integrations')).integrations.every((i: any) => i.status === 'not_configured'), true);
  assert.equal((await new Api(w.base).req('POST', '/api/auth/accept-invite', { token: 'x'.repeat(20), password: PW, accept_privacy: true })).status, 400);
});

test('proveedor: disponibilidad, bloqueos y regla de «sin registro no es disponible»', async () => {
  ok(await v1.put('/api/vendor/availability', { date: '2027-11-01', status: 'unavailable' }));
  ok(await v1.post('/api/vendor/blackouts', { start_date: '2027-12-20', end_date: '2027-12-31', reason: 'Vacaciones' }));
  assert.equal((await v1.post('/api/vendor/blackouts', { start_date: '2027-12-31', end_date: '2027-12-20' })).status, 422);
  const prof = ok(await v1.get('/api/vendor/profile')); assert.ok(prof.availability.length >= 2 && prof.blackouts.length === 1);
  assert.ok(!JSON.stringify(prof).includes('tax_data') && !JSON.stringify(prof).includes('internal_notes'));
  const chk = (d: string) => o.get(`/api/vendors/${w.vendors.v1}/availability-check?date=${d}&start=10:00&end=12:00`).then((r) => r.body.state);
  assert.equal(await chk('2027-11-01'), 'unavailable'); assert.equal(await chk('2027-12-25'), 'unavailable'); assert.equal(await chk('2028-01-15'), 'unknown');
  const e3 = ok(await o.post('/api/events', { name: 'Bloqueado', type: 'boda', event_date: '2027-12-25' }));
  const r3 = ok(await o.post(`/api/events/${e3.id}/requests`, { service_id: svc })); ok(await o.post(`/api/requests/${r3.id}/status`, { to: 'in_review' }));
  const blocked = await o.post(`/api/requests/${r3.id}/assign`, { vendor_id: w.vendors.v1, start_time: '18:00', end_time: '22:00' });
  assert.equal(blocked.status, 409); assert.match(blocked.body.error.details.reasons.join(' '), /bloqueo/);   // la planner ve el motivo y decide
  assert.equal((await o.post(`/api/requests/${r3.id}/assign`, { vendor_id: w.vendors.v1, start_time: '18:00', end_time: '22:00', force: true })).status, 200);   // puede forzar y queda auditado
  assert.ok(w.row(`SELECT 1 x FROM audit_logs WHERE action = 'assignment.create' AND after_json LIKE '%"forced":true%'`));
});
