import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Api, PW, startWorld } from './helpers.ts';
import type { World } from './helpers.ts';
import { config } from '../../src/config.ts';
import { hmac } from '../../src/lib/crypto.ts';

let w: World;
before(async () => { config.storageDir = fs.mkdtempSync('/tmp/planner-flow-'); w = await startWorld(); });
after(() => w.close());
const ok = (r: { status: number; body: any }, code = 200) => { assert.equal(r.status, code, JSON.stringify(r.body)); return r.body; };

test('flujo completo: invitación → evento → solicitud → cotización → aprobación → proveedor → ejecución → pagos → cierre', async () => {
  const o = w.owner;
  // 1-3. La planner da de alta al cliente, lo invita; el cliente activa su cuenta e inicia sesión
  const client = ok(await o.post('/api/clients', { name: 'Ana y Luis', email: 'ana@flow.invalid' }));
  const inv = ok(await o.post('/api/users/invite', { email: 'ana@flow.invalid', role: 'client', client_id: client.id }));
  assert.equal(inv.email_status, 'queued_not_sent');           // sin proveedor de correo: no se afirma que se envió
  const tok = inv.invite_url.split('token=')[1];
  assert.equal((await new Api(w.base).req('POST', '/api/auth/accept-invite', { token: tok, password: PW, accept_privacy: false })).status, 422);
  ok(await new Api(w.base).req('POST', '/api/auth/accept-invite', { token: tok, password: PW, accept_privacy: true }));
  assert.equal((await new Api(w.base).req('POST', '/api/auth/accept-invite', { token: tok, password: PW, accept_privacy: true })).status, 400);   // el token no se reutiliza
  const cli = await w.login('ana@flow.invalid');

  // Evento con plantilla de tareas (fechas relativas)
  const tpl = (await o.get('/api/task-templates')).body.templates.find((t: any) => t.event_type === 'boda');
  const ev = ok(await o.post('/api/events', { name: 'Boda Ana y Luis', type: 'boda', event_date: '2027-06-12', start_time: '17:00', end_time: '23:30', client_id: client.id, template_id: tpl.id, guests_estimated: 100 }));
  assert.match(ev.folio, /^EV-2027-\d{4}$/);
  const tasks = ok(await o.get(`/api/events/${ev.id}/tasks`)).tasks; assert.equal(tasks.length, tpl.items.length);
  assert.equal(tasks.find((t: any) => t.title.startsWith('Pago del saldo')).due_date, '2027-06-05');
  // 4. El cliente guarda progreso parcial del asistente
  ok(await cli.put(`/api/events/${ev.id}/brief`, { data: { style: 'rústico', budget: 'medio' }, step: 4 }));
  assert.equal(w.row('SELECT brief_step s FROM events WHERE id = ?', ev.id).s, 4);

  // Catálogo → solicitudes del cliente
  const catId = (await o.get('/api/catalog')).body.categories[0].id;
  const banq = ok(await o.post('/api/catalog/services', { category_id: catId, name: 'Banquete', price_type: 'per_person', base_price_cents: 65000, vendor_id: w.vendors.v1, internal_notes: 'margen 30%' }));
  const dj = ok(await o.post('/api/catalog/services', { category_id: catId, name: 'DJ', price_type: 'per_hour', base_price_cents: 120000, vendor_id: w.vendors.v2 }));
  await o.post('/api/catalog/services', { category_id: catId, name: 'Servicio oculto', base_price_cents: 1, visible_to_client: false });
  const cat = (await cli.get('/api/catalog')).body.services;
  assert.deepEqual(cat.map((s: any) => s.name).sort(), ['Banquete', 'DJ']);          // el cliente no ve ocultos
  assert.ok(!JSON.stringify(cat).includes('margen 30%') && !JSON.stringify(cat).includes(w.vendors.v1));
  const rB = ok(await cli.post(`/api/events/${ev.id}/requests`, { service_id: banq.id, qty_milli: 100_000 }));
  const rD = ok(await cli.post(`/api/events/${ev.id}/requests`, { service_id: dj.id, qty_milli: 5_000 }));
  assert.equal((await cli.post(`/api/events/${ev.id}/requests`, { service_id: banq.id, qty_milli: 0 })).status, 422);
  assert.ok((await o.get('/api/notifications')).body.notifications.some((n: any) => n.type === 'request_new'));

  // 5-6. La planner revisa, fija precios, y envía versión 1 de la propuesta
  for (const r of [rB, rD]) ok(await o.post(`/api/requests/${r.id}/status`, { to: 'in_review' }));
  ok(await o.patch(`/api/requests/${rB.id}`, { discount_cents: 500_000 }));
  for (const s of ['initial_consult', 'preparing']) ok(await o.post(`/api/events/${ev.id}/status`, { to: s }));
  assert.equal((await o.post(`/api/events/${ev.id}/status`, { to: 'confirmed' })).status, 409);       // transición inválida
  const v1 = ok(await o.post(`/api/events/${ev.id}/quote/versions`, {}));
  assert.equal(v1.total_cents, 7_656_000); assert.equal(v1.tax_cents, 1_056_000); assert.equal(v1.advance_cents, 3_828_000);
  assert.equal(w.row('SELECT status FROM events WHERE id = ?', ev.id).status, 'proposal_sent');
  assert.equal((await o.post(`/api/events/${ev.id}/status`, { to: 'contracted' })).status, 409);        // aún sin aceptación
  assert.equal(w.row('SELECT status FROM service_requests WHERE id = ?', rB.id).status, 'quote_sent');
  // El cliente NO puede dar por contratado un servicio con el clic: solo acepta la versión vigente
  assert.equal((await cli.post(`/api/events/${ev.id}/quote/respond`, { version: 2, accept: true })).status, 404);
  ok(await cli.post(`/api/events/${ev.id}/quote/respond`, { version: 1, accept: true }));
  assert.equal(w.row('SELECT status FROM service_requests WHERE id = ?', rB.id).status, 'client_approved');   // no «confirmado»
  assert.equal((await cli.post(`/api/events/${ev.id}/quote/respond`, { version: 1, accept: true })).status, 409);
  for (const s of ['contracted', 'planning']) ok(await o.post(`/api/events/${ev.id}/status`, { to: s }));
  // Cambio de precio posterior a la aprobación: exige motivo y genera nueva versión con nueva aceptación
  assert.equal((await o.patch(`/api/requests/${rD.id}`, { unit_price_cents: 130000 })).status, 422);
  ok(await o.patch(`/api/requests/${rD.id}`, { unit_price_cents: 130000, reason: 'Ajuste por horario extendido' }));
  const v2 = ok(await o.post(`/api/events/${ev.id}/quote/versions`, {}));
  assert.equal(v2.version, 2); assert.equal(v2.total_cents, 7_656_000 + Math.round(5 * 10000 * 1.16));
  assert.equal(w.row(`SELECT status FROM quote_versions WHERE quote_id = (SELECT id FROM quotes WHERE event_id = ?) AND version = 1`, ev.id).status, 'superseded');
  ok(await cli.post(`/api/events/${ev.id}/quote/respond`, { version: 2, accept: true }));
  const bal0 = ok(await cli.get(`/api/events/${ev.id}/balance`)); assert.equal(bal0.contracted_cents, v2.total_cents);
  assert.ok(!('cost_cents' in bal0) && !JSON.stringify(bal0).includes('margin'));

  // 8-10. Disponibilidad, solicitud al proveedor, aceptación, confirmación
  const vend1 = await (async () => { const inv2 = ok(await o.post('/api/users/invite', { email: 'v1@test.invalid', role: 'vendor', vendor_id: w.vendors.v1 }).catch(() => ({ status: 0, body: {} } as any)).then((r: any) => r) ) ; return inv2; })().catch(() => null);
  void vend1;
  const vendor1 = await w.login('v1@test.invalid'), vendor2 = await w.login('v2@test.invalid');
  const unknown = ok(await o.get(`/api/vendors/${w.vendors.v1}/availability-check?date=2027-06-12&start=17:00&end=23:00`));
  assert.equal(unknown.state, 'unknown');                                                              // sin registro explícito no se asume disponible
  for (const vid of [w.vendors.v1, w.vendors.v2]) ok(await o.put(`/api/vendors/${vid}/availability`, { date: '2027-06-12', status: 'available' }));
  const a1 = ok(await o.post(`/api/requests/${rB.id}/assign`, { vendor_id: w.vendors.v1, cost_cents: 4_000_000, start_time: '17:00', end_time: '23:00', arrival_time: '14:00', location_visible: true, location_detail: 'Hacienda Demo, acceso norte', instructions: 'Montaje de mesas en jardín', checklist: [{ phase: 'prep', text: 'Verificar menú' }, { phase: 'exec', text: 'Servicio de entrada' }, { phase: 'teardown', text: 'Retirar equipo' }] }));
  const a2 = ok(await o.post(`/api/requests/${rD.id}/assign`, { vendor_id: w.vendors.v2, cost_cents: 400_000, start_time: '19:00', end_time: '23:00' }));
  assert.equal((await o.post(`/api/assignments/${a1.id}/status`, { to: 'confirmed' })).status, 409);   // el proveedor aún no acepta
  assert.ok((await vendor1.get('/api/notifications')).body.notifications.some((n: any) => n.type === 'assignment_request' && !JSON.stringify(n).includes('Ana') ));
  // Rechazo → vuelve a revisión y avisa a la planner
  assert.equal((await vendor2.post(`/api/vendor/assignments/${a2.id}/respond`, { accept: false })).status, 422);
  ok(await vendor2.post(`/api/vendor/assignments/${a2.id}/respond`, { accept: false, reason: 'Fecha cruzada' }));
  assert.equal(w.row('SELECT status FROM service_requests WHERE id = ?', rD.id).status, 'in_review');
  assert.ok((await o.get('/api/notifications')).body.notifications.some((n: any) => n.type === 'assignment_rejected' && n.priority === 'high'));
  // Se reasigna y esta vez acepta
  const a2b = ok(await o.post(`/api/requests/${rD.id}/assign`, { vendor_id: w.vendors.v2, cost_cents: 400_000, start_time: '19:00', end_time: '23:00' }));
  for (const [vc, id] of [[vendor1, a1.id], [vendor2, a2b.id]] as const) { ok(await vc.post(`/api/vendor/assignments/${id}/respond`, { accept: true })); ok(await o.post(`/api/assignments/${id}/status`, { to: 'confirmed' })); }
  assert.equal(w.row('SELECT status FROM service_requests WHERE id = ?', rB.id).status, 'confirmed');
  ok(await o.post(`/api/events/${ev.id}/status`, { to: 'confirmed' }));
  // Cronograma: advierte conflictos pero decide la planner; confirmado se bloquea
  const t1 = ok(await o.post(`/api/events/${ev.id}/timeline`, { item_date: '2027-06-12', start_time: '14:00', end_time: '16:00', title: 'Montaje banquete', assignment_id: a1.id }));
  const t2 = ok(await o.post(`/api/events/${ev.id}/timeline`, { item_date: '2027-06-12', start_time: '15:00', end_time: '17:00', title: 'Montaje mesas', assignment_id: a1.id }));
  assert.ok(t2.alerts.some((a: any) => a.type === 'overlap_vendor'));
  assert.equal((await o.patch(`/api/timeline/${t1.id}`, { start_time: '13:00' })).status, 409);       // confirmado: exige motivo
  ok(await o.patch(`/api/timeline/${t1.id}`, { start_time: '13:00', reason: 'El recinto abre antes' }));
  assert.ok(w.row(`SELECT 1 x FROM audit_logs WHERE action = 'timeline.change_confirmed'`));
  assert.ok((await vendor1.get('/api/notifications')).body.notifications.some((n: any) => n.type === 'schedule_change'));

  // 11-12. El proveedor ve instrucciones, completa checklist y confirma llegada/inicio/fin
  const det = ok(await vendor1.get(`/api/vendor/assignments/${a1.id}`));
  assert.equal(det.checklist.length, 3); assert.equal(det.assignment.instructions, 'Montaje de mesas en jardín');
  for (const it of det.checklist) ok(await vendor1.post(`/api/vendor/checklist/${it.id}/toggle`));
  assert.equal((await vendor1.post(`/api/vendor/assignments/${a1.id}/finish`)).status, 409);          // antes de iniciar
  for (const s of ['arrive', 'start', 'finish']) ok(await vendor1.post(`/api/vendor/assignments/${a1.id}/${s}`));
  assert.equal(w.row('SELECT status FROM service_assignments WHERE id = ?', a1.id).status, 'completed');
  assert.equal(w.row('SELECT status FROM service_requests WHERE id = ?', rB.id).status, 'completed');
  ok(await vendor1.post(`/api/vendor/assignments/${a1.id}/incidents`, { description: 'Retraso de 15 min por acceso', severity: 'low' }));
  ok(await vendor2.post(`/api/vendor/assignments/${a2b.id}/arrive`));
  ok(await vendor2.post(`/api/vendor/assignments/${a2b.id}/start`)); ok(await vendor2.post(`/api/vendor/assignments/${a2b.id}/finish`));

  // 14. Pagos, gastos y cifras exactas
  const total = v2.total_cents;
  const p1 = ok(await o.post(`/api/events/${ev.id}/payments`, { direction: 'in', client_id: client.id, amount_cents: 3_828_000, concept: 'Anticipo', due_date: '2027-01-10', idempotency_key: 'anticipo-0001' }));
  const dup = ok(await o.post(`/api/events/${ev.id}/payments`, { direction: 'in', client_id: client.id, amount_cents: 3_828_000, concept: 'Anticipo', idempotency_key: 'anticipo-0001' }));
  assert.equal(dup.duplicate, true); assert.equal(w.row('SELECT COUNT(*) n FROM payments WHERE event_id = ?', ev.id).n, 1);
  assert.equal(ok(await o.get(`/api/events/${ev.id}/finance`)).summary.collectedRegistered, 0);         // pendiente no cuenta como cobrado
  ok(await o.post(`/api/payments/${p1.id}/status`, { to: 'paid' }));
  const p2 = ok(await o.post(`/api/events/${ev.id}/payments`, { direction: 'in', client_id: client.id, amount_cents: total - 3_828_000, concept: 'Saldo', idempotency_key: 'saldo-0001' }));
  ok(await o.patch(`/api/assignments/${a1.id}`, { actual_cost_cents: 4_000_000 }));
  const f1 = ok(await o.get(`/api/events/${ev.id}/finance`)).summary;
  assert.equal(f1.clientBalance, total - 3_828_000); assert.equal(f1.collectedVerified, 0);                // manual ≠ verificado
  // Intento de cerrar con saldo: bloqueado
  for (const s of ['in_execution', 'finished']) ok(await o.post(`/api/events/${ev.id}/status`, { to: s }));
  const blocked = await o.post(`/api/events/${ev.id}/status`, { to: 'closed' }); assert.equal(blocked.status, 409); assert.ok(blocked.body.error.details.blockers.length >= 2);
  ok(await o.post(`/api/payments/${p2.id}/status`, { to: 'paid' }));
  for (const [vid, amt, key] of [[w.vendors.v1, 4_000_000, 'prov1-0001'], [w.vendors.v2, 400_000, 'prov2-0001']] as const) { const p = ok(await o.post(`/api/events/${ev.id}/payments`, { direction: 'out', vendor_id: vid, amount_cents: amt, idempotency_key: key })); ok(await o.post(`/api/payments/${p.id}/status`, { to: 'paid' })); }
  ok(await o.post(`/api/events/${ev.id}/expenses`, { description: 'Transporte de equipo', amount_cents: 50_000, expense_date: '2027-06-12' }));
  ok(await o.post(`/api/incidents/${w.row('SELECT id FROM incidents LIMIT 1').id}/status`, { to: 'resolved', resolution: 'Se ajustó el acceso' }));
  const f2 = ok(await o.get(`/api/events/${ev.id}/finance`)).summary;
  assert.equal(f2.clientBalance, 0); assert.equal(f2.vendorOwed, 0);
  assert.equal(f2.revenueNet, total - v2.tax_cents); assert.equal(f2.realCost, 4_450_000);
  assert.equal(f2.finalProfit, total - v2.tax_cents - 4_450_000);
  ok(await o.post(`/api/events/${ev.id}/status`, { to: 'closed' }));
  assert.ok(w.row('SELECT closed_at FROM events WHERE id = ?', ev.id).closed_at);
  assert.equal((await o.post(`/api/events/${ev.id}/status`, { to: 'planning' })).status, 409);
  // Persistencia: el cliente vuelve a entrar y sigue viendo sus datos
  await cli.post('/api/auth/logout'); assert.equal((await cli.get('/api/me')).body.user, null);
  const again = await w.login('ana@flow.invalid'); assert.equal((await again.get(`/api/events/${ev.id}`)).body.event.name, 'Boda Ana y Luis');
  assert.equal((await again.get(`/api/events/${ev.id}`)).body.event.brief_step, 4);
  // Auditoría registró lo importante
  const acts = new Set(w.db.all('SELECT action FROM audit_logs').map((r) => r.action));
  for (const a of ['event.create', 'event.status', 'quote.version', 'quote.accept', 'request.price_change', 'assignment.create', 'payment.create', 'payment.status']) assert.ok(acts.has(a), a);
});

test('pagos por pasarela: webhook autenticado, idempotente y sin confirmar con firma inválida', async () => {
  const o = w.owner;
  const ev = (await o.post('/api/events', { name: 'Evento pasarela', type: 'cumpleaños', client_id: w.clients.c1 })).body;
  const p = ok(await o.post(`/api/events/${ev.id}/payments`, { direction: 'in', client_id: w.clients.c1, amount_cents: 100_000, idempotency_key: 'pasarela-0001' }));
  const send = (body: object, sig?: string) => { const raw = JSON.stringify(body); return new Api(w.base).req('POST', '/api/webhooks/gateway', undefined, { rawBody: raw, headers: { 'content-type': 'application/json', 'x-signature': sig ?? hmac('secreto-de-prueba', raw) } }); };
  assert.equal((await send({ id: 'evt_1', type: 'payment.succeeded', payment_id: p.id, amount_cents: 100_000 })).status, 503);   // no configurada → no confirma nada
  config.gatewayWebhookSecret = 'secreto-de-prueba';
  try {
    assert.equal((await send({ id: 'evt_1', type: 'payment.succeeded', payment_id: p.id, amount_cents: 100_000 }, 'deadbeef')).status, 401);
    assert.equal(w.row('SELECT status, verified FROM payments WHERE id = ?', p.id).status, 'pending');
    assert.equal((await send({ id: 'evt_1', type: 'payment.succeeded', payment_id: p.id, amount_cents: 40_000 })).status, 200);
    assert.equal((await send({ id: 'evt_1', type: 'payment.succeeded', payment_id: p.id, amount_cents: 40_000 })).body.duplicate, true);   // repetición
    const row = w.row('SELECT status, paid_cents, verified, source FROM payments WHERE id = ?', p.id);
    assert.deepEqual({ ...row }, { status: 'partially_paid', paid_cents: 40_000, verified: 1, source: 'gateway' });
    assert.equal((await send({ id: 'evt_2', type: 'payment.succeeded', payment_id: p.id, amount_cents: 60_000 })).status, 200);
    assert.equal(w.row('SELECT status FROM payments WHERE id = ?', p.id).status, 'paid');
    assert.equal(w.row('SELECT COUNT(*) n FROM payment_transactions WHERE payment_id = ?', p.id).n, 2);
    assert.equal((await o.post(`/api/payments/${p.id}/status`, { to: 'cancelled' })).status, 403);   // verificado: no se edita a mano
    assert.equal(w.row('SELECT COUNT(*) n FROM webhook_events WHERE status = ?', 'rejected').n, 1);
  } finally { config.gatewayWebhookSecret = ''; }
});
