import http from 'node:http';
import { createApp } from '../../src/app.ts';
import { config } from '../../src/config.ts';
import { bootstrapOrg } from '../../src/seed.ts';
import { hashPassword } from '../../src/lib/crypto.ts';
import { uid } from '../../src/lib/db.ts';
import type { Db } from '../../src/lib/db.ts';

export const PW = 'Contrasena-Segura-2026';
export interface Res { status: number; body: any; headers: Headers }

export class Api {
  base: string; cookie = '';
  constructor(base: string) { this.base = base; }
  async req(method: string, path: string, body?: unknown, o: { csrf?: boolean; headers?: Record<string, string>; rawBody?: string } = {}): Promise<Res> {
    const headers: Record<string, string> = { ...(o.headers ?? {}) };
    if (o.csrf !== false) headers['x-requested-with'] = 'fetch';
    if (this.cookie) headers.cookie = this.cookie;
    let payload: string | undefined = o.rawBody;
    if (payload === undefined && body !== undefined) { payload = JSON.stringify(body); headers['content-type'] = 'application/json'; }
    const r = await fetch(this.base + path, { method, headers, body: payload });
    const sc = (r.headers as any).getSetCookie?.() as string[] | undefined;
    if (sc?.length) { const m = sc[0].match(/^sid=([^;]*)/); if (m) this.cookie = m[1] ? `sid=${m[1]}` : ''; }
    const text = await r.text(); let parsed: any = text; try { parsed = JSON.parse(text); } catch { /* texto plano */ }
    return { status: r.status, body: parsed, headers: r.headers };
  }
  get = (p: string) => this.req('GET', p);
  post = (p: string, b?: unknown) => this.req('POST', p, b ?? {});
  patch = (p: string, b: unknown) => this.req('PATCH', p, b);
  put = (p: string, b: unknown) => this.req('PUT', p, b);
  async login(email: string, password = PW) { const r = await this.post('/api/auth/login', { email, password }); if (r.status !== 200) throw new Error(`login ${email}: ${r.status} ${JSON.stringify(r.body)}`); return r; }
}

export async function startWorld() {
  const { db, handler } = createApp(':memory:');
  const server = http.createServer(handler);
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
  const base = `http://127.0.0.1:${(server.address() as any).port}`;
  config.gatewayWebhookSecret = '';
  const { orgId, ownerId } = await bootstrapOrg(db, { orgName: 'Planner de prueba', ownerEmail: 'owner@test.invalid', ownerName: 'Dueña', ownerPassword: PW });
  const mk = async (role: string, email: string, perms: string[] = []) => { const id = uid(); db.run('INSERT INTO users (id, org_id, email, password_hash, display_name, role, permissions) VALUES (?,?,?,?,?,?,?)', id, orgId, email, await hashPassword(PW), email.split('@')[0], role, JSON.stringify(perms)); return id; };
  const ids = {
    staffLogi: await mk('staff', 'logi@test.invalid', ['events.write', 'logistics.manage', 'documents.manage']),     // sin finanzas, sin events.read_all
    staffAll: await mk('staff', 'all@test.invalid', ['events.read_all', 'events.write', 'finance.view']),
    c1: await mk('client', 'c1@test.invalid'), c2: await mk('client', 'c2@test.invalid'),
    v1: await mk('vendor', 'v1@test.invalid'), v2: await mk('vendor', 'v2@test.invalid'),
  };
  const row = (sql: string, ...p: any[]) => db.get(sql, ...p)!;
  const clients = { c1: uid(), c2: uid() }; const vendors = { v1: uid(), v2: uid() };
  db.run('INSERT INTO clients (id, org_id, user_id, name) VALUES (?,?,?,?)', clients.c1, orgId, ids.c1, 'Cliente Uno Secreto'); db.run('INSERT INTO clients (id, org_id, user_id, name) VALUES (?,?,?,?)', clients.c2, orgId, ids.c2, 'Cliente Dos');
  db.run(`INSERT INTO vendors (id, org_id, user_id, business_name, status, setup_minutes, teardown_minutes) VALUES (?,?,?,?,?,60,30)`, vendors.v1, orgId, ids.v1, 'Proveedor Uno', 'active');
  db.run(`INSERT INTO vendors (id, org_id, user_id, business_name, status) VALUES (?,?,?,?,?)`, vendors.v2, orgId, ids.v2, 'Proveedor Dos', 'active');
  const owner = new Api(base); await owner.login('owner@test.invalid');
  const login = async (email: string) => { const a = new Api(base); await a.login(email); return a; };
  return { db: db as Db, base, orgId, ownerId, ids, clients, vendors, owner, login, row, close: () => { server.close(); db.close(); } };
}
export type World = Awaited<ReturnType<typeof startWorld>>;
