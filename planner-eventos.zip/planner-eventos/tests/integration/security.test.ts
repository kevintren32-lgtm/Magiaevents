import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Api, PW, startWorld } from './helpers.ts';
import type { World } from './helpers.ts';
import { config } from '../../src/config.ts';
import { hmac } from '../../src/lib/crypto.ts';
import { signDownload } from '../../src/lib/crypto.ts';

let w: World; let evA: string, evB: string; let c1: Api, c2: Api, v1: Api, v2: Api, logi: Api, all: Api; let asgA: string;
const PDF = Buffer.from('%PDF-1.4\n%demo\n').toString('base64');

before(async () => {
  config.storageDir = fs.mkdtempSync('/tmp/planner-test-');
  w = await startWorld();
  const mkEv = async (name: string, client: string, date: string) => (await w.owner.post('/api/events', { name, type: 'boda', event_date: date, client_id: client })).body.id as string;
  evA = await mkEv('Evento A', w.clients.c1, '2027-06-12'); evB = await mkEv('Evento B', w.clients.c2, '2027-07-10');
  [c1, c2, v1, v2, logi, all] = await Promise.all(['c1', 'c2', 'v1', 'v2', 'logi', 'all'].map((n) => w.login(`${n}@test.invalid`)));
  // Asignación de v1 en evento A (por la planner)
  const cat = (await w.owner.get('/api/catalog')).body.categories[0].id;
  const svc = (await w.owner.post('/api/catalog/services', { category_id: cat, name: 'Banquete', price_type: 'per_person', base_price_cents: 65000, vendor_id: w.vendors.v1 })).body.id;
  const rq = (await w.owner.post(`/api/events/${evA}/requests`, { service_id: svc, qty_milli: 50_000 })).body.id;
  assert.equal((await w.owner.post(`/api/requests/${rq}/status`, { to: 'in_review' })).status, 200);
  await w.owner.put(`/api/vendors/${w.vendors.v1}/availability`, { date: '2027-06-12', status: 'available' });
  const a = await w.owner.post(`/api/requests/${rq}/assign`, { vendor_id: w.vendors.v1, cost_cents: 100000, start_time: '17:00', end_time: '23:00', instructions: 'Entrada de servicio', location_visible: true, location_detail: 'Salón Principal' });
  assert.equal(a.status, 200, JSON.stringify(a.body)); asgA = a.body.id;
});
after(() => w.close());

test('sin sesión no se accede a nada privado (401) y los endpoints no filtran información', async () => {
  const anon = new Api(w.base);
  for (const p of ['/api/events', `/api/events/${evA}`, '/api/users', '/api/vendor/assignments', `/api/events/${evA}/payments`, '/api/dashboard', '/api/audit'])
    assert.equal((await anon.get(p)).status, 401, p);
});
test('/api/me anónimo no revela nada: usuario nulo', async () => {
  const r = await new Api(w.base).get('/api/me'); assert.equal(r.status, 200); assert.deepEqual(r.body, { user: null });
});
test('CSRF: una mutación sin la cabecera de seguridad es rechazada', async () => {
  const r = await w.owner.req('POST', '/api/clients', { name: 'X' }, { csrf: false });
  assert.equal(r.status, 403);
});
test('cliente: cambiar el identificador del evento devuelve 404 en todos los recursos', async () => {
  for (const p of [`/api/events/${evB}`, `/api/events/${evB}/requests`, `/api/events/${evB}/quote`, `/api/events/${evB}/payments`, `/api/events/${evB}/documents`, `/api/events/${evB}/tasks`, `/api/events/${evB}/timeline`, `/api/events/${evB}/guests`, `/api/events/${evB}/balance`])
    assert.equal((await c1.get(p)).status, 404, p);
  const list = (await c1.get('/api/events')).body.events.map((e: any) => e.id);
  assert.deepEqual(list, [evA]);
  assert.equal((await c1.post(`/api/events/${evB}/requests`, { service_id: '00000000-0000-0000-0000-000000000000' })).status, 404);
  assert.equal((await c1.post(`/api/events/${evB}/guests`, { name: 'Intruso' })).status, 404);
});
test('cliente: no puede ver finanzas internas, editar precios, estados, ni administrar', async () => {
  assert.equal((await c1.get(`/api/events/${evA}/finance`)).status, 403);
  assert.equal((await c1.get('/api/users')).status, 403);
  assert.equal((await c1.get('/api/vendors')).status, 403);
  assert.equal((await c1.get('/api/audit')).status, 403);
  assert.equal((await c1.post(`/api/events/${evA}/status`, { to: 'contracted' })).status, 403);
  assert.equal((await c1.patch(`/api/events/${evA}`, { name: 'Hack' })).status, 403);
  assert.equal((await c1.post(`/api/events/${evA}/quote/versions`, {})).status, 403);
  const rid = (await c1.get(`/api/events/${evA}/requests`)).body.requests[0].id;
  assert.equal((await c1.patch(`/api/requests/${rid}`, { unit_price_cents: 1 })).status, 403);
  assert.equal((await c1.post(`/api/requests/${rid}/status`, { to: 'confirmed' })).status, 403);
  const view = (await c1.get(`/api/events/${evA}`)).body.event;
  assert.equal('notes_internal' in view, false); assert.equal('planner_id' in view, false);
  assert.equal('planner_notes' in (await c1.get(`/api/events/${evA}/requests`)).body.requests[0], false);
});
test('un usuario no puede cambiar su propio rol ni otros campos por asignación masiva', async () => {
  await c1.patch('/api/me', { display_name: 'Nuevo nombre', role: 'owner', permissions: ['finance.manage'], org_id: 'x' });
  const me = (await c1.get('/api/me')).body.user;
  assert.equal(me.role, 'client'); assert.deepEqual(me.permissions, []);
  assert.equal(w.row('SELECT role FROM users WHERE id = ?', w.ids.c1).role, 'client');
  const mine = await c1.post('/api/my/events', { name: 'Mi evento', type: 'cumpleaños', status: 'confirmed', planner_id: w.ownerId, budget_approved_cents: 999 });
  assert.equal(mine.status, 200); assert.equal(mine.body.status, 'prospect'); assert.equal(mine.body.budget_approved_cents, null);
});
test('proveedor: solo ve su asignación, sin costos, cliente ni nombre del evento', async () => {
  const mineList = (await v1.get('/api/vendor/assignments')).body.assignments;
  assert.equal(mineList.length, 1);
  const detail = await v1.get(`/api/vendor/assignments/${asgA}`);
  assert.equal(detail.status, 200);
  const text = JSON.stringify(detail.body);
  for (const secret of ['Cliente Uno Secreto', 'Evento A', 'cost_cents', 'actual_cost_cents', 'planner_notes', 'Proveedor Dos']) assert.ok(!text.includes(secret), `filtración: ${secret}`);
  assert.equal(detail.body.assignment.location, 'Salón Principal');
  assert.equal((await v2.get(`/api/vendor/assignments/${asgA}`)).status, 404);
  assert.equal((await v2.post(`/api/vendor/assignments/${asgA}/respond`, { accept: true })).status, 404);
  assert.equal((await v2.get('/api/vendor/assignments')).body.assignments.length, 0);
});
test('proveedor: sin acceso a eventos, catálogo interno, proveedores, finanzas ni clientes', async () => {
  for (const p of [`/api/events/${evA}`, '/api/catalog', '/api/vendors', '/api/clients', `/api/events/${evA}/payments`, `/api/events/${evA}/finance`, '/api/reports/summary', '/api/users'])
    assert.ok([403, 404].includes((await v1.get(p)).status), p);
  assert.deepEqual((await v1.get('/api/events')).body.events, []);
});
test('colaborador sin permiso financiero o sin asignación al evento no accede', async () => {
  assert.equal((await logi.get(`/api/events/${evA}/payments`)).status, 404);   // aún no está asignado a A: ni siquiera sabe que existe
  w.db.run('INSERT INTO event_staff (event_id, user_id) VALUES (?,?)', evA, w.ids.staffLogi);
  assert.equal((await logi.get(`/api/events/${evA}/finance`)).status, 403);
  assert.equal((await logi.get(`/api/events/${evA}/payments`)).status, 403);
  assert.equal((await logi.get(`/api/events/${evB}`)).status, 404);      // no está asignado a B ni tiene events.read_all
  assert.equal((await all.get(`/api/events/${evB}`)).status, 200);        // este sí tiene events.read_all
  assert.equal((await logi.get('/api/users')).status, 403);
  assert.equal((await logi.get('/api/audit')).status, 403);
});
test('no hay canal cliente↔proveedor: las conversaciones son siempre con la planner', async () => {
  const mine = await c1.post('/api/conversations', { subject: 'Hola', body: 'Hola planner', participant_user_id: w.ids.v1 });  // intento de apuntar a un proveedor
  assert.equal(mine.status, 200);
  const cv = w.row('SELECT * FROM conversations WHERE id = ?', mine.body.id);
  assert.equal(cv.participant_user_id, w.ids.c1); assert.equal(cv.kind, 'client');
  assert.equal((await v1.get(`/api/conversations/${mine.body.id}/messages`)).status, 404);
  assert.equal((await v1.post(`/api/conversations/${mine.body.id}/messages`, { body: 'intruso' })).status, 404);
  assert.equal((await c2.get(`/api/conversations/${mine.body.id}/messages`)).status, 404);
  assert.equal((await w.owner.get(`/api/conversations/${mine.body.id}/messages`)).status, 200);
  const notif = (await w.owner.get('/api/notifications')).body.notifications.find((n: any) => n.type === 'message');
  assert.ok(notif && !JSON.stringify(notif).includes('Hola planner'), 'la notificación no debe incluir el contenido');
});
test('documentos: almacenamiento privado, validación, visibilidad y enlaces temporales atados al usuario', async () => {
  assert.equal((await w.owner.post(`/api/events/${evA}/documents`, { name: 'x.exe', mime: 'application/x-msdownload', data_base64: PDF })).status, 422);
  assert.equal((await w.owner.post(`/api/events/${evA}/documents`, { name: 'falso.pdf', mime: 'application/pdf', data_base64: Buffer.from('MZ nope').toString('base64') })).status, 422);   // magic bytes
  const internal = (await w.owner.post(`/api/events/${evA}/documents`, { name: 'contrato-interno.pdf', mime: 'application/pdf', data_base64: PDF, visibility: 'internal' })).body.id;
  const forClient = (await w.owner.post(`/api/events/${evA}/documents`, { name: 'cotizacion.pdf', mime: 'application/pdf', data_base64: PDF, visibility: 'client' })).body.id;
  const forV1 = (await w.owner.post(`/api/events/${evA}/documents`, { name: 'plano.pdf', mime: 'application/pdf', data_base64: PDF, visibility: 'vendor', vendor_ids: [w.vendors.v1] })).body.id;
  assert.equal((await w.owner.post(`/api/events/${evA}/documents`, { name: 'p.pdf', mime: 'application/pdf', data_base64: PDF, visibility: 'vendor', vendor_ids: [w.vendors.v2] })).status, 422);   // v2 no está asignado
  assert.deepEqual((await c1.get(`/api/events/${evA}/documents`)).body.documents.map((d: any) => d.id), [forClient]);
  assert.equal((await c1.post(`/api/documents/${internal}/link`)).status, 404);
  assert.equal((await c2.post(`/api/documents/${forClient}/link`)).status, 404);
  assert.equal((await v2.post(`/api/documents/${forV1}/link`)).status, 404);
  const link = await v1.post(`/api/documents/${forV1}/link`); assert.equal(link.status, 200);
  assert.equal((await v1.get(link.body.url)).status, 200);
  assert.equal((await v2.get(link.body.url)).status, 404);                          // el enlace no sirve a otro usuario
  assert.equal((await v1.get(link.body.url.replace(/sig=[0-9a-f]{4}/, 'sig=0000'))).status, 404);   // firma manipulada
  const expired = `/api/documents/${forV1}/download?${signDownload(forV1, w.ids.v1, 120, Date.now() - 600_000)}`;
  assert.equal((await v1.get(expired)).status, 404);                                // enlace caducado
  assert.equal((await v1.get(`/api/documents/${forV1}/download`)).status, 404);     // sin firma
  const key = w.row('SELECT storage_key FROM documents WHERE id = ?', internal).storage_key; assert.ok(key.length >= 32 && !key.includes(internal));
});
test('cuenta desactivada: la sesión activa deja de funcionar de inmediato', async () => {
  const victim = await w.login('v2@test.invalid');
  assert.equal((await victim.get('/api/vendor/assignments')).status, 200);
  assert.equal((await w.owner.patch(`/api/users/${w.ids.v2}`, { status: 'disabled' })).status, 200);
  assert.equal((await victim.get('/api/vendor/assignments')).status, 401);
  assert.equal((await new Api(w.base).req('POST', '/api/auth/login', { email: 'v2@test.invalid', password: PW })).status, 401);
});
test('auditoría y ajustes financieros son de solo anexado (la base los protege)', async () => {
  assert.equal((await w.owner.post(`/api/events/${evA}/adjustments`, { kind: 'client_charge', amount_cents: 1000, reason: 'Cargo de prueba' })).status, 200);
  assert.throws(() => w.db.run('UPDATE audit_logs SET action = ?', 'x'), /solo anexado/);
  assert.throws(() => w.db.run('DELETE FROM audit_logs'), /solo anexado/);
  assert.throws(() => w.db.run('DELETE FROM financial_adjustments'), /solo anexado/);
  assert.throws(() => w.db.run('UPDATE financial_adjustments SET amount_cents = 1'), /solo anexado/);
  assert.ok(w.row('SELECT COUNT(*) n FROM audit_logs').n > 0);
});
test('un colaborador no puede otorgar permisos que no tiene ni modificar a la propietaria', async () => {
  const mgr = await w.login('all@test.invalid');
  assert.equal((await mgr.patch(`/api/users/${w.ownerId}`, { status: 'disabled' })).status, 403);
  assert.equal((await mgr.get('/api/users')).status, 403);   // ni siquiera tiene users.manage
});
void hmac;

test('archivos estáticos: sin salida de la carpeta pública y con cabeceras de seguridad', async () => {
  for (const path of ['/..%2f..%2fpackage.json', '/%2e%2e/%2e%2e/package.json', '/..%5c..%5cpackage.json', '/js/../../package.json', '/%00']) {
    const r = await fetch(w.base + path); const t = await r.text();
    assert.ok(!t.includes('"planner-eventos"') && !t.includes('migrate'), `se sirvió contenido fuera de public: ${path}`);
  }
  const r = await fetch(w.base + '/'); assert.match(r.headers.get('content-security-policy') ?? '', /script-src 'self'/); assert.equal(r.headers.get('x-frame-options'), 'DENY'); assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal((await new Api(w.base).get('/api/ruta-inexistente')).status, 404);
  const bad = await new Api(w.base).req('POST', '/api/auth/login', undefined, { rawBody: '{no es json', headers: { 'content-type': 'application/json' } }); assert.equal(bad.status, 400);
});
test('concurrencia: 25 pagos simultáneos con la misma clave de idempotencia crean un solo cobro', async () => {
  const ev2 = (await w.owner.post('/api/events', { name: 'Concurrencia', type: 'boda', client_id: w.clients.c1 })).body.id;
  const body = { direction: 'in', client_id: w.clients.c1, amount_cents: 12345, idempotency_key: 'misma-clave-001' };
  const rs = await Promise.all(Array.from({ length: 25 }, () => w.owner.post(`/api/events/${ev2}/payments`, body)));
  assert.ok(rs.every((r) => r.status === 200)); assert.equal(w.row('SELECT COUNT(*) n FROM payments WHERE event_id = ?', ev2).n, 1);
  assert.equal(new Set(rs.map((r) => r.body.id)).size, 1);
});
