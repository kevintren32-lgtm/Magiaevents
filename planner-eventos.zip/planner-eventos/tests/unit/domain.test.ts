import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mulDivRound, lineAmount, taxOf, parseMoney } from '../../src/domain/money.ts';
import { computeQuote, computeEventFinancials } from '../../src/domain/finance.ts';
import { canTransition, EVENT_TRANSITIONS, REQUEST_TRANSITIONS, ASSIGNMENT_TRANSITIONS } from '../../src/domain/states.ts';
import { checkAvailability } from '../../src/domain/availability.ts';
import { detectConflicts } from '../../src/domain/timeline.ts';

test('redondeo monetario mitad hacia arriba, sin flotantes', () => {
  assert.equal(mulDivRound(5, 1, 2), 3);        // 2.5 -> 3
  assert.equal(mulDivRound(-5, 1, 2), -3);      // -2.5 -> -3 (lejos de cero)
  assert.equal(mulDivRound(1, 1, 3), 0);
  assert.equal(taxOf(10001, 1600), 1600);       // 1600.16 -> 1600
  assert.equal(taxOf(10003, 1600), 1600);       // 1600.48 -> 1600
  assert.equal(taxOf(10005, 1600), 1601);       // 1600.80 -> 1601
});
test('IVA 16% de 0.10+0.20 no sufre error de flotante', () => {
  assert.equal(lineAmount(10, 1000) + lineAmount(20, 1000), 30);
  assert.equal(parseMoney('1,234.50'), 123450);
  assert.throws(() => parseMoney('12.345'));
});
test('cotización: líneas, descuento, cargos, IVA y anticipo', () => {
  const q = computeQuote([
    { description: 'Banquete', qtyMilli: 100_000, unitPriceCents: 45_000, discountCents: 100_000, taxBps: 1600 },   // 100 personas x $450
    { description: 'DJ', qtyMilli: 5_500, unitPriceCents: 120_000, taxBps: 1600 },                                // 5.5 h x $1,200
  ], { chargesCents: 50_000, chargesTaxBps: 1600, advanceBps: 5000 });
  assert.equal(q.lines[0].grossCents, 4_500_000);
  assert.equal(q.lines[1].grossCents, 660_000);
  assert.equal(q.subtotalCents, 5_160_000);
  assert.equal(q.discountCents, 100_000);
  const base0 = 4_400_000, base1 = 660_000;
  assert.equal(q.lines[0].taxCents, taxOf(base0, 1600));
  assert.equal(q.taxCents, taxOf(base0, 1600) + taxOf(base1, 1600) + taxOf(50_000, 1600));
  assert.equal(q.totalCents, base0 + base1 + 50_000 + q.taxCents);
  assert.equal(q.advanceCents, taxOf(q.totalCents, 5000));
  assert.throws(() => computeQuote([{ description: 'x', qtyMilli: 1000, unitPriceCents: 100, discountCents: 200, taxBps: 0 }]));
});
test('finanzas del evento: saldo, no suma pendientes/cancelados, margen', () => {
  const f = computeEventFinancials({
    contractedTotalCents: 1_160_000, contractedTaxCents: 160_000,
    payments: [
      { direction: 'in', status: 'paid', amountCents: 500_000, paidCents: 500_000, verified: true },
      { direction: 'in', status: 'partially_paid', amountCents: 300_000, paidCents: 100_000, verified: false },
      { direction: 'in', status: 'pending', amountCents: 400_000, paidCents: 0, verified: false },
      { direction: 'in', status: 'cancelled', amountCents: 999_999, paidCents: 0, verified: false },
      { direction: 'out', status: 'paid', amountCents: 300_000, paidCents: 300_000, verified: false },
    ],
    assignments: [
      { status: 'confirmed', costCents: 600_000, actualCostCents: 620_000 },
      { status: 'rejected', costCents: 777_777, actualCostCents: null },
    ],
    expensesCents: 20_000,
    adjustments: [{ kind: 'refund', amountCents: -50_000 }, { kind: 'client_charge', amountCents: 30_000 }],
  });
  assert.equal(f.collectedRegistered, 600_000 - 50_000);
  assert.equal(f.collectedVerified, 500_000 - 50_000);
  assert.equal(f.clientBalance, 1_160_000 + 30_000 - 550_000);
  assert.equal(f.vendorCostContracted, 600_000);
  assert.equal(f.vendorOwed, 300_000);
  assert.equal(f.realCost, 640_000);
  assert.equal(f.revenueNet, 1_030_000);
  assert.equal(f.finalProfit, 390_000);
  assert.equal(f.marginPct, 37.86);
});
test('transiciones de estado válidas e inválidas', () => {
  assert.ok(canTransition(EVENT_TRANSITIONS, 'prospect', 'initial_consult'));
  assert.ok(!canTransition(EVENT_TRANSITIONS, 'prospect', 'confirmed'));
  assert.ok(!canTransition(EVENT_TRANSITIONS, 'closed', 'planning'));
  assert.ok(!canTransition(REQUEST_TRANSITIONS, 'requested', 'confirmed'));
  assert.ok(canTransition(REQUEST_TRANSITIONS, 'pending_vendor', 'in_review'));
  assert.ok(!canTransition(ASSIGNMENT_TRANSITIONS, 'requested', 'confirmed'));
});
test('disponibilidad: sin registro = desconocida, nunca asumida', () => {
  const base = { window: { date: '2026-12-12', start: '16:00', end: '23:00' }, blackouts: [], dayRows: [], assignments: [], setupMin: 60, teardownMin: 30 };
  assert.equal(checkAvailability(base).state, 'unknown');
  assert.equal(checkAvailability({ ...base, dayRows: [{ date: '2026-12-12', status: 'available', capacity: 1 }] }).state, 'available');
  assert.equal(checkAvailability({ ...base, blackouts: [{ start: '2026-12-10', end: '2026-12-15' }] }).state, 'unavailable');
  const clash = checkAvailability({ ...base, dayRows: [{ date: '2026-12-12', status: 'available', capacity: 2 }], assignments: [{ id: 'a', status: 'confirmed', date: '2026-12-12', start: '10:00', end: '15:30' }] });
  assert.equal(clash.state, 'unavailable');   // montaje de 60 min cruza con la asignación hasta 15:30
});
test('cronograma: detecta traslapes, orden de dependencias y rangos inválidos', () => {
  const a = detectConflicts([
    { id: '1', date: '2026-12-12', start: '10:00', end: '12:00', title: 'Montaje audio', vendorId: 'v1', status: 'pending', deps: [] },
    { id: '2', date: '2026-12-12', start: '11:00', end: '13:00', title: 'Montaje luces', vendorId: 'v1', status: 'pending', deps: [] },
    { id: '3', date: '2026-12-12', start: '11:30', end: '12:30', title: 'Prueba', vendorId: null, status: 'in_progress', deps: ['1'] },
    { id: '4', date: '2026-12-12', start: '15:00', end: '14:00', title: 'Roto', vendorId: null, status: 'pending', deps: [] },
  ]);
  const types = a.map((x) => x.type).sort();
  assert.deepEqual(types, ['dependency_incomplete', 'dependency_order', 'invalid_range', 'overlap_vendor']);
});
