// Sustituto mínimo de @types/node para poder comprobar tipos SIN red.
// Si instalas @types/node (npm i -D @types/node), borra este archivo.
declare module "node:*";
declare const process: any;
declare const Buffer: any;
type Buffer = any;
interface ImportMeta { dirname: string; filename: string }
